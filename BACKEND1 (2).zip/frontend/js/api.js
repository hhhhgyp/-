/* ============================================================
   API 客户端 - 前端唯一的接口调用出口
   ------------------------------------------------------------
   设计要点（与后端约定保持一致）：
   1. 所有请求统一走 request()，统一拼接 /api/v1 前缀；
   2. 统一解析后端的错误体 {code, message, detail, request_id}，
      抛出的 ApiError 上带有 code 字段，页面可以直接按错误码展示文案；
   3. 收到 401 时自动清除本地会话并跳转登录页，
      避免"token 过期后页面一直报错但不提示重新登录"。
   ============================================================ */
(function (global) {
  'use strict';

  var API_BASE = '/api/v1';
  var TOKEN_KEY = 'll_access_token';
  var USER_KEY = 'll_current_user';

  function ApiError(code, message, detail, status) {
    var err = new Error(message || '请求失败');
    err.name = 'ApiError';
    err.code = code;
    err.detail = detail || null;
    err.status = status || 0;
    return err;
  }

  /* ---------------- 会话管理 ---------------- */

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }

  function getCurrentUser() {
    var raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  function isLoggedIn() {
    return !!getToken();
  }

  function isAdmin() {
    var user = getCurrentUser();
    return !!user && user.role === 'ADMIN';
  }

  function currentPath() {
    return window.location.pathname + window.location.search;
  }

  function redirectToLogin() {
    var target = encodeURIComponent(currentPath());
    window.location.href = '/login.html?redirect=' + target;
  }

  /* ---------------- 核心请求 ---------------- */

  function buildUrl(path, query) {
    var url = API_BASE + path;
    if (!query) return url;
    var parts = [];
    Object.keys(query).forEach(function (key) {
      var value = query[key];
      if (value === undefined || value === null || value === '') return;
      parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    if (parts.length) url += '?' + parts.join('&');
    return url;
  }

  async function request(path, options) {
    options = options || {};
    var method = options.method || 'GET';
    // 未登录时访问需要认证的接口，不应该发出请求后再跳转
    var needAuth = options.auth !== false;
    if (needAuth && !getToken()) {
      redirectToLogin();
      throw ApiError('AUTH_TOKEN_MISSING', '请先登录', null, 401);
    }

    var headers = { 'Accept': 'application/json' };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (needAuth) headers['Authorization'] = 'Bearer ' + getToken();

    var response = await fetch(buildUrl(path, options.query), {
      method: method,
      headers: headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body)
    });

    var text = await response.text();
    var data = null;
    if (text) {
      try { data = JSON.parse(text); } catch (e) { data = text; }
    }

    if (!response.ok) {
      var code = (data && data.code) || ('HTTP_' + response.status);
      var message = (data && data.message) || ('请求失败（HTTP ' + response.status + '）');
      if (response.status === 401 && needAuth) {
        clearSession();
        redirectToLogin();
      }
      throw ApiError(code, message, data && data.detail, response.status);
    }
    return data;
  }

  var api = {
    ApiError: ApiError,
    base: API_BASE,

    getToken: getToken,
    getCurrentUser: getCurrentUser,
    setSession: setSession,
    clearSession: clearSession,
    isLoggedIn: isLoggedIn,
    isAdmin: isAdmin,
    redirectToLogin: redirectToLogin,

    get: function (path, query, options) {
      return request(path, Object.assign({ method: 'GET', query: query }, options || {}));
    },
    post: function (path, body, options) {
      return request(path, Object.assign({ method: 'POST', body: body }, options || {}));
    },
    put: function (path, body, options) {
      return request(path, Object.assign({ method: 'PUT', body: body }, options || {}));
    },
    patch: function (path, body, options) {
      return request(path, Object.assign({ method: 'PATCH', body: body }, options || {}));
    },
    del: function (path, options) {
      return request(path, Object.assign({ method: 'DELETE' }, options || {}));
    },

    /* ---- 认证接口（与后端 app/api/v1/auth.py 一一对应） ---- */
    auth: {
      register: function (payload) {
        return request('/auth/register', { method: 'POST', body: payload, auth: false });
      },
      login: function (payload) {
        return request('/auth/login', { method: 'POST', body: payload, auth: false });
      },
      logout: function () {
        return request('/auth/logout', { method: 'POST' });
      },
      me: function () {
        return request('/auth/me', { method: 'GET' });
      }
    },

    /* ---- 查询接口（公开，auth:false 表示不附带 token、401 也不跳登录） ---- */
    points: {
      list: function (query) {
        return request('/points', { method: 'GET', query: query, auth: false });
      },
      cities: function () {
        return request('/points/cities', { method: 'GET', auth: false });
      },
      detail: function (pointId) {
        return request('/points/' + pointId, { method: 'GET', auth: false });
      },
      groups: function (pointId) {
        return request('/points/' + pointId + '/groups', { method: 'GET', auth: false });
      }
    },
    cabinetTypes: {
      list: function (query) {
        return request('/cabinet-types', { method: 'GET', query: query, auth: false });
      }
    },
    cabinets: {
      /** Q5：按时间段查询寄存点下可用的柜格 */
      availability: function (query) {
        return request('/cabinets/availability', { method: 'GET', query: query, auth: false });
      },
      /** Q6：单个柜格在指定时间段是否可用 */
      availabilityOf: function (cabinetId, query) {
        return request('/cabinets/' + cabinetId + '/availability',
          { method: 'GET', query: query, auth: false });
      },
      /** Q7：柜格详情 */
      detail: function (cabinetId) {
        return request('/cabinets/' + cabinetId, { method: 'GET', auth: false });
      }
    },

    /* ---- 预约接口（与后端 app/api/v1/reservations.py 一一对应） ---- */
    reservations: {
      /**
       * R1：创建预约。
       * 注意它有两种成功状态：
       *   201 + idempotent_replay=false  本次真正新建
       *   200 + idempotent_replay=true   同一幂等键重复提交，返回原订单
       * 页面必须按 idempotent_replay 字段区分，不能只看 HTTP 状态码。
       */
      create: function (payload) {
        return request('/reservations', { method: 'POST', body: payload });
      },
      /** R2：我的订单列表（分页） */
      mine: function (query) {
        return request('/reservations/my', { method: 'GET', query: query });
      },
      /** R3：订单详情（含 status_logs 状态时间线） */
      detail: function (orderNo) {
        return request('/reservations/' + encodeURIComponent(orderNo), { method: 'GET' });
      },
      /** R4：取消预约 */
      cancel: function (orderNo, reason) {
        return request('/reservations/' + encodeURIComponent(orderNo) + '/cancel',
          { method: 'POST', body: { reason: reason || null } });
      },
      /**
       * R5：签到存入（RESERVED -> IN_USE）。
       * 窗口 = [start_time - 15 分钟, checkin_deadline]，超出返回 409 CHECKIN_WINDOW_INVALID。
       * 签到**不**释放柜格时段（行李在柜内，柜格仍被占用）。
       */
      checkin: function (orderNo) {
        return request('/reservations/' + encodeURIComponent(orderNo) + '/check-in',
          { method: 'POST' });
      },
      /**
       * R6：完成取件（IN_USE / OVERDUE -> COMPLETED）。
       * 成功后立即释放柜格剩余时段（BR-24），不必等到 end_time。
       */
      complete: function (orderNo) {
        return request('/reservations/' + encodeURIComponent(orderNo) + '/complete',
          { method: 'POST' });
      }
    },

    /* ============================================================
       管理端接口（与后端 app/api/v1/admin.py 一一对应，M1 ~ M15）
       ------------------------------------------------------------
       全部需要 ADMIN 权限。非管理员调用会拿到 403 AUTH_FORBIDDEN，
       但页面在进入时就已经拦住了（ui.requireAdmin），不会把用户晾在一个
       "每个按钮都点不动"的页面上。
       ============================================================ */
    admin: {
      /* ---- M1 ~ M3 寄存点 ---- */
      points: {
        create: function (payload) {
          return request('/admin/points', { method: 'POST', body: payload });
        },
        update: function (pointId, payload) {
          return request('/admin/points/' + pointId, { method: 'PUT', body: payload });
        },
        setStatus: function (pointId, status) {
          return request('/admin/points/' + pointId + '/status',
            { method: 'PATCH', body: { status: status } });
        }
      },

      /* ---- M4 ~ M6 柜体与柜格 ---- */
      groups: {
        create: function (pointId, payload) {
          return request('/admin/points/' + pointId + '/groups', { method: 'POST', body: payload });
        },
        update: function (groupId, payload) {
          return request('/admin/groups/' + groupId, { method: 'PUT', body: payload });
        },
        /** M6b：某柜体下的全部柜格（含规格已停用的），P11 的数据源 */
        cabinets: function (groupId) {
          return request('/admin/groups/' + groupId + '/cabinets', { method: 'GET' });
        }
      },
      cabinets: {
        /** M6：批量新增柜格（C12 全有或全无，冲突时 409 并给出 conflicts 明细） */
        batchCreate: function (groupId, payload) {
          return request('/admin/groups/' + groupId + '/cabinets',
            { method: 'POST', body: payload });
        },
        /** M7：切换柜格运维状态（存在 IN_USE / OVERDUE 订单时切维护会 409） */
        setStatus: function (cabinetId, physicalStatus, remark) {
          return request('/admin/cabinets/' + cabinetId + '/status',
            { method: 'PATCH', body: { physical_status: physicalStatus, remark: remark || null } });
        }
      },

      /* ---- M8 ~ M9 柜格规格 ---- */
      cabinetTypes: {
        create: function (payload) {
          return request('/admin/cabinet-types', { method: 'POST', body: payload });
        },
        update: function (typeId, payload) {
          return request('/admin/cabinet-types/' + typeId, { method: 'PUT', body: payload });
        }
      },

      /* ---- M10 ~ M11 订单 ---- */
      reservations: {
        list: function (query) {
          return request('/admin/reservations', { method: 'GET', query: query });
        },
        /** M11：强制取消（不受取消窗口限制；终态订单 409 ORDER_STATUS_NOT_ALLOWED） */
        forceCancel: function (orderNo, reason) {
          return request('/admin/reservations/' + encodeURIComponent(orderNo) + '/force-cancel',
            { method: 'POST', body: { reason: reason } });
        }
      },

      /* ---- M12 统计 ---- */
      stats: {
        overview: function () {
          return request('/admin/stats/overview', { method: 'GET' });
        }
      },

      /* ---- M13 ~ M14 任务 ---- */
      jobs: {
        /** M13：手动触发超时释放任务（trigger_type = MANUAL） */
        runReleaseExpired: function () {
          return request('/admin/jobs/release-expired/run', { method: 'POST' });
        },
        logs: function (query) {
          return request('/admin/jobs/logs', { method: 'GET', query: query });
        }
      },

      /* ---- M15 系统配置 ---- */
      configs: {
        list: function () {
          return request('/admin/configs', { method: 'GET' });
        },
        update: function (key, value) {
          return request('/admin/configs/' + encodeURIComponent(key),
            { method: 'PUT', body: { value: String(value) } });
        }
      }
    }
  };

  global.api = api;
})(window);
