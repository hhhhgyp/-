/* ============================================================
   页面公共逻辑：导航栏渲染、提示、格式化、退出登录
   ============================================================ */
(function (global) {
  'use strict';

  /* ---------------- 工具函数 ---------------- */

  function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** 后端返回 "2026-10-20 10:00:00"，直接展示即可；这里只做空值兜底 */
  function formatDateTime(value) {
    if (!value) return '-';
    return String(value).replace('T', ' ');
  }

  /** "08:00:00" -> "08:00" */
  function formatHhmm(value) {
    if (!value) return '-';
    return String(value).slice(0, 5);
  }

  /** 派生状态 -> 中文标签 */
  var DERIVED_STATUS_TEXT = {
    AVAILABLE: '可用',
    RESERVED: '已预约',
    IN_USE: '使用中',
    MAINTENANCE: '维护中',
    DISABLED: '停用',
    UNAVAILABLE: '不可用'
  };

  function derivedStatusText(status) {
    return DERIVED_STATUS_TEXT[status] || status || '-';
  }

  /** 订单状态 -> 中文标签（与后端 ReservationStatus 一一对应） */
  var ORDER_STATUS_TEXT = {
    RESERVED: '已预约',
    IN_USE: '使用中',
    OVERDUE: '已超时',
    COMPLETED: '已完成',
    CANCELLED: '已取消',
    EXPIRED: '已过期（未存入）',
    FORCE_CANCELLED: '已强制取消'
  };

  function orderStatusText(status) {
    return ORDER_STATUS_TEXT[status] || status || '-';
  }

  /** 操作人类型 -> 中文 */
  function operatorText(type) {
    return { USER: '用户', ADMIN: '管理员', SYSTEM: '系统' }[type] || type || '-';
  }

  /* ---------------- 管理端文案表 ---------------- */

  /** 寄存点状态 -> 中文 */
  function pointStatusText(status) {
    return { OPEN: '营业中', CLOSED: '已关闭' }[status] || status || '-';
  }

  /** 柜体状态 -> 中文 */
  function groupStatusText(status) {
    return { NORMAL: '正常', MAINTENANCE: '维护中', DISABLED: '停用' }[status] || status || '-';
  }

  /** 柜格运维状态（physical_status）-> 中文 */
  function physicalStatusText(status) {
    return { AVAILABLE: '可用', MAINTENANCE: '维护中', DISABLED: '停用' }[status] || status || '-';
  }

  /** 行李尺寸等级 -> 中文 */
  function sizeLevelText(level) {
    return { SMALL: '小', MEDIUM: '中', LARGE: '大' }[level] || level || '-';
  }

  /**
   * 定时任务名 -> 中文。
   * 保留英文原名（放在 title 里或括号中）便于和数据库 job_execution_logs.job_name 对照。
   */
  var JOB_NAME_TEXT = {
    release_expired_reservations: '超时未签到释放',
    mark_overdue_reservations: '逾期未取标记'
  };

  function jobNameText(name) {
    return JOB_NAME_TEXT[name] || name || '-';
  }

  /** 任务触发类型 -> 中文（对应 job_execution_logs.trigger_type） */
  function jobTriggerText(type) {
    return { SCHEDULER: '调度器自动', MANUAL: '管理端手动', SCRIPT: '命令行' }[type] || type || '-';
  }

  /** 任务结果 -> 中文 */
  function jobResultText(result) {
    return { SUCCESS: '成功', PARTIAL: '部分成功', FAILED: '失败' }[result] || result || '-';
  }

  /** 支付状态 -> 中文（本期为模拟字段，不接入真实支付） */
  function payStatusText(status) {
    return { UNPAID: '未支付（模拟）', PAID: '已支付（模拟）', REFUNDED: '已退款（模拟）' }[status] || status || '-';
  }

  function formatMoney(value) {
    if (value === null || value === undefined || value === '') return '-';
    var num = Number(value);
    if (isNaN(num)) return String(value);
    return '¥' + num.toFixed(2);
  }

  function getQuery(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  /* ---------------- 提示 ---------------- */

  /**
   * 在指定的 .alert 元素上显示提示。
   * @param {HTMLElement|string} target 元素或元素 id
   * @param {string} message 文案
   * @param {'error'|'success'|'info'|'warning'} type 类型
   */
  function showAlert(target, message, type) {
    var el = typeof target === 'string' ? document.getElementById(target) : target;
    if (!el) return;
    el.className = 'alert alert-' + (type || 'error') + ' show';
    el.textContent = message;
  }

  function hideAlert(target) {
    var el = typeof target === 'string' ? document.getElementById(target) : target;
    if (!el) return;
    el.className = 'alert';
    el.textContent = '';
  }

  /**
   * 统一把后端异常转成可读提示。
   * 后端错误体形如 {code, message, detail, request_id}，
   * 直接在提示里带上 code 和 request_id，方便缺陷复现时对照日志。
   */
  function describeError(err) {
    if (!err) return '未知错误';
    var parts = [err.message || '请求失败'];
    if (err.code) parts.push('【' + err.code + '】');
    if (err.status === 401) parts.push('\n登录状态已失效，请重新登录。');
    return parts.join(' ');
  }

  /* ---------------- 导航栏 ---------------- */

  /**
   * 渲染顶部导航栏。
   * @param {string} active 当前激活的菜单标识
   */
  function renderNavbar(active) {
    var user = api.getCurrentUser();
    var logged = api.isLoggedIn() && !!user;

    var links = [
      { key: 'home', href: '/index.html', text: '寄存点' }
    ];
    if (logged) {
      links.push({ key: 'orders', href: '/my-orders.html', text: '我的订单' });
    }
    if (logged && api.isAdmin()) {
      links.push({ key: 'admin', href: '/admin/index.html', text: '后台管理' });
    }

    var html = '<nav class="navbar" id="navbar">';
    html += '<a class="brand" href="/index.html">智能行李寄存柜预约系统</a>';
    links.forEach(function (item) {
      var style = item.key === active ? ' style="color:#2563eb;font-weight:600"' : '';
      html += '<a class="nav-link"' + style + ' href="' + item.href + '">' + escapeHtml(item.text) + '</a>';
    });
    html += '<span class="spacer"></span>';
    if (logged) {
      html += '<span class="user-box">' + escapeHtml(user.username) +
        '（' + (user.role === 'ADMIN' ? '管理员' : '普通用户') + '）</span>';
      html += '<button class="btn btn-secondary btn-sm" id="nav-logout">退出登录</button>';
    } else {
      html += '<a class="nav-link" href="/login.html">登录</a>';
      html += '<a class="btn btn-sm" href="/register.html">注册</a>';
    }
    html += '</nav>';

    var holder = document.getElementById('navbar');
    if (holder) holder.outerHTML = html;

    var logoutBtn = document.getElementById('nav-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', doLogout);
    }
  }

  async function doLogout() {
    try {
      await api.auth.logout();
    } catch (e) {
      // 即便服务端调用失败（例如 token 已失效），本地也要清干净
      console.warn('退出登录接口返回异常：', e);
    }
    api.clearSession();
    window.location.href = '/login.html';
  }

  /* ---------------- 管理端 ---------------- */

  /**
   * 管理页入口守卫。**每个 /admin/*.html 都必须在最前面调用**。
   *
   * 为什么不在页面里靠"接口返回 403 再提示"：
   * 那样用户会看到一个布局完整、但每个按钮点下去都报错的页面，
   * 分不清是"没权限"还是"系统坏了"。权限问题必须在进入页面时就明确告知。
   *
   * @returns {boolean} true 表示当前用户是管理员，可以继续渲染页面
   */
  function requireAdmin() {
    var user = api.getCurrentUser();
    if (!api.isLoggedIn() || !user) {
      api.redirectToLogin();
      return false;
    }
    if (user.role !== 'ADMIN') {
      // 已登录但不是管理员：送回登录页并说明原因（登录页会读 denied=1 显示提示）。
      // 不跳首页，是因为用户的下一步动作几乎一定是“换个管理员账号登录”。
      // redirect 使用当前管理页而不是写死 index，管理员登录后可回到原目标页。
      var target = window.location.pathname + window.location.search;
      window.location.replace(
        '/login.html?denied=1&redirect=' + encodeURIComponent(target)
      );
      return false;
    }
    return true;
  }

  var ADMIN_NAV = [
    { key: 'index', href: '/admin/index.html', text: '控制台' },
    { key: 'points', href: '/admin/points.html', text: '寄存点' },
    { key: 'groups', href: '/admin/groups.html', text: '柜体' },
    { key: 'cabinets', href: '/admin/cabinets.html', text: '柜格' },
    { key: 'types', href: '/admin/types.html', text: '规格' },
    { key: 'orders', href: '/admin/orders.html', text: '订单' },
    { key: 'jobs', href: '/admin/jobs.html', text: '任务' }
  ];

  /**
   * 渲染管理端二级导航（对应设计方案 7.1 的 P8 ~ P14）。
   * @param {string} active 当前页面的 key
   */
  function renderAdminNav(active) {
    var holder = document.getElementById('admin-nav');
    if (!holder) return;
    var html = '<div class="admin-nav">';
    ADMIN_NAV.forEach(function (item) {
      var cls = 'admin-nav-item' + (item.key === active ? ' active' : '');
      html += '<a class="' + cls + '" href="' + item.href + '">' + escapeHtml(item.text) + '</a>';
    });
    html += '</div>';
    holder.innerHTML = html;
  }

  /** 管理页统一的错误提示：把 detail 里后端给的可读原因也带出来 */
  function describeAdminError(err) {
    var text = describeError(err);
    if (err && err.detail && err.detail.hint) {
      text += '\n提示：' + err.detail.hint;
    }
    return text;
  }

  global.ui = {
    escapeHtml: escapeHtml,
    formatDateTime: formatDateTime,
    formatHhmm: formatHhmm,
    derivedStatusText: derivedStatusText,
    orderStatusText: orderStatusText,
    operatorText: operatorText,
    pointStatusText: pointStatusText,
    groupStatusText: groupStatusText,
    physicalStatusText: physicalStatusText,
    sizeLevelText: sizeLevelText,
    jobNameText: jobNameText,
    jobTriggerText: jobTriggerText,
    jobResultText: jobResultText,
    payStatusText: payStatusText,
    formatMoney: formatMoney,
    getQuery: getQuery,
    showAlert: showAlert,
    hideAlert: hideAlert,
    describeError: describeError,
    describeAdminError: describeAdminError,
    renderNavbar: renderNavbar,
    renderAdminNav: renderAdminNav,
    requireAdmin: requireAdmin,
    doLogout: doLogout
  };
})(window);
