# pytest 接口自动化测试

真实 HTTP + 真实 MySQL，无 mock。完整说明见 `../docs/06-Pytest接口自动化测试.md`。

## 快速开始

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt

# 另一个终端启动服务（关闭调度器，避免干扰）
python run.py --port 8138 --no-reload --no-scheduler

# 核心用例
python -m pytest -m core -v

# 全量 + HTML 报告
python -m pytest -v --html=tests/reports/api-report.html --self-contained-html
```

当前基线：**71 passed**（auth 13 + query 12 + reservation 18 + lifecycle 14 + admin 12 + concurrency 2）。

## 目录

| 文件 | 用途 |
|---|---|
| `config.py` | 环境变量配置（`TEST_BASE_URL` / 账号 / 超时）与时间工具 |
| `api_client.py` | requests 公共封装、登录、错误体三层断言 |
| `db.py` | 订单 / 时段 / 状态日志 / 幂等键的只读校验 |
| `factories.py` | 预约请求体构造 |
| `conftest.py` | 客户端、隔离寄存点/柜体、时段分配、订单清理、配置回滚 |
| `test_01_auth.py` | 认证、登出、角色权限、注册校验 |
| `test_02_query.py` | 寄存点、柜体、规格、Q5/Q6 可用性 |
| `test_03_reservation.py` | 创建、冲突、边界（144/145）、幂等 |
| `test_04_lifecycle.py` | 取消、签到、取件、强制取消、越权 |
| `test_05_admin.py` | 管理端查询、统计、任务、配置 |
| `test_06_concurrency.py` | 8 线程同柜格抢锁 + 并发幂等 |
| `cleanup_test_data.py` | 异常中断后的兜底清理（只删 pytest 数据） |
| `reports/` | HTML / JUnit 报告输出目录 |

## UI 自动化

Selenium 浏览器端用例在 `tests/ui/`，说明见 `../docs/07-Selenium-UI自动化测试.md`：

```powershell
python -m pytest -m ui -v
python -m pytest tests/ui -v --html=tests/ui/reports/ui-report.html --self-contained-html
```

当前 UI 基线：Chrome 6 passed（Edge 完整 E2E 抽查 1 passed）。

## 数据隔离

- session 级 `sandbox`：通过管理端真实接口创建 `TST-PY-*` 寄存点、柜体和 6 个 S 柜格，结束后按 FK 顺序删除。
- function 级 `order_cleanup`：用例结束先用户取消，失败再管理员强制取消。
- `config_override`：修改配置后按原值恢复。
- `temp_user`：注册的临时用户结束后删除。
- `slot_factory`：每个用例分配不同柜格/时段，避免窗口冲突。

## 注意

- 测试顺序执行，不建议 `pytest-xdist` 跑全量（管理端统计/任务日志是全局视角）。
- 需要先启动服务；测试不会自动拉起进程。
- 依赖种子基线：SP001 20 个柜格、A-12 维护中、S/M/L 三种规格。
- 异常中断后执行 `python tests\cleanup_test_data.py --dry-run` 确认，再去掉 `--dry-run` 清理。
