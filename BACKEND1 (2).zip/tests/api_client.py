﻿"""轻量 HTTP 封装：统一 base_url、超时、Bearer Token 和状态码断言。"""

from __future__ import annotations

from typing import Any

import requests

from tests.config import Settings


class ApiClient:
    def __init__(self, base_url: str, token: str | None = None, timeout: float = 10.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.token = token
        self.session = requests.Session()
        if token:
            self.session.headers.update({"Authorization": f"Bearer {token}"})

    def request(self, method: str, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        url = f"{self.base_url}/{path.lstrip('/')}"
        response = self.session.request(method, url, timeout=self.timeout, **kwargs)
        if expected is not None:
            assert response.status_code == expected, (
                f"{method} {url} 期望 HTTP {expected}，实际 {response.status_code}\n"
                f"响应体: {response.text[:1000]}"
            )
        return response

    def get(self, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        return self.request("GET", path, expected=expected, **kwargs)

    def post(self, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        return self.request("POST", path, expected=expected, **kwargs)

    def put(self, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        return self.request("PUT", path, expected=expected, **kwargs)

    def patch(self, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        return self.request("PATCH", path, expected=expected, **kwargs)

    def delete(self, path: str, *, expected: int | None = None, **kwargs: Any) -> requests.Response:
        return self.request("DELETE", path, expected=expected, **kwargs)

    def close(self) -> None:
        self.session.close()


def login(config: Settings, username: str, password: str) -> tuple[ApiClient, dict[str, Any]]:
    anon = ApiClient(config.base_url, timeout=config.timeout)
    response = anon.post("/auth/login", json={"username": username, "password": password}, expected=200)
    body = response.json()
    anon.close()
    return ApiClient(config.base_url, token=body["access_token"], timeout=config.timeout), body


def assert_error(response: requests.Response, status: int, code: str) -> dict[str, Any]:
    """三层断言的第一、二层：HTTP 状态 + 业务错误码。"""
    assert response.status_code == status, (
        f"期望 HTTP {status}，实际 {response.status_code}\n响应体: {response.text[:1000]}"
    )
    body = response.json()
    assert body.get("code") == code, f"期望业务码 {code}，实际 {body.get('code')}，响应体: {body}"
    assert body.get("message"), "错误响应缺少 message"
    assert body.get("request_id"), "错误响应缺少 request_id（无法定位服务端日志）"
    return body
