"""兜底清理：删除 pytest 套件创建的寄存点/柜体/柜格/订单/临时用户。

正常跑完 pytest 不需要执行；仅在测试进程被强杀、fixture 的 finally 没来得及
执行时使用。只删除带 pytest 标识的数据，不碰种子数据。

用法（在 backend 目录）：
    python tests/cleanup_test_data.py --dry-run
    python tests/cleanup_test_data.py
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import text  # noqa: E402

from app.db.session import SessionLocal  # noqa: E402


def _in_clause(column: str, values: list[int], params: dict) -> str:
    names = []
    for index, value in enumerate(values):
        name = f"v{index}"
        names.append(f":{name}")
        params[name] = value
    return f"{column} IN ({', '.join(names)})"


def cleanup(dry_run: bool = False) -> None:
    session = SessionLocal()
    try:
        point_ids = [
            int(value)
            for value in session.execute(
                text("SELECT id FROM storage_points WHERE code LIKE 'TST-PY-%'")
            ).scalars()
        ]
        params: dict = {}
        group_ids: list[int] = []
        cabinet_ids: list[int] = []
        if point_ids:
            group_ids = [
                int(value)
                for value in session.execute(
                    text(f"SELECT id FROM cabinet_groups WHERE {_in_clause('point_id', point_ids, params)}"),
                    params,
                ).scalars()
            ]
        params = {}
        if group_ids:
            cabinet_ids = [
                int(value)
                for value in session.execute(
                    text(f"SELECT id FROM cabinets WHERE {_in_clause('group_id', group_ids, params)}"),
                    params,
                ).scalars()
            ]

        print(f"points={point_ids}")
        print(f"groups={group_ids}")
        print(f"cabinets={cabinet_ids}")

        if dry_run:
            print("dry-run：不执行删除")
            return

        if cabinet_ids:
            join_params: dict = {}
            join_clause = _in_clause("r.cabinet_id", cabinet_ids, join_params)
            session.execute(
                text(
                    "DELETE l FROM reservation_status_logs l "
                    "JOIN reservations r ON r.id = l.reservation_id "
                    f"WHERE {join_clause}"
                ),
                join_params,
            )
            session.execute(
                text(
                    "DELETE s FROM reservation_slots s "
                    "JOIN reservations r ON r.id = s.reservation_id "
                    f"WHERE {join_clause}"
                ),
                join_params,
            )
            own_params: dict = {}
            own_clause = _in_clause("cabinet_id", cabinet_ids, own_params)
            session.execute(text(f"DELETE FROM reservations WHERE {own_clause}"), own_params)
            id_params: dict = {}
            id_clause = _in_clause("id", cabinet_ids, id_params)
            session.execute(text(f"DELETE FROM cabinets WHERE {id_clause}"), id_params)
        if group_ids:
            params = {}
            session.execute(
                text(f"DELETE FROM cabinet_groups WHERE {_in_clause('id', group_ids, params)}"), params
            )
        if point_ids:
            params = {}
            session.execute(
                text(f"DELETE FROM storage_points WHERE {_in_clause('id', point_ids, params)}"), params
            )

        session.execute(text(r"DELETE FROM users WHERE username REGEXP '^pytest_[0-9a-f]{8}$'"))
        session.commit()
        print("清理完成")
    finally:
        session.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="清理 pytest 自动化测试遗留数据")
    parser.add_argument("--dry-run", action="store_true", help="只打印将删除的 ID，不提交")
    cleanup(dry_run=parser.parse_args().dry_run)
