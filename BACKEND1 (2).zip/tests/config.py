﻿"""测试配置：全部通过环境变量覆盖，默认值对应本地 8138 端口。"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta

_API_BASE_DEFAULT = os.getenv("TEST_BASE_URL", "http://127.0.0.1:8138/api/v1")
_UI_BASE_DEFAULT = os.getenv(
    "TEST_UI_BASE_URL", _API_BASE_DEFAULT.removesuffix("/api/v1")
)


@dataclass(frozen=True)
class Settings:
    base_url: str = _API_BASE_DEFAULT
    ui_base_url: str = _UI_BASE_DEFAULT
    username: str = os.getenv("TEST_USERNAME", "user01")
    password: str = os.getenv("TEST_PASSWORD", "Demo@123456")
    user2_username: str = os.getenv("TEST_USER2_USERNAME", "user02")
    user2_password: str = os.getenv("TEST_USER2_PASSWORD", "Demo@123456")
    admin_username: str = os.getenv("TEST_ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("TEST_ADMIN_PASSWORD", "Demo@123456")
    timeout: float = float(os.getenv("TEST_TIMEOUT", "10"))
    browser: str = os.getenv("TEST_BROWSER", "chrome")
    headless: bool = os.getenv("TEST_HEADLESS", "1").lower() not in {"0", "false", "no"}
    ui_timeout: float = float(os.getenv("TEST_UI_TIMEOUT", "15"))


def at(day_offset: int, hour: int, minute: int = 0) -> datetime:
    """构造相对“现在”的未来时间，秒/微秒归零，保证 30 分钟对齐。

    默认使用 D+2 以后，避免与“当前时间之后的最近时段”产生偶发越界。
    """
    now = datetime.now()
    target = now + timedelta(days=day_offset)
    return target.replace(hour=hour, minute=minute, second=0, microsecond=0)


def iso(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H:%M:%S")


def unique_key(prefix: str = "pytest") -> str:
    """幂等键：8~64 位，测试内唯一，便于按前缀清理。"""
    return f"{prefix}-{uuid.uuid4().hex[:16]}"
