﻿"""pytest fixtures：认证、隔离测试柜组、时段分配、订单清理、配置回滚。"""

from __future__ import annotations

import secrets
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from itertools import count

import pytest
from sqlalchemy import text

from tests.api_client import ApiClient, login
from tests.config import Settings, at
from tests.db import db_session
from tests.factories import booking_payload


# ---------------------------------------------------------------------------
# 基础客户端
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def config() -> Settings:
    return Settings()


@pytest.fixture(scope="session")
def anon(config: Settings) -> ApiClient:
    return ApiClient(config.base_url, timeout=config.timeout)


@pytest.fixture(scope="session")
def admin(config: Settings) -> ApiClient:
    client, _ = login(config, config.admin_username, config.admin_password)
    return client


@pytest.fixture(scope="session")
def user_login(config: Settings):
    return login(config, config.username, config.password)


@pytest.fixture(scope="session")
def user_api(user_login) -> ApiClient:
    return user_login[0]


@pytest.fixture(scope="session")
def user_api_body(user_login) -> dict:
    return user_login[1]


@pytest.fixture(scope="session")
def user2_api(config: Settings) -> ApiClient:
    client, _ = login(config, config.user2_username, config.user2_password)
    return client


# ---------------------------------------------------------------------------
# 隔离测试数据：独立寄存点 + 柜体 + 6 个柜格
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CabinetRef:
    id: int
    code: str


@dataclass(frozen=True)
class Sandbox:
    point_id: int
    point_code: str
    point_name: str
    group_id: int
    group_code: str
    cabinet_prefix: str
    cabinets: list[CabinetRef]
    type_s_id: int
    type_s_price: str


@dataclass(frozen=True)
class Slot:
    cabinet_id: int
    cabinet_code: str
    start: datetime
    end: datetime

    def shifted(self, minutes: int) -> "Slot":
        delta = timedelta(minutes=minutes)
        return replace(self, start=self.start + delta, end=self.end + delta)

    def extended(self, slots: int) -> "Slot":
        return replace(self, end=self.start + timedelta(minutes=30 * slots))


def _cleanup_sandbox(point_id: int | None, group_id: int | None, cabinet_ids: list[int]) -> None:
    """按 FK 顺序清理：状态日志 -> 时段 -> 订单 -> 柜格 -> 柜体 -> 寄存点。

    即使测试数据只创建了一半（例如批量建柜格时抛错），也按 group_id 反查柜格，
    保证不会留下悬挂数据。
    """
    with db_session() as session:
        if group_id:
            rows = session.execute(
                text("SELECT id FROM cabinets WHERE group_id = :group_id"), {"group_id": group_id}
            ).scalars().all()
            cabinet_ids = sorted({*cabinet_ids, *[int(value) for value in rows]})
        if cabinet_ids:
            ids = ",".join(str(int(value)) for value in cabinet_ids)
            session.execute(
                text(
                    f"DELETE l FROM reservation_status_logs l "
                    f"JOIN reservations r ON r.id = l.reservation_id "
                    f"WHERE r.cabinet_id IN ({ids})"
                )
            )
            session.execute(
                text(
                    f"DELETE s FROM reservation_slots s "
                    f"JOIN reservations r ON r.id = s.reservation_id "
                    f"WHERE r.cabinet_id IN ({ids})"
                )
            )
            session.execute(text(f"DELETE FROM reservations WHERE cabinet_id IN ({ids})"))
            session.execute(text(f"DELETE FROM cabinets WHERE id IN ({ids})"))
        if group_id:
            session.execute(text("DELETE FROM cabinet_groups WHERE id = :id"), {"id": group_id})
        if point_id:
            session.execute(text("DELETE FROM storage_points WHERE id = :id"), {"id": point_id})
        # 兜底：清理本套件注册的临时用户（测试失败时 fixture 可能来不及收尾）
        session.execute(text(r"DELETE FROM users WHERE username REGEXP '^pytest_[0-9a-f]{8}$'"))
        session.commit()


@pytest.fixture(scope="session")
def sandbox(admin: ApiClient) -> Sandbox:
    suffix = secrets.token_hex(3)
    point_id: int | None = None
    group_id: int | None = None
    cabinet_ids: list[int] = []
    try:
        point = admin.post(
            "/admin/points",
            json={
                "code": f"TST-PY-{suffix}",
                "name": f"pytest 隔离寄存点 {suffix}",
                "city": "测试城市",
                "address": "pytest 自动化测试专用，禁止人工使用",
                "open_time": "08:00",
                "close_time": "22:00",
                "status": "OPEN",
                "description": "pytest 创建，测试结束自动删除",
            },
            expected=201,
        ).json()
        point_id = point["id"]

        group = admin.post(
            f"/admin/points/{point_id}/groups",
            json={"code": f"G-{suffix}", "name": f"pytest 柜体 {suffix}", "status": "NORMAL"},
            expected=201,
        ).json()
        group_id = group["id"]

        types = admin.get("/cabinet-types", expected=200).json()
        small = next(item for item in types if item["code"] == "S")
        assert small["is_active"] is True, "种子数据中 S 规格必须启用"

        batch = admin.post(
            f"/admin/groups/{group_id}/cabinets",
            json={
                "prefix": f"PY{suffix[:4]}-",
                "count": 6,
                "type_id": small["id"],
                "start_index": 1,
                "remark": "pytest 隔离柜格",
            },
            expected=201,
        ).json()
        cabinets = [CabinetRef(id=item["id"], code=item["code"]) for item in batch["created"]]
        cabinet_ids = [item.id for item in cabinets]
        assert len(cabinets) == 6

        yield Sandbox(
            point_id=point_id,
            point_code=point["code"],
            point_name=point["name"],
            group_id=group_id,
            group_code=group["code"],
            cabinet_prefix=f"PY{suffix[:4]}-",
            cabinets=cabinets,
            type_s_id=small["id"],
            type_s_price=str(small["price_per_slot"]),
        )
    finally:
        _cleanup_sandbox(point_id, group_id, cabinet_ids)


@pytest.fixture(scope="session")
def slot_factory(sandbox: Sandbox):
    """给每个测试分配互不重叠的 (柜格, 时段)。

    6 个柜格 × 每天 3 个时段 × D+2..D+5，足够 70+ 个测试；
    每个测试结束后清理订单，因此同一柜格可以安全复用不同时段。
    """
    counter = count()

    def _next(minutes: int = 60) -> Slot:
        index = next(counter)
        cabinet = sandbox.cabinets[index % len(sandbox.cabinets)]
        round_index = index // len(sandbox.cabinets)
        day = 2 + round_index // 3
        hour = 10 + (round_index % 3) * 3
        start = at(day, hour)
        return Slot(
            cabinet_id=cabinet.id,
            cabinet_code=cabinet.code,
            start=start,
            end=start + timedelta(minutes=minutes),
        )

    return _next


# ---------------------------------------------------------------------------
# 订单清理：测试结束取消未终态订单；失败则用管理员强制取消
# ---------------------------------------------------------------------------
class OrderCleanup:
    def __init__(self, user_api: ApiClient, admin: ApiClient) -> None:
        self.user_api = user_api
        self.admin = admin
        self.order_nos: list[str] = []

    def register(self, order_no: str) -> None:
        self.order_nos.append(order_no)

    def cleanup(self) -> None:
        for order_no in reversed(self.order_nos):
            response = self.user_api.post(f"/reservations/{order_no}/cancel", json={})
            if response.status_code == 200:
                continue
            # 已签到/已完成/已取消等终态无法用户取消，尝试管理员强制取消
            self.admin.post(
                f"/admin/reservations/{order_no}/force-cancel",
                json={"reason": "pytest teardown 自动清理"},
            )


@pytest.fixture
def order_cleanup(user_api: ApiClient, admin: ApiClient) -> OrderCleanup:
    cleanup = OrderCleanup(user_api, admin)
    yield cleanup
    cleanup.cleanup()


@pytest.fixture
def book(user_api: ApiClient, order_cleanup: OrderCleanup):
    """创建预约并登记清理；返回 response，便于断言。"""

    def _book(
        slot: Slot,
        *,
        size: str = "SMALL",
        count: int = 1,
        key: str | None = None,
        expected: int | None = 201,
        end: datetime | None = None,
    ):
        payload = booking_payload(
            slot.cabinet_id,
            slot.start,
            end or slot.end,
            size=size,
            count=count,
            key=key,
        )
        response = user_api.post("/reservations", json=payload, expected=expected)
        if response.status_code == 201:
            order_cleanup.register(response.json()["order_no"])
        return response

    return _book


# ---------------------------------------------------------------------------
# 系统配置覆盖：测试内改，测试结束恢复原值
# ---------------------------------------------------------------------------
@pytest.fixture
def config_override(admin: ApiClient):
    originals: dict[str, str] = {}

    def _set(key: str, value: str | int) -> str:
        configs = admin.get("/admin/configs", expected=200).json()
        item = next(config for config in configs if config["key"] == key)
        originals.setdefault(key, item["value"])
        admin.put(f"/admin/configs/{key}", json={"value": str(value)}, expected=200)
        return item["value"]

    yield _set
    for key, value in originals.items():
        admin.put(f"/admin/configs/{key}", json={"value": value}, expected=200)


# ---------------------------------------------------------------------------
# 临时用户（注册/登录/登出场景），测试结束删除
# ---------------------------------------------------------------------------
@pytest.fixture
def temp_user(anon: ApiClient):
    username = f"pytest_{secrets.token_hex(4)}"
    password = "Pytest@123456"
    anon.post("/auth/register", json={"username": username, "password": password}, expected=201)
    yield username, password
    with db_session() as session:
        session.execute(text("DELETE FROM users WHERE username = :username"), {"username": username})
        session.commit()


@pytest.fixture
def temp_user_client(config: Settings, temp_user):
    username, password = temp_user
    client, body = login(config, username, password)
    yield client, body
    client.close()
