"""数据库校验助手：复用应用 SessionLocal，避免另写一套连接配置。"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
from typing import Any, Iterator

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.db.session import SessionLocal


@contextmanager
def db_session() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def _one(sql: str, params: dict[str, Any]) -> dict[str, Any] | None:
    with db_session() as session:
        row = session.execute(text(sql), params).mappings().first()
    return dict(row) if row else None


def _all(sql: str, params: dict[str, Any]) -> list[dict[str, Any]]:
    with db_session() as session:
        rows = session.execute(text(sql), params).mappings().all()
    return [dict(row) for row in rows]


def order_row(order_no: str) -> dict[str, Any] | None:
    return _one(
        """
        SELECT id, order_no, user_id, point_id, cabinet_id, cabinet_type_id,
               start_time, end_time, slot_count, luggage_size, luggage_count,
               unit_price, amount, pay_status, status, idempotency_key,
               checkin_deadline, checked_in_at, completed_at, cancelled_at, cancel_reason
        FROM reservations
        WHERE order_no = :order_no
        """,
        {"order_no": order_no},
    )


def slot_starts(order_no: str) -> list[datetime]:
    rows = _all(
        """
        SELECT s.slot_start
        FROM reservation_slots s
        JOIN reservations r ON r.id = s.reservation_id
        WHERE r.order_no = :order_no
        ORDER BY s.slot_start
        """,
        {"order_no": order_no},
    )
    return [row["slot_start"] for row in rows]


def slot_count(order_no: str) -> int:
    row = _one(
        """
        SELECT COUNT(*) AS cnt
        FROM reservation_slots s
        JOIN reservations r ON r.id = s.reservation_id
        WHERE r.order_no = :order_no
        """,
        {"order_no": order_no},
    )
    return int(row["cnt"]) if row else 0


def status_transitions(order_no: str) -> list[dict[str, Any]]:
    return _all(
        """
        SELECT l.from_status, l.to_status, l.operator_type, l.operator_id, l.remark
        FROM reservation_status_logs l
        JOIN reservations r ON r.id = l.reservation_id
        WHERE r.order_no = :order_no
        ORDER BY l.id
        """,
        {"order_no": order_no},
    )


def reservations_by_key(idempotency_key: str) -> list[dict[str, Any]]:
    return _all(
        "SELECT order_no, status FROM reservations WHERE idempotency_key = :key",
        {"key": idempotency_key},
    )


def active_orders_on_cabinet(cabinet_id: int) -> list[dict[str, Any]]:
    return _all(
        """
        SELECT order_no, status, start_time, end_time
        FROM reservations
        WHERE cabinet_id = :cabinet_id
          AND status IN ('RESERVED', 'IN_USE', 'OVERDUE')
        """,
        {"cabinet_id": cabinet_id},
    )


def cabinet_by_code(code: str) -> dict[str, Any] | None:
    return _one(
        """
        SELECT c.id, c.code, c.physical_status, c.group_id, g.point_id, c.type_id
        FROM cabinets c
        JOIN cabinet_groups g ON g.id = c.group_id
        WHERE c.code = :code
        """,
        {"code": code},
    )


def count_slots_in_window(cabinet_id: int, start: datetime, end: datetime) -> int:
    """统计某柜格在 [start, end) 内被占用的 slot 数（用于验证并发/冲突未落库）。"""
    row = _one(
        """
        SELECT COUNT(*) AS cnt
        FROM reservation_slots
        WHERE cabinet_id = :cabinet_id
          AND slot_start >= :start
          AND slot_start < :end
        """,
        {"cabinet_id": cabinet_id, "start": start, "end": end},
    )
    return int(row["cnt"]) if row else 0


def active_order_count(cabinet_id: int, start: datetime, end: datetime) -> int:
    row = _one(
        """
        SELECT COUNT(*) AS cnt
        FROM reservations
        WHERE cabinet_id = :cabinet_id
          AND start_time = :start
          AND end_time = :end
          AND status IN ('RESERVED', 'IN_USE', 'OVERDUE')
        """,
        {"cabinet_id": cabinet_id, "start": start, "end": end},
    )
    return int(row["cnt"]) if row else 0
