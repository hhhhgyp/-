"""测试数据构造器：只生成请求体，不直接写库。"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from tests.config import iso, unique_key


def booking_payload(
    cabinet_id: int,
    start: datetime,
    end: datetime,
    *,
    size: str = "SMALL",
    count: int = 1,
    key: str | None = None,
) -> dict[str, Any]:
    return {
        "cabinet_id": cabinet_id,
        "start_time": iso(start),
        "end_time": iso(end),
        "luggage_size": size,
        "luggage_count": count,
        "idempotency_key": key or unique_key(),
    }
