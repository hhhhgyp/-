﻿"""认证与权限基础用例（第一阶段核心）。"""

from __future__ import annotations

import pytest

from tests.api_client import ApiClient, assert_error
from tests.config import Settings


@pytest.mark.core
def test_health_and_database(anon: ApiClient) -> None:
    body = anon.get("/health", expected=200).json()
    assert body["status"] == "ok"
    assert body["database"]["ok"] is True
    assert body["database"]["server_time"]


@pytest.mark.core
def test_login_success_returns_token_and_profile(user_api: ApiClient, user_api_body: dict) -> None:
    assert user_api_body["token_type"] == "bearer"
    assert user_api_body["expires_in"] > 0
    assert user_api_body["access_token"]
    user = user_api_body["user"]
    assert user["username"] == "user01"
    assert user["role"] == "USER"
    assert user["status"] == "ACTIVE"
    assert "password" not in str(user).lower()


@pytest.mark.core
def test_me_with_valid_token(user_api: ApiClient) -> None:
    body = user_api.get("/auth/me", expected=200).json()
    assert body["username"] == "user01"
    assert body["role"] == "USER"
    assert body["token_version"] >= 1


@pytest.mark.core
@pytest.mark.parametrize(
    ("username", "password"),
    [
        ("user01", "Wrong@123456"),
        ("no_such_user_pytest", "Demo@123456"),
    ],
)
def test_login_rejects_bad_credentials(anon: ApiClient, username: str, password: str) -> None:
    response = anon.post("/auth/login", json={"username": username, "password": password})
    assert_error(response, 401, "AUTH_INVALID_CREDENTIALS")


@pytest.mark.core
def test_me_without_token(anon: ApiClient) -> None:
    assert_error(anon.get("/auth/me"), 401, "AUTH_TOKEN_MISSING")


@pytest.mark.core
def test_me_with_malformed_token(config: Settings) -> None:
    client = ApiClient(config.base_url, token="not-a-real-jwt", timeout=config.timeout)
    assert_error(client.get("/auth/me"), 401, "AUTH_TOKEN_INVALID")


@pytest.mark.core
def test_regular_user_cannot_access_admin(user_api: ApiClient) -> None:
    assert_error(user_api.get("/admin/configs"), 403, "AUTH_FORBIDDEN")


@pytest.mark.core
def test_logout_invalidates_old_token(temp_user_client) -> None:
    client, body = temp_user_client
    assert body["user"]["role"] == "USER"

    client.post("/auth/logout", expected=200)
    assert_error(client.get("/auth/me"), 401, "AUTH_TOKEN_INVALID")


@pytest.mark.core
def test_duplicate_username_rejected(anon: ApiClient) -> None:
    response = anon.post(
        "/auth/register",
        json={"username": "user01", "password": "Another@123456"},
    )
    assert_error(response, 409, "USERNAME_EXISTS")


@pytest.mark.core
@pytest.mark.parametrize(
    "payload",
    [
        {"username": "ab", "password": "Demo@123456"},           # 用户名过短
        {"username": "pytest_ok_name", "password": "12345678"},  # 密码缺少字母
        {"username": "pytest_bad_name", "password": "abc"},      # 密码过短
    ],
)
def test_register_validation(anon: ApiClient, payload: dict) -> None:
    assert_error(anon.post("/auth/register", json=payload), 400, "VALIDATION_ERROR")
