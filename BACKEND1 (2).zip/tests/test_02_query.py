﻿"""寄存点、柜体、规格与可用性查询（第一阶段核心）。"""

from __future__ import annotations

import pytest

from tests.api_client import ApiClient, assert_error
from tests.config import at, iso
from tests.conftest import Sandbox


@pytest.mark.core
def test_points_pagination_and_keyword(anon: ApiClient, sandbox: Sandbox) -> None:
    body = anon.get("/points", params={"page": 1, "page_size": 100}, expected=200).json()
    assert body["page"] == 1
    assert body["page_size"] == 100
    assert body["total"] == len(body["items"]) >= 3

    filtered = anon.get(
        "/points", params={"keyword": "pytest 隔离寄存点", "page_size": 100}, expected=200
    ).json()
    codes = [item["code"] for item in filtered["items"]]
    assert sandbox.point_code in codes


@pytest.mark.core
def test_points_page_size_boundary(anon: ApiClient) -> None:
    assert_error(anon.get("/points", params={"page_size": 101}), 400, "VALIDATION_ERROR")


@pytest.mark.core
def test_point_detail_counts(anon: ApiClient) -> None:
    body = anon.get("/points/1", expected=200).json()
    assert body["code"] == "SP001"
    assert body["status"] == "OPEN"
    # 种子数据：A 组 12 个柜格 + B 组 8 个柜格
    assert body["group_count"] == 2
    assert body["cabinet_count"] == 20


@pytest.mark.core
def test_point_groups(anon: ApiClient) -> None:
    groups = anon.get("/points/1/groups", expected=200).json()
    assert len(groups) == 2
    by_code = {group["code"]: group for group in groups}
    assert by_code["A"]["cabinet_count"] == 12
    assert by_code["B"]["cabinet_count"] == 8
    assert all(group["status"] == "NORMAL" for group in groups)


@pytest.mark.core
def test_cabinet_types_cover_three_sizes(anon: ApiClient) -> None:
    types = anon.get("/cabinet-types", expected=200).json()
    codes = {item["code"] for item in types}
    assert {"S", "M", "L"} <= codes
    for item in types:
        assert item["slot_minutes"] == 30
        assert float(item["price_per_slot"]) > 0


@pytest.mark.core
def test_availability_all_test_cabinets_free(anon: ApiClient, sandbox: Sandbox) -> None:
    start, end = at(6, 10), at(6, 11)
    body = anon.get(
        "/cabinets/availability",
        params={
            "point_id": sandbox.point_id,
            "start_time": iso(start),
            "end_time": iso(end),
        },
        expected=200,
    ).json()
    assert body["slot_count"] == 2
    assert body["luggage_size"] is None
    assert len(body["groups"]) == 1

    group = body["groups"][0]
    assert group["group_id"] == sandbox.group_id
    assert len(group["types"]) == 1
    type_slot = group["types"][0]
    assert type_slot["type_id"] == sandbox.type_s_id
    assert type_slot["total_count"] == 6
    assert type_slot["available_count"] == 6
    assert len(type_slot["cabinets"]) == 6


@pytest.mark.core
def test_availability_filters_by_luggage_size(anon: ApiClient, sandbox: Sandbox) -> None:
    start, end = at(6, 11), at(6, 12)
    body = anon.get(
        "/cabinets/availability",
        params={
            "point_id": sandbox.point_id,
            "start_time": iso(start),
            "end_time": iso(end),
            "luggage_size": "LARGE",
        },
        expected=200,
    ).json()
    type_slot = body["groups"][0]["types"][0]
    assert body["luggage_size"] == "LARGE"
    assert type_slot["total_count"] == 6
    assert type_slot["available_count"] == 0  # S 柜格放不下 LARGE


@pytest.mark.core
@pytest.mark.parametrize(
    ("start_hour", "start_minute", "end_hour", "end_minute", "expected_code"),
    [
        (12, 0, 12, 45, "TIME_NOT_ALIGNED"),
        (12, 15, 13, 0, "TIME_NOT_ALIGNED"),
        (12, 0, 12, 0, "DURATION_OUT_OF_RANGE"),
    ],
)
def test_availability_rejects_bad_window(
    anon: ApiClient,
    sandbox: Sandbox,
    start_hour: int,
    start_minute: int,
    end_hour: int,
    end_minute: int,
    expected_code: str,
) -> None:
    response = anon.get(
        "/cabinets/availability",
        params={
            "point_id": sandbox.point_id,
            "start_time": iso(at(6, start_hour, start_minute)),
            "end_time": iso(at(6, end_hour, end_minute)),
        },
    )
    assert_error(response, 400, expected_code)


@pytest.mark.core
def test_cabinet_availability_detail(anon: ApiClient, sandbox: Sandbox) -> None:
    cabinet = sandbox.cabinets[0]
    body = anon.get(
        f"/cabinets/{cabinet.id}/availability",
        params={"start_time": iso(at(6, 13)), "end_time": iso(at(6, 14))},
        expected=200,
    ).json()
    assert body["cabinet_id"] == cabinet.id
    assert body["code"] == cabinet.code
    assert body["physical_status"] == "AVAILABLE"
    assert body["available"] is True
    assert body["reason"] is None
    assert body["conflicts"] == []


@pytest.mark.core
def test_cabinet_availability_not_found(anon: ApiClient) -> None:
    response = anon.get(
        "/cabinets/999999/availability",
        params={"start_time": iso(at(6, 13)), "end_time": iso(at(6, 14))},
    )
    assert_error(response, 404, "RESOURCE_NOT_FOUND")
