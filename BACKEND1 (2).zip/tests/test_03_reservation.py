"""预约创建、冲突、边界与幂等（第一阶段核心）。"""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

import pytest

from tests.api_client import ApiClient, assert_error
from tests.config import at, iso, unique_key
from tests.db import cabinet_by_code, count_slots_in_window, order_row, slot_count, slot_starts, status_transitions
from tests.factories import booking_payload


@pytest.mark.core
@pytest.mark.db
def test_create_reservation_persists_order_and_slots(book, user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    key = unique_key("pytest-create")
    response = book(slot, key=key)
    body = response.json()

    assert body["status"] == "RESERVED"
    assert body["idempotent_replay"] is False
    assert body["cabinet_id"] == slot.cabinet_id
    assert body["cabinet_code"] == slot.cabinet_code
    assert body["slot_count"] == 2
    assert body["luggage_size"] == "SMALL"
    assert body["luggage_count"] == 1
    assert Decimal(body["unit_price"]) == Decimal("1.00")
    assert Decimal(body["amount"]) == Decimal(body["unit_price"]) * body["slot_count"]
    assert datetime.fromisoformat(body["start_time"]) == slot.start
    assert datetime.fromisoformat(body["end_time"]) == slot.end
    assert datetime.fromisoformat(body["checkin_deadline"]) == slot.start + timedelta(minutes=30)

    row = order_row(body["order_no"])
    assert row is not None
    assert row["status"] == "RESERVED"
    assert row["user_id"] == user_api_body_id(user_api)
    assert row["idempotency_key"] == key
    assert row["start_time"] == slot.start and row["end_time"] == slot.end

    assert slot_count(body["order_no"]) == 2
    assert slot_starts(body["order_no"]) == [slot.start, slot.start + timedelta(minutes=30)]

    logs = status_transitions(body["order_no"])
    assert [(log["from_status"], log["to_status"], log["operator_type"]) for log in logs] == [
        (None, "RESERVED", "USER")
    ]


def user_api_body_id(client: ApiClient) -> int:
    return client.get("/auth/me", expected=200).json()["id"]


@pytest.mark.core
def test_adjacent_window_is_not_a_conflict(book, slot_factory) -> None:
    slot = slot_factory()
    assert book(slot).status_code == 201
    adjacent = slot.shifted(60)
    response = book(adjacent)
    assert response.status_code == 201
    assert response.json()["cabinet_id"] == slot.cabinet_id


@pytest.mark.core
@pytest.mark.db
def test_overlapping_window_rejected_and_not_persisted(book, user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    first = book(slot)
    order_no = first.json()["order_no"]

    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, slot.start, slot.end, key=unique_key()),
    )
    assert_error(response, 409, "CABINET_TIME_CONFLICT")

    # 冲突请求不能留下任何时段占用
    assert count_slots_in_window(slot.cabinet_id, slot.start, slot.end) == 2
    assert slot_count(order_no) == 2


@pytest.mark.core
def test_partial_overlap_rejected(book, user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    assert book(slot).status_code == 201

    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, slot.shifted(30).start, slot.shifted(30).end, key=unique_key()),
    )
    assert_error(response, 409, "CABINET_TIME_CONFLICT")


@pytest.mark.core
@pytest.mark.db
def test_conflict_releases_nothing_and_second_attempt_succeeds_after_cancel(
    book, user_api: ApiClient, slot_factory
) -> None:
    slot = slot_factory()
    first = book(slot)
    order_no = first.json()["order_no"]

    conflict = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, slot.start, slot.end, key=unique_key()),
    )
    assert_error(conflict, 409, "CABINET_TIME_CONFLICT")

    assert user_api.post(f"/reservations/{order_no}/cancel", json={}, expected=200).status_code == 200
    assert slot_count(order_no) == 0

    retry = book(slot)
    assert retry.status_code == 201
    assert retry.json()["order_no"] != order_no


@pytest.mark.core
@pytest.mark.parametrize(
    ("mutate", "expected_code"),
    [
        (lambda payload: payload.update(luggage_count=2), "MULTI_LUGGAGE_NOT_SUPPORTED"),
        (lambda payload: payload.update(luggage_count=0), "MULTI_LUGGAGE_NOT_SUPPORTED"),
        (lambda payload: payload.update(luggage_size="LARGE"), "SIZE_NOT_MATCH"),
        (lambda payload: payload.update(idempotency_key="short12"), "VALIDATION_ERROR"),
    ],
)
def test_create_validation_rules(user_api: ApiClient, slot_factory, mutate, expected_code: str) -> None:
    slot = slot_factory()
    payload = booking_payload(slot.cabinet_id, slot.start, slot.end)
    mutate(payload)
    response = user_api.post("/reservations", json=payload)
    assert_error(response, 400, expected_code)


@pytest.mark.core
def test_create_rejects_past_time(user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    start = at(-2, 10)
    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, start, start + timedelta(hours=1)),
    )
    assert_error(response, 400, "TIME_IN_PAST")


@pytest.mark.core
def test_create_rejects_beyond_booking_window(user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    start = at(8, 10)
    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, start, start + timedelta(hours=1)),
    )
    assert_error(response, 400, "BOOKING_WINDOW_EXCEEDED")


@pytest.mark.core
def test_create_rejects_end_not_after_start(user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, slot.start, slot.start),
    )
    assert_error(response, 400, "DURATION_OUT_OF_RANGE")


@pytest.mark.core
def test_create_rejects_nonexistent_cabinet(user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    response = user_api.post(
        "/reservations",
        json=booking_payload(999999, slot.start, slot.end),
    )
    assert_error(response, 404, "RESOURCE_NOT_FOUND")


@pytest.mark.core
def test_create_rejects_maintenance_cabinet(user_api: ApiClient, slot_factory) -> None:
    cabinet = cabinet_by_code("A-12")
    assert cabinet is not None and cabinet["physical_status"] == "MAINTENANCE"
    slot = slot_factory()
    response = user_api.post(
        "/reservations",
        json=booking_payload(cabinet["id"], slot.start, slot.end),
    )
    assert_error(response, 409, "CABINET_NOT_AVAILABLE")


@pytest.mark.core
@pytest.mark.db
def test_full_day_boundary_144_slots(book, user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    full_day = slot.extended(144)
    response = book(full_day)
    body = response.json()

    assert body["slot_count"] == 144
    assert slot_count(body["order_no"]) == 144
    assert slot_starts(body["order_no"])[0] == slot.start
    assert slot_starts(body["order_no"])[-1] == slot.start + timedelta(minutes=30 * 143)

    cancel = user_api.post(f"/reservations/{body['order_no']}/cancel", json={}, expected=200).json()
    assert cancel["released_slot_count"] == 144
    assert slot_count(body["order_no"]) == 0


@pytest.mark.core
def test_duration_over_144_slots_rejected(user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    oversized = slot.extended(145)
    response = user_api.post(
        "/reservations",
        json=booking_payload(slot.cabinet_id, oversized.start, oversized.end),
    )
    assert_error(response, 400, "DURATION_OUT_OF_RANGE")


@pytest.mark.core
@pytest.mark.db
def test_idempotent_replay_returns_same_order(book, slot_factory) -> None:
    slot = slot_factory()
    key = unique_key("pytest-idem")
    first = book(slot, key=key)
    assert first.status_code == 201
    first_body = first.json()
    assert first_body["idempotent_replay"] is False

    second = book(slot, key=key, expected=200)
    second_body = second.json()
    assert second_body["idempotent_replay"] is True
    assert second_body["order_no"] == first_body["order_no"]

    from tests.db import reservations_by_key

    rows = reservations_by_key(key)
    assert len(rows) == 1
    assert slot_count(first_body["order_no"]) == 2


@pytest.mark.core
def test_cabinet_availability_reports_conflict_after_booking(book, anon: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    assert book(slot).status_code == 201

    body = anon.get(
        f"/cabinets/{slot.cabinet_id}/availability",
        params={"start_time": iso(slot.start), "end_time": iso(slot.end)},
        expected=200,
    ).json()
    assert body["available"] is False
    assert body["conflicts"]
    assert body["conflicts"][0]["start_time"]
