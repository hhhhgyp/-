"""订单状态流转、取消窗口、签到/取件与权限（第二阶段扩展）。"""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from tests.api_client import ApiClient, assert_error
from tests.config import at
from tests.conftest import Sandbox, Slot
from tests.db import order_row, slot_count, status_transitions


@pytest.mark.extended
@pytest.mark.db
def test_cancel_releases_slots_and_writes_logs(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    assert slot_count(order_no) == 2

    body = user_api.post(f"/reservations/{order_no}/cancel", json={"reason": "行程变更"}, expected=200).json()
    assert body["status"] == "CANCELLED"
    assert body["released_slot_count"] == 2
    assert slot_count(order_no) == 0

    row = order_row(order_no)
    assert row["status"] == "CANCELLED"
    assert row["cancelled_at"] is not None
    assert row["cancel_reason"] == "行程变更"

    logs = status_transitions(order_no)
    assert [(log["from_status"], log["to_status"], log["operator_type"]) for log in logs] == [
        (None, "RESERVED", "USER"),
        ("RESERVED", "CANCELLED", "USER"),
    ]

    detail = user_api.get(f"/reservations/{order_no}", expected=200).json()
    assert detail["status"] == "CANCELLED"
    assert detail["can_cancel"] is False
    assert detail["status_logs"][-1]["to_status"] == "CANCELLED"


@pytest.mark.extended
def test_repeat_cancel_rejected(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    user_api.post(f"/reservations/{order_no}/cancel", json={}, expected=200)
    assert_error(user_api.post(f"/reservations/{order_no}/cancel", json={}), 409, "ORDER_STATUS_NOT_ALLOWED")


@pytest.mark.extended
def test_checkin_too_early_rejected(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    response = user_api.post(f"/reservations/{order_no}/check-in")
    assert_error(response, 409, "CHECKIN_WINDOW_INVALID")
    assert order_row(order_no)["status"] == "RESERVED"


@pytest.mark.extended
def test_complete_before_checkin_rejected(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    assert_error(user_api.post(f"/reservations/{order_no}/complete"), 409, "ORDER_STATUS_NOT_ALLOWED")


@pytest.mark.extended
@pytest.mark.db
def test_checkin_and_complete_lifecycle(book, user_api: ApiClient, slot_factory, config_override) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    config_override("checkin_early_minutes", 10080)

    checkin = user_api.post(f"/reservations/{order_no}/check-in", expected=200).json()
    assert checkin["status"] == "IN_USE"
    assert checkin["checked_in_at"]
    row = order_row(order_no)
    assert row["status"] == "IN_USE"
    assert row["checked_in_at"] is not None
    assert slot_count(order_no) == 2  # 使用中仍占用时段

    complete = user_api.post(f"/reservations/{order_no}/complete", expected=200).json()
    assert complete["status"] == "COMPLETED"
    assert complete["released_slot_count"] == 2
    assert slot_count(order_no) == 0

    logs = status_transitions(order_no)
    assert [(log["from_status"], log["to_status"], log["operator_type"]) for log in logs] == [
        (None, "RESERVED", "USER"),
        ("RESERVED", "IN_USE", "USER"),
        ("IN_USE", "COMPLETED", "USER"),
    ]


@pytest.mark.extended
@pytest.mark.db
def test_checkin_after_cancel_rejected(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    user_api.post(f"/reservations/{order_no}/cancel", json={}, expected=200)
    assert_error(user_api.post(f"/reservations/{order_no}/check-in"), 409, "ORDER_STATUS_NOT_ALLOWED")


@pytest.mark.extended
@pytest.mark.db
def test_admin_force_cancel_in_use_order(
    admin: ApiClient, book, user_api: ApiClient, slot_factory, config_override
) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    config_override("checkin_early_minutes", 10080)
    user_api.post(f"/reservations/{order_no}/check-in", expected=200)

    reason = "pytest 强制取消：柜体故障"
    body = admin.post(
        f"/admin/reservations/{order_no}/force-cancel", json={"reason": reason}, expected=200
    ).json()
    assert body["status"] == "FORCE_CANCELLED"
    assert body["released_slot_count"] == 2

    row = order_row(order_no)
    assert row["status"] == "FORCE_CANCELLED"
    assert row["cancel_reason"] == reason
    assert slot_count(order_no) == 0

    logs = status_transitions(order_no)
    assert logs[-1]["from_status"] == "IN_USE"
    assert logs[-1]["to_status"] == "FORCE_CANCELLED"
    assert logs[-1]["operator_type"] == "ADMIN"
    assert logs[-1]["remark"] == reason


@pytest.mark.extended
def test_force_cancel_requires_reason(admin: ApiClient, book, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    assert_error(
        admin.post(f"/admin/reservations/{order_no}/force-cancel", json={}), 400, "VALIDATION_ERROR"
    )
    assert_error(
        admin.post(
            f"/admin/reservations/{order_no}/force-cancel", json={"reason": "x" * 129}
        ),
        400,
        "VALIDATION_ERROR",
    )


@pytest.mark.extended
def test_force_cancel_terminal_order_rejected(admin: ApiClient, book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    user_api.post(f"/reservations/{order_no}/cancel", json={}, expected=200)
    assert_error(
        admin.post(
            f"/admin/reservations/{order_no}/force-cancel", json={"reason": "重复操作"}
        ),
        409,
        "ORDER_STATUS_NOT_ALLOWED",
    )


@pytest.mark.extended
@pytest.mark.db
def test_cancel_window_expired_blocks_cancel(
    book, user_api: ApiClient, sandbox: Sandbox, config_override
) -> None:
    slot = Slot(
        cabinet_id=sandbox.cabinets[0].id,
        cabinet_code=sandbox.cabinets[0].code,
        start=at(1, 10),
        end=at(1, 11),
    )
    order_no = book(slot).json()["order_no"]
    # 把取消截止时间放大到 48 小时，D+1 的订单已经进入不可取消窗口
    config_override("cancel_ahead_minutes", 2880)
    assert_error(
        user_api.post(f"/reservations/{order_no}/cancel", json={}), 409, "CANCEL_WINDOW_EXPIRED"
    )
    assert order_row(order_no)["status"] == "RESERVED"


@pytest.mark.extended
@pytest.mark.db
def test_order_visible_only_to_owner(
    book, user_api: ApiClient, user2_api: ApiClient, slot_factory
) -> None:
    order_no = book(slot_factory()).json()["order_no"]

    assert_error(user2_api.get(f"/reservations/{order_no}"), 403, "AUTH_FORBIDDEN")
    assert_error(user2_api.post(f"/reservations/{order_no}/cancel", json={}), 403, "AUTH_FORBIDDEN")

    other_list = user2_api.get("/reservations/my", params={"page_size": 100}, expected=200).json()
    assert order_no not in [item["order_no"] for item in other_list["items"]]

    detail = user_api.get(f"/reservations/{order_no}", expected=200).json()
    assert detail["order_no"] == order_no


@pytest.mark.extended
def test_order_not_found(user_api: ApiClient) -> None:
    assert_error(user_api.get("/reservations/LZ-NOT-EXIST"), 404, "RESOURCE_NOT_FOUND")


@pytest.mark.extended
def test_my_orders_status_filter(book, user_api: ApiClient, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]

    reserved = user_api.get(
        "/reservations/my", params={"status": "RESERVED", "page_size": 100}, expected=200
    ).json()
    assert order_no in [item["order_no"] for item in reserved["items"]]
    assert all(item["status"] == "RESERVED" for item in reserved["items"])

    user_api.post(f"/reservations/{order_no}/cancel", json={}, expected=200)
    cancelled = user_api.get(
        "/reservations/my", params={"status": "CANCELLED", "page_size": 100}, expected=200
    ).json()
    assert order_no in [item["order_no"] for item in cancelled["items"]]

    reserved_after = user_api.get(
        "/reservations/my", params={"status": "RESERVED", "page_size": 100}, expected=200
    ).json()
    assert order_no not in [item["order_no"] for item in reserved_after["items"]]


@pytest.mark.extended
def test_reservation_detail_has_checkin_deadline(book, user_api: ApiClient, slot_factory) -> None:
    slot = slot_factory()
    order_no = book(slot).json()["order_no"]
    detail = user_api.get(f"/reservations/{order_no}", expected=200).json()
    deadline = datetime.fromisoformat(detail["checkin_deadline"])
    assert deadline == slot.start + timedelta(minutes=30)
