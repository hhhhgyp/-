﻿"""管理端权限、全量查询、统计、定时任务与系统配置（第二阶段扩展）。"""

from __future__ import annotations

import pytest

from tests.api_client import ApiClient, assert_error
from tests.conftest import Sandbox


@pytest.mark.extended
def test_admin_group_cabinets(admin: ApiClient, sandbox: Sandbox) -> None:
    body = admin.get(f"/admin/groups/{sandbox.group_id}/cabinets", expected=200).json()
    assert body["group_id"] == sandbox.group_id
    assert body["point_id"] == sandbox.point_id
    assert body["cabinet_count"] == 6
    assert len(body["items"]) == 6
    codes = {item["code"] for item in body["items"]}
    assert codes == {cabinet.code for cabinet in sandbox.cabinets}


@pytest.mark.extended
def test_admin_batch_create_is_all_or_nothing(admin: ApiClient, sandbox: Sandbox) -> None:
    # 已存在的编号：M6 必须整批拒绝，不能只写入一部分
    response = admin.post(
        f"/admin/groups/{sandbox.group_id}/cabinets",
        json={"prefix": sandbox.cabinet_prefix, "count": 1, "type_id": sandbox.type_s_id, "start_index": 1},
    )
    assert_error(response, 409, "DUPLICATE_CODE")
    assert len(admin.get(f"/admin/groups/{sandbox.group_id}/cabinets", expected=200).json()["items"]) == 6


@pytest.mark.extended
def test_admin_reservations_query_by_order_no(admin: ApiClient, book, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]

    body = admin.get(
        "/admin/reservations", params={"order_no": order_no, "page_size": 20}, expected=200
    ).json()
    assert body["total"] == 1
    item = body["items"][0]
    assert item["order_no"] == order_no
    assert item["username"] == "user01"
    assert item["can_force_cancel"] is True


@pytest.mark.extended
def test_admin_reservations_query_by_username_and_status(admin: ApiClient, book, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]

    body = admin.get(
        "/admin/reservations",
        params={"username": "user01", "status": "RESERVED", "page_size": 100},
        expected=200,
    ).json()
    assert order_no in [item["order_no"] for item in body["items"]]
    assert all(item["status"] == "RESERVED" for item in body["items"])


@pytest.mark.extended
def test_admin_stats_relationships(admin: ApiClient, book, slot_factory) -> None:
    order_no = book(slot_factory()).json()["order_no"]
    body = admin.get("/admin/stats/overview", expected=200).json()

    assert body["point_count"] >= 3          # 种子 2 个 + pytest 隔离点
    assert body["cabinet_count"] >= 26       # 种子 20 个 + pytest 6 个
    assert body["active_order_count"] >= 1
    assert body["today_order_count"] >= 1
    assert body["occupancy_numerator"] <= body["occupancy_denominator"]
    assert body["as_of"]

    detail = admin.get("/admin/reservations", params={"order_no": order_no}, expected=200).json()
    assert detail["total"] == 1


@pytest.mark.extended
def test_admin_job_run_and_logs(admin: ApiClient) -> None:
    first = admin.post("/admin/jobs/release-expired/run", expected=200).json()
    assert first["job_name"] == "release_expired_reservations"
    assert first["trigger_type"] == "MANUAL"
    assert first["result"] == "SUCCESS"
    assert first["failed_count"] == 0

    second = admin.post("/admin/jobs/release-expired/run", expected=200).json()
    assert second["result"] == "SUCCESS"
    assert second["affected_count"] == 0  # 同一秒内重复执行必须幂等

    logs = admin.get(
        "/admin/jobs/logs", params={"job_name": "release_expired_reservations", "page_size": 20}, expected=200
    ).json()
    assert logs["total"] >= 2
    assert logs["items"][0]["job_name"] == "release_expired_reservations"
    assert logs["items"][0]["result"] == "SUCCESS"


@pytest.mark.extended
def test_admin_configs_contract(admin: ApiClient) -> None:
    configs = admin.get("/admin/configs", expected=200).json()
    by_key = {item["key"]: item for item in configs}
    assert {"cancel_ahead_minutes", "checkin_early_minutes", "max_slot_count"} <= set(by_key)

    slot = by_key["max_slot_count"]
    assert slot["value_type"] == "int"
    assert slot["min_value"] is not None and slot["max_value"] is not None
    assert slot["default_value"] == "144"


@pytest.mark.extended
@pytest.mark.parametrize(
    ("key", "value", "status", "code"),
    [
        ("not_exist_key", "1", 404, "RESOURCE_NOT_FOUND"),
        ("max_slot_count", "0", 400, "VALIDATION_ERROR"),
        ("max_slot_count", "abc", 400, "VALIDATION_ERROR"),
        ("cancel_ahead_minutes", "999999", 400, "VALIDATION_ERROR"),
    ],
)
def test_admin_config_validation(
    admin: ApiClient, key: str, value: str, status: int, code: str
) -> None:
    assert_error(admin.put(f"/admin/configs/{key}", json={"value": value}), status, code)


@pytest.mark.extended
def test_admin_endpoints_reject_regular_user(user_api: ApiClient) -> None:
    assert_error(user_api.get("/admin/stats/overview"), 403, "AUTH_FORBIDDEN")
    assert_error(user_api.get("/admin/jobs/logs"), 403, "AUTH_FORBIDDEN")
    assert_error(user_api.put("/admin/configs/max_slot_count", json={"value": "144"}), 403, "AUTH_FORBIDDEN")
