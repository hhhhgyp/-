"""真实并发测试：同一柜格抢锁 + 同一幂等键重复提交（第二阶段扩展）。

注意：这是多线程同时打真实 HTTP 接口，不是串行模拟。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from threading import Barrier

import pytest

from tests.api_client import ApiClient
from tests.config import Settings, unique_key
from tests.conftest import Slot
from tests.db import active_order_count, count_slots_in_window, reservations_by_key, slot_count
from tests.factories import booking_payload

THREADS = 8


def _run_concurrently(config: Settings, token: str, payloads: list[dict]) -> list[tuple[int, dict]]:
    barrier = Barrier(len(payloads))

    def worker(payload: dict) -> tuple[int, dict]:
        client = ApiClient(config.base_url, token=token, timeout=30)
        try:
            barrier.wait(timeout=10)
            response = client.post("/reservations", json=payload)
            return response.status_code, response.json()
        finally:
            client.close()

    with ThreadPoolExecutor(max_workers=len(payloads)) as pool:
        return list(pool.map(worker, payloads))


@pytest.mark.extended
@pytest.mark.db
def test_concurrent_booking_same_slot_only_one_wins(
    config: Settings, user_api: ApiClient, order_cleanup, slot_factory
) -> None:
    slot: Slot = slot_factory()
    payloads = [
        booking_payload(slot.cabinet_id, slot.start, slot.end, key=unique_key("pytest-race"))
        for _ in range(THREADS)
    ]

    results = _run_concurrently(config, user_api.token, payloads)
    successes = [body for status, body in results if status == 201]
    conflicts = [body for status, body in results if status == 409]

    assert len(successes) == 1, f"同一柜格同一时段只能成功 1 单，实际 {len(successes)} 单"
    assert len(conflicts) == THREADS - 1
    assert all(body["code"] in {"CABINET_TIME_CONFLICT", "LOCK_TIMEOUT"} for body in conflicts)

    order_no = successes[0]["order_no"]
    order_cleanup.register(order_no)

    # 数据库是最终事实：只有 2 条时段占用、只有 1 个活动订单
    assert slot_count(order_no) == 2
    assert count_slots_in_window(slot.cabinet_id, slot.start, slot.end) == 2
    assert active_order_count(slot.cabinet_id, slot.start, slot.end) == 1


@pytest.mark.extended
@pytest.mark.db
def test_concurrent_duplicate_submit_is_idempotent(
    config: Settings, user_api: ApiClient, order_cleanup, slot_factory
) -> None:
    slot: Slot = slot_factory()
    key = unique_key("pytest-idem-race")
    payload = booking_payload(slot.cabinet_id, slot.start, slot.end, key=key)

    results = _run_concurrently(config, user_api.token, [payload] * THREADS)
    statuses = [status for status, _ in results]
    bodies = [body for _, body in results]

    assert statuses.count(201) == 1, f"首次提交应只有 1 个 201，实际 {statuses}"
    assert statuses.count(200) == THREADS - 1, f"其余应为幂等重放 200，实际 {statuses}"
    order_nos = {body["order_no"] for body in bodies}
    assert len(order_nos) == 1
    assert sum(1 for body in bodies if body["idempotent_replay"] is False) == 1
    assert sum(1 for body in bodies if body["idempotent_replay"] is True) == THREADS - 1

    order_no = order_nos.pop()
    order_cleanup.register(order_no)
    rows = reservations_by_key(key)
    assert len(rows) == 1
    assert slot_count(order_no) == 2
