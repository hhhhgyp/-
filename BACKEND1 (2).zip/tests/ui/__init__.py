"""Selenium UI 自动化：页面对象 + pytest fixtures + 失败截图。"""
