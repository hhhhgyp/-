"""Selenium fixtures：浏览器、显式等待、失败截图/日志。

运行前必须已经有可访问的前端（默认 http://127.0.0.1:8138）。
"""

from __future__ import annotations

import base64
import logging

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.edge.options import Options as EdgeOptions

from tests.config import Settings
from tests.ui.pages.login_page import LoginPage
from tests.ui.pages.my_orders_page import MyOrdersPage
from tests.ui.pages.order_detail_page import OrderDetailPage
from tests.ui.pages.point_detail_page import PointDetailPage
from tests.ui.pages.points_page import PointsPage
from tests.ui.pages.reserve_page import ReservePage
from tests.ui.support import LOG_DIR, ensure_dirs, save_page_source, save_screenshot

LOGGER = logging.getLogger("ui")


def _configure_logging() -> None:
    ensure_dirs()
    if LOGGER.handlers:
        return
    LOGGER.setLevel(logging.INFO)
    LOGGER.propagate = False
    handler = logging.FileHandler(LOG_DIR / "ui.log", encoding="utf-8")
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S")
    )
    LOGGER.addHandler(handler)


@pytest.fixture(scope="session", autouse=True)
def _ui_logging() -> None:
    _configure_logging()


@pytest.fixture(scope="session")
def ui_base_url(config: Settings) -> str:
    return config.ui_base_url.rstrip("/")


@pytest.fixture
def driver(config: Settings):
    """每个用例一个独立浏览器上下文，避免 localStorage / 登录态互相污染。"""
    browser = config.browser.lower()
    if browser == "edge":
        options = EdgeOptions()
    elif browser == "chrome":
        options = ChromeOptions()
    else:
        raise pytest.UsageError(f"不支持的 TEST_BROWSER={config.browser!r}，可选 chrome / edge")

    if config.headless:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1440,1000")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-notifications")
    options.add_argument("--lang=zh-CN")
    if browser == "chrome":
        options.set_capability("goog:loggingPrefs", {"browser": "ALL"})
        drv = webdriver.Chrome(options=options)
    else:
        drv = webdriver.Edge(options=options)

    drv.set_page_load_timeout(40)
    drv.implicitly_wait(0)  # 全部走显式等待，避免隐式等待掩盖问题
    LOGGER.info("BROWSER START browser=%s headless=%s", browser, config.headless)
    try:
        yield drv
    finally:
        try:
            drv.quit()
        finally:
            LOGGER.info("BROWSER QUIT")


@pytest.fixture
def login_page(driver, ui_base_url: str, config: Settings) -> LoginPage:
    return LoginPage(driver, ui_base_url, timeout=config.ui_timeout)


@pytest.fixture
def points_page(driver, ui_base_url: str, config: Settings) -> PointsPage:
    return PointsPage(driver, ui_base_url, timeout=config.ui_timeout)


@pytest.fixture
def point_page(driver, ui_base_url: str, config: Settings) -> PointDetailPage:
    return PointDetailPage(driver, ui_base_url, timeout=config.ui_timeout)


@pytest.fixture
def reserve_page(driver, ui_base_url: str, config: Settings) -> ReservePage:
    return ReservePage(driver, ui_base_url, timeout=config.ui_timeout)


@pytest.fixture
def orders_page(driver, ui_base_url: str, config: Settings) -> MyOrdersPage:
    return MyOrdersPage(driver, ui_base_url, timeout=config.ui_timeout)


@pytest.fixture
def order_page(driver, ui_base_url: str, config: Settings) -> OrderDetailPage:
    return OrderDetailPage(driver, ui_base_url, timeout=config.ui_timeout)


# ---------------------------------------------------------------------------
# 失败证据：截图 + 页面源码 + 浏览器 console
# ---------------------------------------------------------------------------
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    setattr(item, f"rep_{report.when}", report)

    if report.when != "call" or not report.failed:
        return

    drv = getattr(item, "funcargs", {}).get("driver")
    if drv is None:
        return

    test_name = item.nodeid.replace("::", "_")
    try:
        screenshot = save_screenshot(drv, test_name)
        source = save_page_source(drv, test_name)
        LOGGER.error("FAILED %s url=%s title=%s", item.nodeid, drv.current_url, drv.title)
        LOGGER.error("SCREENSHOT %s", screenshot)
        LOGGER.error("PAGE_SOURCE %s", source)
        try:
            console = drv.get_log("browser")
        except Exception:  # noqa: BLE001 - Edge / 非 Chromium 没有 browser log
            console = []
        for entry in console[-30:]:
            LOGGER.error("BROWSER_LOG %s", entry.get("message", entry))

        try:
            from pytest_html import extras

            encoded = base64.b64encode(screenshot.read_bytes()).decode("ascii")
            report.extras = getattr(report, "extras", []) + [
                extras.png(encoded, "失败截图")
            ]
        except Exception:  # noqa: BLE001 - 未安装 pytest-html 时不影响测试
            pass
    except Exception as exc:  # noqa: BLE001 - 截取证据失败不能覆盖原始失败
        LOGGER.error("CAPTURE_FAILED %s", exc)
