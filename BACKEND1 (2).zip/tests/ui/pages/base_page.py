"""所有 Page Object 的基类：显式等待 + 稳定动作封装。"""

from __future__ import annotations

import logging
from typing import Iterable

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

LOGGER = logging.getLogger("ui")
Locator = tuple[str, str]


class BasePage:
    def __init__(self, driver: WebDriver, base_url: str, timeout: float = 15) -> None:
        self.driver = driver
        self.base_url = base_url.rstrip("/")
        self.wait = WebDriverWait(driver, timeout)

    # ------------------------------------------------------------------
    # 导航
    # ------------------------------------------------------------------
    def open(self, path: str) -> None:
        url = self.base_url + (path if path.startswith("/") else "/" + path)
        LOGGER.info("OPEN %s", url)
        self.driver.get(url)

    def wait_url_contains(self, fragment: str) -> None:
        self.wait.until(EC.url_contains(fragment))

    def current_url(self) -> str:
        return self.driver.current_url

    # ------------------------------------------------------------------
    # 元素
    # ------------------------------------------------------------------
    def wait_visible(self, locator: Locator) -> WebElement:
        return self.wait.until(EC.visibility_of_element_located(locator))

    def wait_present(self, locator: Locator) -> WebElement:
        return self.wait.until(EC.presence_of_element_located(locator))

    def wait_clickable(self, locator: Locator) -> WebElement:
        return self.wait.until(EC.element_to_be_clickable(locator))

    def wait_visible_all(self, locator: Locator) -> list[WebElement]:
        return self.wait.until(EC.visibility_of_all_elements_located(locator))

    def click(self, locator: Locator) -> None:
        LOGGER.info("CLICK %s", locator)
        self.wait_clickable(locator).click()

    def fill(self, locator: Locator, text: str) -> None:
        LOGGER.info("TYPE %s <- %r", locator, text)
        element = self.wait_visible(locator)
        element.clear()
        element.send_keys(text)

    def text(self, locator: Locator) -> str:
        return self.wait_visible(locator).text

    def texts(self, locator: Locator) -> list[str]:
        return [element.text for element in self.wait_visible_all(locator)]

    def wait_text_contains(self, locator: Locator, text: str) -> None:
        self.wait.until(EC.text_to_be_present_in_element(locator, text))

    def wait_attribute_contains(self, locator: Locator, attribute: str, value: str) -> None:
        self.wait.until(
            lambda _driver: value in (self.wait_present(locator).get_attribute(attribute) or "")
        )

    # ------------------------------------------------------------------
    # 前端 datetime-local / 下拉框
    # ------------------------------------------------------------------
    def set_datetime_local(self, element_id: str, value: str) -> None:
        """直接写 value 并触发 input/change，避免 send_keys 对 datetime-local 的格式差异。"""
        self.wait_present((By.ID, element_id))
        self.driver.execute_script(
            """
            const el = document.getElementById(arguments[0]);
            el.value = arguments[1];
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            """,
            element_id,
            value,
        )

    def select_value(self, element_id: str, value: str) -> None:
        from selenium.webdriver.support.ui import Select

        Select(self.wait_visible((By.ID, element_id))).select_by_value(value)

    # ------------------------------------------------------------------
    # 断言辅助
    # ------------------------------------------------------------------
    def alert_class(self, alert_id: str = "alert") -> str:
        return self.wait_present((By.ID, alert_id)).get_attribute("class") or ""

    def alert_text(self, alert_id: str = "alert") -> str:
        return self.wait_visible((By.ID, alert_id)).text

    def wait_alert(self, css_class: str, alert_id: str = "alert") -> None:
        self.wait.until(lambda _driver: css_class in self.alert_class(alert_id))

    def exists(self, locator: Locator) -> bool:
        return bool(self.driver.find_elements(*locator))

    def find_all(self, locator: Locator) -> list[WebElement]:
        return list(self.driver.find_elements(*locator))

    @staticmethod
    def by_text(xpath_template: str, values: Iterable[str]) -> list[Locator]:
        return [(By.XPATH, xpath_template.format(value=value)) for value in values]
