"""登录页。"""

from __future__ import annotations

from urllib.parse import quote

from selenium.webdriver.common.by import By

from tests.ui.pages.base_page import BasePage


class LoginPage(BasePage):
    PATH = "/login.html"

    USERNAME = (By.ID, "username")
    PASSWORD = (By.ID, "password")
    SUBMIT = (By.ID, "submit-btn")
    ALERT = (By.ID, "alert")

    def open_for(self, redirect: str = "/index.html") -> None:
        self.open(f"{self.PATH}?redirect={quote(redirect, safe='')}")
        self.wait_visible(self.USERNAME)

    def login(self, username: str, password: str, redirect: str = "/index.html") -> None:
        self.open_for(redirect)
        self.fill(self.USERNAME, username)
        self.fill(self.PASSWORD, password)
        self.click(self.SUBMIT)
        self.wait_url_contains(redirect)

    def login_expect_failure(self, username: str, password: str) -> str:
        self.open_for("/index.html")
        self.fill(self.USERNAME, username)
        self.fill(self.PASSWORD, password)
        self.click(self.SUBMIT)
        self.wait_alert("alert-error")
        return self.alert_text()
