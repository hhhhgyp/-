"""我的订单页。"""

from __future__ import annotations

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from tests.ui.pages.base_page import BasePage


class MyOrdersPage(BasePage):
    PATH = "/my-orders.html"
    LIST = (By.ID, "list-wrap")
    TABLE = (By.CSS_SELECTOR, "#list-wrap table")
    EMPTY = (By.CSS_SELECTOR, "#list-wrap .empty")
    CANCEL_ALERT = (By.ID, "alert")
    STATUS_FILTER = (By.ID, "filter-status")

    def open(self, path: str = PATH) -> None:  # type: ignore[override]
        super().open(path)
        self.wait.until(
            lambda _driver: self.exists(self.TABLE) or self.exists(self.EMPTY)
        )

    @staticmethod
    def row_xpath(order_no: str) -> tuple[str, str]:
        return (
            By.XPATH,
            f"//tr[.//code[normalize-space()='{order_no}']]",
        )

    def row(self, order_no: str) -> WebElement:
        return self.wait_present(self.row_xpath(order_no))

    def status_class(self, order_no: str) -> str:
        return self.row(order_no).find_element(By.CSS_SELECTOR, ".tag").get_attribute("class") or ""

    def wait_status(self, order_no: str, status_class: str) -> None:
        self.wait.until(lambda _driver: status_class in self.status_class(order_no))

    def cancel(self, order_no: str, reason: str = "UI 自动化取消") -> None:
        button = self.row(order_no).find_element(By.CSS_SELECTOR, f"[data-cancel='{order_no}']")
        button.click()

        alert = self.wait.until(lambda driver: driver.switch_to.alert)
        alert.send_keys(reason)
        alert.accept()

        # 页面先 await load() 刷新列表，再 showAlert；两件事都要等到。
        self.wait_alert("alert-success")
        self.wait_status(order_no, "tag-CANCELLED")

    def has_cancel_button(self, order_no: str) -> bool:
        return bool(self.row(order_no).find_elements(By.CSS_SELECTOR, f"[data-cancel='{order_no}']"))

    def order_rows(self) -> list[WebElement]:
        return self.find_all((By.CSS_SELECTOR, "#list-wrap tbody tr"))
