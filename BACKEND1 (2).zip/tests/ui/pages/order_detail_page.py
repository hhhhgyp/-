"""订单详情页。"""

from __future__ import annotations

from selenium.webdriver.common.by import By

from tests.ui.pages.base_page import BasePage


class OrderDetailPage(BasePage):
    DETAIL = (By.ID, "detail-wrap")
    TABLE = (By.CSS_SELECTOR, "#detail-wrap table")
    TIMELINE = (By.ID, "timeline-wrap")
    STATUS_TAG = (By.CSS_SELECTOR, "#detail-wrap .tag")
    CANCEL = (By.ID, "btn-cancel")
    CHECKIN = (By.ID, "btn-checkin")
    PICKUP = (By.ID, "btn-pickup")

    def open(self, order_no: str) -> None:  # type: ignore[override]
        super().open(f"/order.html?order_no={order_no}")
        self.wait_loaded(order_no)

    def wait_loaded(self, order_no: str) -> None:
        self.wait_visible(self.TABLE)
        self.wait_text_contains(self.DETAIL, order_no)

    def status_class(self) -> str:
        return self.wait_visible(self.STATUS_TAG).get_attribute("class") or ""

    def wait_status(self, status_class: str) -> None:
        self.wait.until(lambda _driver: status_class in self.status_class())

    def action_enabled(self, action: str) -> bool:
        locator = {
            "cancel": self.CANCEL,
            "checkin": self.CHECKIN,
            "pickup": self.PICKUP,
        }[action]
        return self.wait_present(locator).is_enabled()

    def timeline_text(self) -> str:
        return self.wait_visible(self.TIMELINE).text

    def reload(self) -> None:
        self.driver.refresh()
        self.wait_visible(self.TABLE)
