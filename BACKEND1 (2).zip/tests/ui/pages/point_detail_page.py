"""寄存点详情 / 可用柜格查询页。"""

from __future__ import annotations

from datetime import datetime

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from tests.ui.pages.base_page import BasePage


class PointDetailPage(BasePage):
    START = (By.ID, "start-time")
    END = (By.ID, "end-time")
    SIZE = (By.ID, "luggage-size")
    QUERY = (By.ID, "btn-query")
    RESULT = (By.ID, "result-wrap")
    RESULT_DESC = (By.CSS_SELECTOR, "#result-wrap .page-desc")
    CHIPS = (By.CSS_SELECTOR, ".cabinet-chip")
    ALERT = (By.ID, "alert")

    def open(self, point_id: int, start: datetime | None = None, end: datetime | None = None, size: str = "") -> None:  # type: ignore[override]
        path = f"/point.html?id={point_id}"
        if start and end:
            path += (
                f"&start={start.strftime('%Y-%m-%dT%H:%M')}"
                f"&end={end.strftime('%Y-%m-%dT%H:%M')}"
            )
        if size:
            path += f"&size={size}"
        super().open(path)
        self.wait_loaded()

    def wait_loaded(self) -> None:
        self.wait.until(
            lambda driver: "加载中"
            not in driver.find_element(By.ID, "point-card").text
        )
        self.wait_visible((By.CSS_SELECTOR, "#point-card .page-title"))
        self.wait.until(
            lambda _driver: self.exists(self.CHIPS) or self.exists((By.CSS_SELECTOR, "#result-wrap .empty"))
        )

    def set_window(self, start: datetime, end: datetime, size: str = "SMALL") -> None:
        self.wait.until(
            lambda _driver: len(
                self.wait_present(self.SIZE).find_elements(By.TAG_NAME, "option")
            )
            > 1
        )
        self.set_datetime_local("start-time", start.strftime("%Y-%m-%dT%H:%M"))
        self.set_datetime_local("end-time", end.strftime("%Y-%m-%dT%H:%M"))
        self.select_value("luggage-size", size)
        self.click(self.QUERY)
        # 结果标题里带接口返回的 start_time，用它确认“新查询已渲染”，而不是等旧 DOM。
        self.wait_text_contains(
            self.RESULT_DESC, start.strftime("%Y-%m-%dT%H:%M")
        )
        self.wait.until(lambda _driver: self.exists(self.CHIPS))

    def chip(self, cabinet_code: str) -> WebElement:
        xpath = (
            "//div[contains(@class,'cabinet-chip')]"
            f"[.//span[contains(@class,'code') and normalize-space()='{cabinet_code}']]"
        )
        return self.wait_present((By.XPATH, xpath))

    def is_available(self, cabinet_code: str) -> bool:
        chip = self.chip(cabinet_code)
        return "is-available" in (chip.get_attribute("class") or "")

    def has_reserve_button(self, cabinet_code: str) -> bool:
        return bool(self.chip(cabinet_code).find_elements(By.CSS_SELECTOR, "button[data-reserve]"))

    def reserve(self, cabinet_code: str) -> None:
        chip = self.chip(cabinet_code)
        button = chip.find_element(By.CSS_SELECTOR, "button[data-reserve]")
        button.click()
        self.wait_url_contains("/reserve.html")

    def click_reserve_expect_login(self, cabinet_code: str) -> None:
        chip = self.chip(cabinet_code)
        button = chip.find_element(By.CSS_SELECTOR, "button[data-reserve]")
        button.click()
        self.wait_url_contains("/login.html")

    def available_codes(self) -> list[str]:
        codes = []
        for chip in self.find_all(self.CHIPS):
            if "is-available" in (chip.get_attribute("class") or ""):
                codes.append(chip.find_element(By.CSS_SELECTOR, ".code").text)
        return codes
