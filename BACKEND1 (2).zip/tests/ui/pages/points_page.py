"""寄存点列表页（首页）。"""

from __future__ import annotations

from selenium.webdriver.common.by import By

from tests.ui.pages.base_page import BasePage


class PointsPage(BasePage):
    PATH = "/index.html"

    KEYWORD = (By.ID, "filter-keyword")
    SEARCH = (By.ID, "btn-search")
    RESET = (By.ID, "btn-reset")
    CARDS = (By.CSS_SELECTOR, ".point-card")
    EMPTY = (By.CSS_SELECTOR, "#list-wrap .empty")
    ALERT = (By.ID, "alert")

    def open(self, path: str = PATH) -> None:  # type: ignore[override]
        super().open(path)
        self.wait.until(
            lambda _driver: self.exists(self.CARDS) or self.exists(self.EMPTY)
        )

    def search(self, keyword: str, expected_cards: int | None = None) -> list[str]:
        self.fill(self.KEYWORD, keyword)
        self.click(self.SEARCH)
        self.wait.until(
            lambda _driver: "加载中" not in self.wait_present((By.ID, "list-wrap")).text
        )
        if expected_cards is not None:
            self.wait.until(lambda _driver: len(self.find_all(self.CARDS)) == expected_cards)
        else:
            self.wait.until(
                lambda _driver: self.exists(self.CARDS) or self.exists(self.EMPTY)
            )
        return self.card_names()

    def card_names(self) -> list[str]:
        return [card.find_element(By.TAG_NAME, "h3").text for card in self.find_all(self.CARDS)]

    def open_point_by_name(self, name: str) -> None:
        card = self.wait.until(
            lambda driver: next(
                (
                    item
                    for item in driver.find_elements(By.CSS_SELECTOR, ".point-card")
                    if name in item.find_element(By.TAG_NAME, "h3").text
                ),
                None,
            )
        )
        link = card.find_element(By.CSS_SELECTOR, "a")
        link.click()
        self.wait_url_contains("/point.html")
