"""确认预约页。"""

from __future__ import annotations

from selenium.webdriver.common.by import By

from tests.ui.pages.base_page import BasePage


class ReservePage(BasePage):
    PREVIEW = (By.CSS_SELECTOR, "#preview table")
    SIZE = (By.ID, "size-select")
    SUBMIT = (By.ID, "btn-submit")
    RESULT = (By.CSS_SELECTOR, "#result .card")
    ORDER_CODE = (By.CSS_SELECTOR, "#result td code")
    ORDER_LINK = (By.CSS_SELECTOR, "#result a[href^='/order.html']")
    ALERT = (By.ID, "alert")

    def wait_ready(self) -> None:
        self.wait_visible(self.PREVIEW)
        self.wait.until(lambda _driver: self.wait_present(self.SUBMIT).is_enabled())

    def submit(self) -> str:
        self.click(self.SUBMIT)
        self.wait.until(
            lambda _driver: self.exists(self.RESULT) or "alert-error" in self.alert_class()
        )
        if "alert-error" in self.alert_class():
            raise AssertionError(f"提交预约失败：{self.alert_text()}")
        order_no = self.wait_visible(self.ORDER_CODE).text.strip()
        assert order_no, "预约成功后页面没有显示订单号"
        return order_no

    def open_order_detail(self) -> None:
        self.click(self.ORDER_LINK)
        self.wait_url_contains("/order.html")
