"""UI 测试公共支持：产物路径、截图、定位器等待。"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from selenium.webdriver.remote.webdriver import WebDriver

ARTIFACTS_DIR = Path(__file__).resolve().parent / "artifacts"
SCREENSHOT_DIR = ARTIFACTS_DIR / "screenshots"
LOG_DIR = ARTIFACTS_DIR / "logs"
SOURCE_DIR = ARTIFACTS_DIR / "page-source"


def ensure_dirs() -> None:
    for path in (SCREENSHOT_DIR, LOG_DIR, SOURCE_DIR):
        path.mkdir(parents=True, exist_ok=True)


def safe_name(value: str, limit: int = 120) -> str:
    value = re.sub(r"[^0-9A-Za-z_.-]+", "_", value)
    return value[:limit].strip("_") or "ui"


def stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def save_screenshot(driver: WebDriver, name: str) -> Path:
    ensure_dirs()
    path = SCREENSHOT_DIR / f"{safe_name(name)}-{stamp()}.png"
    driver.save_screenshot(str(path))
    return path


def save_page_source(driver: WebDriver, name: str) -> Path:
    ensure_dirs()
    path = SOURCE_DIR / f"{safe_name(name)}-{stamp()}.html"
    path.write_text(driver.page_source, encoding="utf-8")
    return path
