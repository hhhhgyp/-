﻿"""UI 核心流程：登录 → 搜索寄存点 → 查柜格 → 创建预约 → 查看订单 → 取消。"""

from __future__ import annotations

import time
from urllib.parse import parse_qs, urlparse

import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from tests.api_client import ApiClient
from tests.config import Settings
from tests.conftest import Sandbox
from tests.db import slot_count
from tests.ui.support import save_screenshot


@pytest.mark.ui
def test_e2e_login_search_book_view_cancel(
    driver,
    config: Settings,
    sandbox: Sandbox,
    slot_factory,
    order_cleanup,
    user_api: ApiClient,
    login_page,
    points_page,
    point_page,
    reserve_page,
    orders_page,
    order_page,
) -> None:
    """一条真实页面链路，全部通过 Selenium 操作，关键结果同时查接口/数据库。"""
    slot = slot_factory()

    # 1) 登录：从带 redirect 的登录页进入首页
    login_page.login(config.username, config.password, "/index.html")
    assert "/index.html" in driver.current_url

    # 2) 首页查询：按测试寄存点名称搜索，只应命中隔离点
    names = points_page.search(sandbox.point_name, expected_cards=1)
    assert len(names) == 1
    assert sandbox.point_name in names[0]

    # 3) 进入寄存点，按指定时段/尺寸查询柜格
    points_page.open_point_by_name(sandbox.point_name)
    point_page.wait_loaded()
    assert sandbox.point_code in point_page.text((By.ID, "point-card"))
    point_page.set_window(slot.start, slot.end, "SMALL")
    assert point_page.has_reserve_button(slot.cabinet_code), "隔离柜格应可预约"

    # 4) 进入确认页并提交预约
    point_page.reserve(slot.cabinet_code)
    reserve_page.wait_ready()
    order_no = reserve_page.submit()
    order_cleanup.register(order_no)

    # 5) 接口 + 数据库核对：页面显示成功不能只信页面
    detail = user_api.get(f"/reservations/{order_no}", expected=200).json()
    assert detail["status"] == "RESERVED"
    assert detail["cabinet_code"] == slot.cabinet_code
    assert detail["slot_count"] == 2
    assert slot_count(order_no) == 2

    # 6) 查看订单详情：状态、取消按钮可用
    reserve_page.open_order_detail()
    order_page.wait_loaded(order_no)
    order_page.wait_status("tag-RESERVED")
    assert order_page.action_enabled("cancel") is True
    assert "创建订单" in order_page.timeline_text() or "已预约" in order_page.timeline_text()
    save_screenshot(driver, f"e2e-order-{order_no}")

    # 7) 我的订单列表：能看到刚创建的单，并从这里取消（含原生 prompt）
    orders_page.open()
    orders_page.wait_status(order_no, "tag-RESERVED")
    assert orders_page.has_cancel_button(order_no) is True
    orders_page.cancel(order_no, "UI 自动化 E2E 取消")

    # 8) 页面最终状态：已取消、取消按钮消失
    assert "tag-CANCELLED" in orders_page.status_class(order_no)
    assert orders_page.has_cancel_button(order_no) is False

    # 9) 详情页刷新后同步显示已取消，取消动作不可用
    order_page.open(order_no)
    order_page.wait_status("tag-CANCELLED")
    assert order_page.action_enabled("cancel") is False
    assert "已取消" in order_page.timeline_text()

    # 10) 数据库：时段占用已释放，状态日志有取消记录
    after = user_api.get(f"/reservations/{order_no}", expected=200).json()
    assert after["status"] == "CANCELLED"
    assert slot_count(order_no) == 0
    save_screenshot(driver, f"e2e-cancelled-{order_no}")


@pytest.mark.ui
def test_login_rejects_wrong_password(login_page, driver) -> None:
    message = login_page.login_expect_failure("user01", "Wrong@123456")
    assert message
    assert "用户名或密码" in message
    assert "/login.html" in driver.current_url


@pytest.mark.ui
def test_point_search_filters_sandbox_point(
    config: Settings, sandbox: Sandbox, login_page, points_page, point_page, driver
) -> None:
    login_page.login(config.username, config.password)
    names = points_page.search(sandbox.point_name, expected_cards=1)
    assert sandbox.point_name in names[0]

    points_page.open_point_by_name(sandbox.point_name)
    point_page.wait_loaded()
    assert sandbox.point_code in point_page.text((By.ID, "point-card"))
    assert "/point.html?id=" in driver.current_url


@pytest.mark.ui
def test_booked_slot_is_not_offered_again(
    config: Settings,
    sandbox: Sandbox,
    slot_factory,
    book,
    login_page,
    point_page,
) -> None:
    slot = slot_factory()
    book(slot)  # 通过接口先占位，模拟“查询后被人抢走”的前置状态

    login_page.login(config.username, config.password)
    point_page.open(sandbox.point_id)
    point_page.set_window(slot.start, slot.end, "SMALL")

    assert point_page.is_available(slot.cabinet_code) is False
    assert point_page.has_reserve_button(slot.cabinet_code) is False

    chip = point_page.chip(slot.cabinet_code)
    tag = chip.find_element(By.CSS_SELECTOR, ".tag")
    assert "tag-RESERVED" in (tag.get_attribute("class") or "")


@pytest.mark.ui
def test_unauthenticated_reserve_redirects_to_login(
    sandbox: Sandbox, slot_factory, point_page, driver
) -> None:
    slot = slot_factory()
    point_page.open(sandbox.point_id)
    point_page.set_window(slot.start, slot.end, "SMALL")
    point_page.click_reserve_expect_login(slot.cabinet_code)

    assert "/login.html" in driver.current_url
    assert "redirect=" in driver.current_url
    assert "reserve.html" in driver.current_url


@pytest.mark.ui
def test_non_admin_guard_redirects_to_login_without_loop(
    config: Settings, login_page, driver, ui_base_url: str
) -> None:
    """D-03 回归：普通用户访问管理端时，应停在登录页并显示“没有管理权限”。

    旧缺陷是管理页 → 登录页 → 管理页的循环，最终浏览器报
    ERR_TOO_MANY_REDIRECTS，用户看不到拒绝原因。本用例按真实页面路径复现并
    检查三件事：最终 URL、denied=1/redirect 参数、提示文案；等待 1 秒后再核对
    URL，确认页面没有继续跳转。
    """
    login_page.login(config.username, config.password, "/index.html")
    assert "/index.html" in driver.current_url

    driver.get(f"{ui_base_url}/admin/index.html")
    login_page.wait_url_contains("/login.html")
    login_page.wait_alert("alert-warning")

    parsed = urlparse(driver.current_url)
    query = parse_qs(parsed.query)
    assert parsed.path.endswith("/login.html")
    assert query.get("denied") == ["1"]
    assert query.get("redirect") == ["/admin/index.html"]

    message = login_page.alert_text()
    assert "没有管理权限" in message
    assert "admin" in message

    first_url = driver.current_url
    time.sleep(1)
    assert driver.current_url == first_url, "登录页不应再次自动跳回管理页"
    assert "/login.html" in driver.current_url
    save_screenshot(driver, "d03-non-admin-denied")

    # 同一页面改用管理员登录，应回到最初请求的管理页（TC-AUTHZ-05 ④）。
    login_page.fill(login_page.USERNAME, config.admin_username)
    login_page.fill(login_page.PASSWORD, config.admin_password)
    login_page.click(login_page.SUBMIT)
    login_page.wait_url_contains("/admin/index.html")
    login_page.wait_present((By.ID, "admin-nav"))
    assert "管理" in driver.title
    save_screenshot(driver, "d03-admin-login-return")


@pytest.mark.ui
def test_non_admin_guard_on_orders_page_stays_denied(
    config: Settings, login_page, driver, ui_base_url: str
) -> None:
    """TC-UI-02：管理端订单页守卫，3 秒后仍停留在拒绝提示页。"""
    login_page.login(config.username, config.password, "/index.html")
    driver.get(f"{ui_base_url}/admin/orders.html")
    login_page.wait_url_contains("/login.html")
    login_page.wait_alert("alert-warning")

    parsed = urlparse(driver.current_url)
    query = parse_qs(parsed.query)
    assert query.get("denied") == ["1"]
    assert query.get("redirect") == ["/admin/orders.html"]
    assert "没有管理权限" in login_page.alert_text()

    denied_url = driver.current_url
    time.sleep(3)
    assert driver.current_url == denied_url
    save_screenshot(driver, "d03-admin-orders-denied")


@pytest.mark.ui
def test_logout_clears_session_and_guards_my_orders(
    config: Settings, login_page, driver, ui_base_url: str
) -> None:
    login_page.login(config.username, config.password)
    driver.find_element(By.ID, "nav-logout").click()
    login_page.wait_url_contains("/login.html")

    driver.get(f"{ui_base_url}/my-orders.html")
    login_page.wait.until(EC.url_contains("/login.html"))
    assert "redirect=" in driver.current_url
