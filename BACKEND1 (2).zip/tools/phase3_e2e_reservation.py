# -*- coding: utf-8 -*-
"""
第三阶段（R1~R4）端到端 + 并发验证。

真实 HTTP + 真实 MySQL。分两部分：
  A. 功能与规则验证（R1 全部错误码、幂等、R2/R3/R4、数据库残留检查）
  B. **真并发验证**：多线程同时抢同一个柜格的同一时段

B 部分是本阶段最关键的验证，它要回答两个问题：
  1. 16 个并发请求抢同一时段，是否**只有 1 个**成功？
  2. 兜底的是应用层的冲突检测，还是数据库的唯一索引？
     （两道防线各自负责哪个场景，与设计方案 5.7 节的判断是否一致）

用法（先启动服务，再执行）：

    cd backend
    .\.venv\Scripts\Activate.ps1
    python run.py --port 8131 --no-reload     # 另开一个窗口

    python tools\phase3_e2e_reservation.py
    # 或者换个端口：
    $env:PHASE3_BASE_URL="http://127.0.0.1:8000/api/v1"
    python tools\phase3_e2e_reservation.py

退出码 0 表示全部用例通过。脚本会自行清理它创建的订单、
以及被临时改动的寄存点/柜体/规格状态与配置项。

【为什么这段脚本要以"真实 HTTP + 真实 MySQL"的方式跑】
本阶段的验证重点不是"函数返回对不对"，而是：
  1. 多线程同时打同一个柜格同一时段时，最终只产生一条订单；
  2. 数据库里的 reservation_slots / reservation_status_logs 与订单状态始终自洽；
  3. 失败请求不留残留数据（BR-32）。
这三点都必须在"进程边界之外"观察才可信，进程内的单元测试无法证明。
"""
from __future__ import annotations

import json
import os
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from typing import Any

sys.path.insert(0, ".")

BASE = os.environ.get("PHASE3_BASE_URL", "http://127.0.0.1:8131/api/v1")
KEY_PREFIX = "e2e3a_"

results: list[tuple[bool, str]] = []


def check(ok: bool, name: str, extra: str = "") -> None:
    results.append((bool(ok), name))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {extra}" if extra else ""))


def call(
    method: str,
    path: str,
    *,
    token: str | None = None,
    body: dict | None = None,
    query: dict | None = None,
) -> tuple[int, Any]:
    url = BASE + path
    if query:
        clean = {k: v for k, v in query.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            return exc.code, (json.loads(raw) if raw else None)
        except json.JSONDecodeError:
            return exc.code, {"raw": raw}


def code_of(payload: Any) -> str | None:
    return payload.get("code") if isinstance(payload, dict) else None


def detail_text(payload: Any) -> str:
    return json.dumps(payload.get("detail") if isinstance(payload, dict) else payload, ensure_ascii=False)


def login(username: str, password: str = "Demo@123456") -> str:
    status, body = call("POST", "/auth/login", body={"username": username, "password": password})
    assert status == 200, f"登录失败 {username}: {status} {body}"
    return body["access_token"]


# ==================================================================
# 数据库夹具
# ==================================================================
class Fixture:
    def __init__(self) -> None:
        from sqlalchemy import text

        from app.db.session import SessionLocal
        from app.models.storage_point import StoragePoint

        self.db = SessionLocal()
        self.restore: list[tuple[str, str, int]] = []  # (what, column, id) -> 见 restore_all

        self._cleanup_residue()

        point = self.db.query(StoragePoint).order_by(StoragePoint.id).first()
        self.point_id = point.id
        self.point_name = point.name
        self.open_time = point.open_time
        self.close_time = point.close_time

        # 找一个"可用 + 小规格"的柜格，和一个"可用 + 大规格"的柜格
        rows = self.db.execute(
            text(
                "SELECT c.id, c.code, c.type_id, t.size_level, t.is_active, c.physical_status "
                "FROM cabinets c JOIN cabinet_types t ON t.id = c.type_id "
                "JOIN cabinet_groups g ON g.id = c.group_id "
                "WHERE c.physical_status = 'AVAILABLE' AND g.status = 'NORMAL' "
                "AND g.point_id = :p AND c.code <> 'A-12' "
                "ORDER BY c.code"
            ),
            {"p": self.point_id},
        ).all()
        self.cab_small = next(r for r in rows if r[3] == "SMALL")
        self.cab_large = next(r for r in rows if r[3] == "LARGE")
        self.cab_maintenance = self.db.execute(
            text("SELECT id, code, type_id FROM cabinets WHERE code = 'A-12'")
        ).first()
        self.group_of_small = self.db.execute(
            text("SELECT group_id FROM cabinets WHERE id = :i"), {"i": self.cab_small[0]}
        ).scalar()

    # ---------- 临时改状态 ----------
    def set_point_status(self, status: str) -> None:
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE storage_points SET status = :s WHERE id = :i"),
            {"s": status, "i": self.point_id},
        )
        self.db.commit()
        self._point_status_restore = status

    def set_group_status(self, group_id: int, status: str) -> None:
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE cabinet_groups SET status = :s WHERE id = :i"),
            {"s": status, "i": group_id},
        )
        self.db.commit()

    def set_type_active(self, type_id: int, active: int) -> None:
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE cabinet_types SET is_active = :a WHERE id = :i"),
            {"a": active, "i": type_id},
        )
        self.db.commit()

    def set_config(self, key: str, value: str) -> None:
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
            {"v": value, "k": key},
        )
        self.db.commit()

    # ---------- 计数 ----------
    def _refresh(self) -> None:
        """
        结束当前只读事务。

        【必须存在的原因】本 Session 与引擎同为 REPEATABLE READ：
        第一次查询就固定了读视图，之后不管服务端提交了多少新数据，
        本 Session 都读不到。不显式结束事务，下面所有计数都会是过期的，
        测试会假绿或假红。这是写这类"旁路校验脚本"最容易踩的坑。
        """
        self.db.commit()

    def count_reservations(self, *, idempotency_like: str | None = None) -> int:
        from sqlalchemy import text

        self._refresh()
        if idempotency_like:
            return int(
                self.db.execute(
                    text("SELECT COUNT(*) FROM reservations WHERE idempotency_key LIKE :p"),
                    {"p": idempotency_like},
                ).scalar()
            )
        return int(self.db.execute(text("SELECT COUNT(*) FROM reservations")).scalar())

    def count_slots(self, order_no: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) FROM reservation_slots rs "
                    "JOIN reservations r ON r.id = rs.reservation_id WHERE r.order_no = :o"
                ),
                {"o": order_no},
            ).scalar()
        )

    def count_logs(self, order_no: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) FROM reservation_status_logs l "
                    "JOIN reservations r ON r.id = l.reservation_id WHERE r.order_no = :o"
                ),
                {"o": order_no},
            ).scalar()
        )

    def fetch_one(self, sql: str, params: dict | None = None):
        """执行一条只读查询（先刷新读视图）。"""
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(text(sql), params or {}).first()

    def fetch_all(self, sql: str, params: dict | None = None):
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(text(sql), params or {}).all()

    # ---------- 清理 ----------
    def _cleanup_residue(self) -> None:
        from sqlalchemy import text

        self._refresh()
        ids = self.db.execute(
            text("SELECT id FROM reservations WHERE idempotency_key LIKE :p"),
            {"p": f"{KEY_PREFIX}%"},
        ).scalars().all()
        for rid in ids:
            self.db.execute(text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid})
            self.db.execute(
                text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"), {"i": rid}
            )
            self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
        self.db.commit()

    def close(self) -> None:
        from sqlalchemy import text

        self._cleanup_residue()
        # 恢复所有被临时改动的状态
        self.db.execute(
            text("UPDATE storage_points SET status = 'OPEN' WHERE id = :i"), {"i": self.point_id}
        )
        self.db.execute(text("UPDATE cabinet_groups SET status = 'NORMAL'"))
        self.db.execute(text("UPDATE cabinet_types SET is_active = 1"))
        self.db.execute(
            text("UPDATE system_config SET config_value = '30' WHERE config_key = 'cancel_ahead_minutes'")
        )
        self.db.commit()
        self.db.close()


# ==================================================================
# 主流程
# ==================================================================
def main() -> int:
    import logging

    logging.disable(logging.CRITICAL)

    fx = Fixture()
    token01 = login("user01")
    token02 = login("user02")

    # 构造窗口：明天营业时间内
    open_dt = datetime.combine(datetime.today().date(), fx.open_time)
    base = (open_dt + timedelta(hours=2)).replace(minute=0, second=0, microsecond=0) + timedelta(days=1)
    assert (base + timedelta(hours=6)).time() <= fx.close_time, "营业时间不足以构造测试窗口"

    def window(offset_hours: float, hours: float = 1.0) -> tuple[str, str]:
        s = base + timedelta(hours=offset_hours)
        e = s + timedelta(hours=hours)
        return s.isoformat(), e.isoformat()

    W1, W2, W3, W4, W5 = (window(0), window(1), window(2), window(4), window(5))
    #: W6 是给并发测试准备的独立时段
    W6 = window(5, 1.0)

    print("=" * 78)
    print("夹具")
    print("=" * 78)
    print(f"  寄存点 : id={fx.point_id} {fx.point_name} 营业 {fx.open_time}~{fx.close_time}")
    print(f"  小规格柜格(可用) : {fx.cab_small[1]} (id={fx.cab_small[0]}, {fx.cab_small[3]})")
    print(f"  大规格柜格(可用) : {fx.cab_large[1]} (id={fx.cab_large[0]}, {fx.cab_large[3]})")
    print(f"  维护中柜格       : {fx.cab_maintenance[1]} (id={fx.cab_maintenance[0]})")
    print(f"  测试时段 base    : {base}")

    cab_small_id = fx.cab_small[0]
    cab_large_id = fx.cab_large[0]
    base_before = fx.count_reservations()

    def create(token: str, cabinet_id: int, w: tuple[str, str], size: str = "SMALL", **extra) -> tuple[int, Any]:
        body = {
            "cabinet_id": cabinet_id,
            "start_time": w[0],
            "end_time": w[1],
            "luggage_size": size,
            "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        }
        body.update(extra)
        return call("POST", "/reservations", token=token, body=body)

    try:
        # ==========================================================
        print()
        print("=" * 78)
        print("A. 认证与鉴权（BR-25）")
        print("=" * 78)
        status, body = call("POST", "/reservations", body={
            "cabinet_id": cab_small_id, "start_time": W4[0], "end_time": W4[1],
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}noauth0000",
        })
        check(status == 401 and code_of(body) == "AUTH_TOKEN_MISSING", "未登录创建预约 -> 401", f"{status}/{code_of(body)}")

        status, body = call("GET", "/reservations/my")
        check(status == 401, "未登录查我的订单 -> 401", f"实际={status}")

        # ==========================================================
        print()
        print("=" * 78)
        print("B. R1 创建预约 —— 正常路径 + 数据库落地验证")
        print("=" * 78)
        key_a = f"{KEY_PREFIX}orderA0000000001"
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_small_id, "start_time": W1[0], "end_time": W1[1],
            "luggage_size": "SMALL", "idempotency_key": key_a,
        })
        check(status == 201, "创建预约返回 201", f"实际={status} {code_of(body)}")
        check(body.get("idempotent_replay") is False, "首次创建 idempotent_replay=false")
        check(body.get("status") == "RESERVED", "订单状态为 RESERVED", f"实际={body.get('status')}")
        order_a = body.get("order_no")
        check(bool(order_a) and len(order_a) == 18 and order_a.startswith("LZ"),
              "订单号格式 LZ+YYYYMMDD+8位十六进制", f"order_no={order_a}")
        check(body.get("slot_count") == 2, "slot_count=2（1 小时 / 30 分钟）", f"实际={body.get('slot_count')}")
        check(float(body.get("amount")) == float(body.get("unit_price")) * 2,
              "amount = unit_price * slot_count", f"amount={body.get('amount')}")
        check(body.get("cabinet_code") == fx.cab_small[1], "柜格编号快照正确")
        check(body.get("point_name") == fx.point_name, "寄存点名称快照正确")
        check(body.get("pay_status") == "UNPAID", "pay_status 为 UNPAID（不伪造已支付）")
        check(body.get("can_cancel") is True, "can_cancel=true")

        check(fx.count_slots(order_a) == 2,
              "数据库 reservation_slots 落库 2 条（BR-30）", f"实际={fx.count_slots(order_a)}")
        check(fx.count_logs(order_a) == 1,
              "数据库 reservation_status_logs 落库 1 条（BR-33）", f"实际={fx.count_logs(order_a)}")

        from sqlalchemy import text
        log_row = fx.fetch_one(
            "SELECT from_status, to_status, operator_type, operator_id "
            "FROM reservation_status_logs l JOIN reservations r ON r.id=l.reservation_id "
            "WHERE r.order_no = :o",
            {"o": order_a},
        )
        check(log_row[0] is None and log_row[1] == "RESERVED" and log_row[2] == "USER" and log_row[3] is not None,
              "状态日志内容正确（from=null, to=RESERVED, operator=USER+id）", f"{log_row}")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("C. R1 幂等（BR-16 / BR-17）")
        print("=" * 78)
        status, body2 = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_small_id, "start_time": W1[0], "end_time": W1[1],
            "luggage_size": "SMALL", "idempotency_key": key_a,
        })
        check(status == 200, "同一幂等键重复提交 -> 200（不是 409）", f"实际={status}")
        check(body2.get("idempotent_replay") is True, "idempotent_replay=true")
        check(body2.get("order_no") == order_a, "返回的是第一次创建的订单", f"{body2.get('order_no')}")
        check(fx.count_reservations(idempotency_like=key_a) == 1,
              "数据库中该幂等键只有 1 条订单", f"实际={fx.count_reservations(idempotency_like=key_a)}")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("D. R1 时段冲突（BR-13 / BR-14 / BR-15）")
        print("=" * 78)
        status, body = create(token01, cab_small_id, W1)
        check(status == 409 and code_of(body) == "CABINET_TIME_CONFLICT",
              "同一柜格同一时段再次预约 -> 409 CABINET_TIME_CONFLICT", f"{status}/{code_of(body)}")
        check("判定条件" in detail_text(body),
              "本次由【应用层冲突检测】拦下（detail 含判定条件说明）")
        check(fx.count_reservations(idempotency_like=f"{KEY_PREFIX}%") == 1,
              "失败请求未留下任何残留订单（BR-32）",
              f"实际={fx.count_reservations(idempotency_like=f'{KEY_PREFIX}%')}")

        # 半重叠
        s = (base + timedelta(minutes=30)).isoformat()
        e = (base + timedelta(minutes=90)).isoformat()
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_small_id, "start_time": s, "end_time": e,
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 409 and code_of(body) == "CABINET_TIME_CONFLICT",
              "半重叠（10:30-11:30 对 10:00-11:00）-> 409", f"{status}/{code_of(body)}")

        # BR-14 相邻
        status, body = create(token01, cab_small_id, W2)
        check(status == 201, "相邻时段 11:00-12:00 可以预约（BR-14 关键边界）",
              f"{status}/{code_of(body)}")
        order_b = body.get("order_no")

        # BR-15 用户对自己的柜格再来一次
        status, body = create(token01, cab_small_id, W2)
        check(status == 409, "用户对同一柜格同一时段的第二次预约 -> 409（BR-15）", f"实际={status}")

        # 另一个用户抢同一时段
        status, body = create(token02, cab_small_id, W1)
        check(status == 409, "另一个用户抢已占用时段 -> 409", f"实际={status}")

        # 另一个用户用另一个柜格
        status, body = create(token02, cab_large_id, W3)
        check(status == 201, "另一个用户预约大柜 -> 201", f"{status}/{code_of(body)}")
        order_c = body.get("order_no")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("E. R1 参数类校验（BR-01~BR-05、BR-07、BR-08、BR-18）")
        print("=" * 78)
        before = fx.count_reservations()

        bad_s = (base + timedelta(hours=4, minutes=15)).isoformat()
        bad_e = (base + timedelta(hours=5)).isoformat()
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": bad_s, "end_time": bad_e,
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "TIME_NOT_ALIGNED", "BR-01 时间未对齐 -> 400", f"{status}/{code_of(body)}")

        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": W4[0], "end_time": W4[0],
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "DURATION_OUT_OF_RANGE", "BR-02 end<=start -> 400", f"{status}/{code_of(body)}")

        past = (base - timedelta(days=2)).isoformat()
        past_e = (base - timedelta(days=2) + timedelta(hours=1)).isoformat()
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": past, "end_time": past_e,
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "TIME_IN_PAST", "BR-03 过去时间 -> 400", f"{status}/{code_of(body)}")

        far = (base + timedelta(days=30)).isoformat()
        far_e = (base + timedelta(days=30, hours=1)).isoformat()
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": far, "end_time": far_e,
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "BOOKING_WINDOW_EXCEEDED", "BR-04 超过 7 天 -> 400", f"{status}/{code_of(body)}")

        from datetime import time as dtime
        night = datetime.combine(base.date(), dtime((fx.open_time.hour - 1) % 24, 0))
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": night.isoformat(),
            "end_time": (night + timedelta(hours=1)).isoformat(),
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "OUT_OF_BUSINESS_HOURS", "BR-05 营业时间外 -> 400", f"{status}/{code_of(body)}")

        status, body = create(token01, fx.cab_small[0], W4, size="LARGE")
        check(status == 400 and code_of(body) == "SIZE_NOT_MATCH",
              "BR-08 小柜放大行李 -> 400 SIZE_NOT_MATCH", f"{status}/{code_of(body)}")

        status, body = create(token01, cab_large_id, W4, size="SMALL", luggage_count=2)
        check(status == 400 and code_of(body) == "MULTI_LUGGAGE_NOT_SUPPORTED",
              "BR-07 luggage_count=2 -> 400 MULTI_LUGGAGE_NOT_SUPPORTED", f"{status}/{code_of(body)}")

        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": W4[0], "end_time": W4[1],
            "luggage_size": "SMALL", "idempotency_key": "short",
        })
        check(status == 400 and code_of(body) == "VALIDATION_ERROR",
              "BR-18 幂等键过短 -> 400 VALIDATION_ERROR", f"{status}/{code_of(body)}")

        status, body = create(token01, 99999999, W4)
        check(status == 404 and code_of(body) == "RESOURCE_NOT_FOUND",
              "不存在的柜格 -> 404", f"{status}/{code_of(body)}")

        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": cab_large_id, "start_time": W4[0], "end_time": W4[1],
            "luggage_size": "HUGE", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 400 and code_of(body) == "VALIDATION_ERROR",
              "BR-06 非法尺寸枚举 -> 400", f"{status}/{code_of(body)}")

        check(fx.count_reservations() == before,
              "以上全部失败请求都没有留下残留数据（BR-32）",
              f"期望{before} 实际{fx.count_reservations()}")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("F. R1 资源状态校验（BR-09 / BR-10 / BR-11 / BR-12）")
        print("=" * 78)
        status, body = call("POST", "/reservations", token=token01, body={
            "cabinet_id": fx.cab_maintenance[0], "start_time": W4[0], "end_time": W4[1],
            "luggage_size": "SMALL", "idempotency_key": f"{KEY_PREFIX}{uuid.uuid4().hex[:16]}",
        })
        check(status == 409 and code_of(body) == "CABINET_NOT_AVAILABLE",
              "BR-09 维护中柜格 -> 409 CABINET_NOT_AVAILABLE", f"{status}/{code_of(body)}")

        status, body = create(token01, cab_small_id, W5, size="MEDIUM")
        check(status == 400 and code_of(body) == "SIZE_NOT_MATCH", "前置确认：小柜放中行李也拒绝")

        # BR-12 规格停用
        fx.set_type_active(fx.cab_large[2], 0)
        status, body = create(token01, cab_large_id, W4)
        check(status == 409 and code_of(body) == "CABINET_TYPE_DISABLED",
              "BR-12 规格停用 -> 409 CABINET_TYPE_DISABLED", f"{status}/{code_of(body)}")
        fx.set_type_active(fx.cab_large[2], 1)

        # BR-10 柜体维护
        fx.set_group_status(fx.group_of_small, "MAINTENANCE")
        status, body = create(token01, cab_small_id, W5)
        check(status == 409 and code_of(body) == "CABINET_NOT_AVAILABLE",
              "BR-10 柜体维护中 -> 409 CABINET_NOT_AVAILABLE", f"{status}/{code_of(body)}")
        fx.set_group_status(fx.group_of_small, "NORMAL")

        # BR-11 寄存点关闭
        fx.set_point_status("CLOSED")
        status, body = create(token01, cab_small_id, W5)
        check(status == 409 and code_of(body) == "POINT_CLOSED",
              "BR-11 寄存点关闭 -> 409 POINT_CLOSED", f"{status}/{code_of(body)}")
        status, q5 = call("GET", "/cabinets/availability", query={
            "point_id": fx.point_id, "start_time": W5[0], "end_time": W5[1],
        })
        check(q5.get("point_id") == fx.point_id and len(q5.get("groups", [])) >= 0,
              "对照：查询接口对关闭寄存点仍返回 200（只有下单才报 409）", f"实际={status}")
        fx.set_point_status("OPEN")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("G. R2 我的订单列表")
        print("=" * 78)
        status, page = call("GET", "/reservations/my", token=token01)
        check(status == 200 and page["total"] >= 2, "返回订单列表", f"total={page.get('total')}")
        check({"items", "total", "page", "page_size"} <= set(page.keys()), "分页结构完整")
        my_orders = {item["order_no"] for item in page["items"]}
        check(order_a in my_orders and order_b in my_orders, "包含自己创建的两条订单")
        check(order_c not in my_orders, "不包含其他用户的订单（user02 的订单不可见）")
        created = [item["created_at"] for item in page["items"]]
        check(created == sorted(created, reverse=True), "按创建时间倒序")
        check(all("can_cancel" in item for item in page["items"]), "每条订单都带 can_cancel")

        status, page2 = call("GET", "/reservations/my", token=token01, query={"status": "RESERVED"})
        check(status == 200 and all(i["status"] == "RESERVED" for i in page2["items"]),
              "status 筛选生效", f"total={page2.get('total')}")
        status, page3 = call("GET", "/reservations/my", token=token01, query={"status": "NOT_A_STATUS"})
        check(status == 400 and code_of(page3) == "VALIDATION_ERROR", "非法 status -> 400", f"{status}/{code_of(page3)}")
        status, page4 = call("GET", "/reservations/my", token=token01, query={"page_size": 1})
        check(len(page4["items"]) == 1, "分页生效", f"items={len(page4['items'])}")

        status, page5 = call("GET", "/reservations/my", token=token02)
        check(all(i["order_no"] != order_a for i in page5["items"]), "user02 看不到 user01 的订单")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("H. R3 订单详情（BR-27）")
        print("=" * 78)
        status, detail = call("GET", f"/reservations/{order_a}", token=token01)
        check(status == 200 and detail["order_no"] == order_a, "本人查看订单详情 -> 200", f"实际={status}")
        check(len(detail["status_logs"]) == 1 and detail["status_logs"][0]["to_status"] == "RESERVED",
              "详情带状态流转时间线", f"logs={len(detail['status_logs'])}")

        status, body = call("GET", f"/reservations/{order_a}", token=token02)
        check(status == 403 and code_of(body) == "AUTH_FORBIDDEN",
              "查看他人订单 -> 403 AUTH_FORBIDDEN（BR-27，不是 404）", f"{status}/{code_of(body)}")

        status, body = call("GET", "/reservations/LZ00000000DEADBEEF", token=token01)
        check(status == 404 and code_of(body) == "RESOURCE_NOT_FOUND", "订单不存在 -> 404", f"{status}/{code_of(body)}")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("I. R4 取消预约（BR-19 / BR-20）")
        print("=" * 78)
        status, body = call("POST", f"/reservations/{order_a}/cancel", token=token02,
                            body={"reason": "越权尝试"})
        check(status == 403, "取消他人订单 -> 403", f"实际={status}")

        status, body = call("POST", "/reservations/LZ00000000DEADBEEF/cancel", token=token01)
        check(status == 404, "取消不存在的订单 -> 404", f"实际={status}")

        status, body = call("POST", f"/reservations/{order_a}/cancel", token=token01,
                            body={"reason": "行程有变"})
        check(status == 200 and body.get("status") == "CANCELLED", "取消自己的订单 -> 200 CANCELLED",
              f"{status}/{body.get('status')}")
        check(body.get("released_slot_count") == 2,
              "released_slot_count 等于 slot_count（BR-20/BR-31）",
              f"实际={body.get('released_slot_count')}")
        check(fx.count_slots(order_a) == 0, "数据库时段占用已删除",
              f"实际={fx.count_slots(order_a)}")
        check(fx.count_logs(order_a) == 2, "状态日志累计 2 条（创建 + 取消）",
              f"实际={fx.count_logs(order_a)}")

        status, detail = call("GET", f"/reservations/{order_a}", token=token01)
        check(detail["status"] == "CANCELLED" and detail["cancel_reason"] == "行程有变",
              "详情反映取消结果与原因", f"{detail['status']}/{detail.get('cancel_reason')}")
        check(detail["can_cancel"] is False and detail["cannot_cancel_reason"],
              "已取消订单 can_cancel=false 且给出原因", f"{detail.get('cannot_cancel_reason')}")

        # BR-20：释放后该时段可被重新预约
        status, body = create(token02, cab_small_id, W1)
        check(status == 201, "被取消的时段可以被重新预约（BR-20）", f"{status}/{code_of(body)}")
        order_d = body.get("order_no")

        # 再取消一次
        status, body = call("POST", f"/reservations/{order_a}/cancel", token=token01)
        check(status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
              "重复取消 -> 409 ORDER_STATUS_NOT_ALLOWED", f"{status}/{code_of(body)}")

        # 取消窗口（把提前量临时改成 1440 分钟）
        fx.set_config("cancel_ahead_minutes", "1440")
        status, body = call("POST", f"/reservations/{order_b}/cancel", token=token01)
        check(status == 409 and code_of(body) == "CANCEL_WINDOW_EXPIRED",
              "BR-19 超过取消时限 -> 409 CANCEL_WINDOW_EXPIRED", f"{status}/{code_of(body)}")
        status, detail = call("GET", f"/reservations/{order_b}", token=token01)
        check(detail["can_cancel"] is False and "可取消时间" in (detail.get("cannot_cancel_reason") or ""),
              "列表/详情同步反映不可取消原因", f"{detail.get('cannot_cancel_reason')}")
        fx.set_config("cancel_ahead_minutes", "30")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("J. 第二道防线：唯一索引直接验证")
        print("=" * 78)
        from sqlalchemy.exc import IntegrityError

        from app.models.reservation_slot import ReservationSlot

        rows = fx.fetch_one(
            "SELECT reservation_id, cabinet_id, slot_start FROM reservation_slots "
            "WHERE reservation_id = (SELECT id FROM reservations WHERE order_no = :o) LIMIT 1",
            {"o": order_b},
        )
        try:
            fx.db.add(ReservationSlot(reservation_id=rows[0], cabinet_id=rows[1], slot_start=rows[2]))
            fx.db.flush()
            fx.db.rollback()
            check(False, "直接插入重复 (cabinet_id, slot_start) 应被唯一索引拒绝")
        except IntegrityError as exc:
            fx.db.rollback()
            check("uk_slots_cabinet_slot" in str(exc.orig),
                  "直接插入重复 (cabinet_id, slot_start) 被 uk_slots_cabinet_slot 拒绝（第二道防线存在且有效）")

        # ==========================================================
        print()
        print("=" * 78)
        print("K. 真并发验证 —— 16 个请求同时抢同一柜格同一时段")
        print("=" * 78)
        conc_before = fx.count_reservations()
        barrier = threading.Barrier(16)

        def racer(_: int) -> tuple[int, Any]:
            body = {
                "cabinet_id": cab_small_id,
                "start_time": W6[0],
                "end_time": W6[1],
                "luggage_size": "SMALL",
                "idempotency_key": f"{KEY_PREFIX}conc_{uuid.uuid4().hex[:12]}",
            }
            barrier.wait()  # 尽量让 16 个请求同时发出
            return call("POST", "/reservations", token=token01, body=body)

        with ThreadPoolExecutor(max_workers=16) as pool:
            race = list(pool.map(racer, range(16)))

        succeeded = [(s, b) for s, b in race if s == 201]
        conflicts = [(s, b) for s, b in race if s == 409]
        others = [(s, b) for s, b in race if s not in (201, 409)]

        print(f"  201 成功 : {len(succeeded)}")
        print(f"  409 冲突 : {len(conflicts)}")
        print(f"  其它     : {[(s, code_of(b)) for s, b in others]}")

        check(len(succeeded) == 1, "16 个并发请求中**恰好 1 个**成功", f"实际={len(succeeded)}")
        check(len(conflicts) == 15, "其余 15 个都返回 409", f"实际={len(conflicts)}")
        check(not others, "没有出现其它状态码（5xx / 200 等）", f"{[(s, code_of(b)) for s, b in others]}")
        check(all(code_of(b) == "CABINET_TIME_CONFLICT" for _, b in conflicts),
              "冲突错误码统一为 CABINET_TIME_CONFLICT")
        winner_order = succeeded[0][1]["order_no"] if succeeded else None
        check(fx.count_slots(winner_order) == 2,
              "赢家订单的时段记录数正确（没有被并发写坏）", f"实际={fx.count_slots(winner_order)}")

        finally_count = fx.count_reservations()
        check(finally_count == conc_before + 1,
              "并发后数据库中**只多出 1 条**订单", f"期望={conc_before + 1} 实际={finally_count}")

        index_hits = [b for _, b in conflicts if "唯一索引" in detail_text(b)]
        check(len(index_hits) >= 1,
              f"其中 {len(index_hits)} 个是由【数据库唯一索引】兜底拦下的"
              "（证明第二道防线确实在承担并发场景，不是摆设）")

        # ----------------------------------------------------------
        print()
        print("=" * 78)
        print("L. 真并发验证 —— 12 个请求携带**同一个幂等键**")
        print("=" * 78)
        same_key = f"{KEY_PREFIX}same_{uuid.uuid4().hex[:12]}"
        barrier2 = threading.Barrier(12)
        W7 = window(5, 1.0)

        def same_racer(_: int) -> tuple[int, Any]:
            body = {
                "cabinet_id": cab_large_id,
                "start_time": W7[0],
                "end_time": W7[1],
                "luggage_size": "LARGE",
                "idempotency_key": same_key,
            }
            barrier2.wait()
            return call("POST", "/reservations", token=token02, body=body)

        with ThreadPoolExecutor(max_workers=12) as pool:
            race2 = list(pool.map(same_racer, range(12)))

        created_count = sum(1 for s, _ in race2 if s == 201)
        replay_count = sum(1 for s, _ in race2 if s == 200)
        err2 = [(s, code_of(b)) for s, b in race2 if s not in (200, 201)]
        order_nos = {b["order_no"] for s, b in race2 if s in (200, 201)}

        print(f"  201 新建 : {created_count}")
        print(f"  200 重放 : {replay_count}")
        print(f"  其它     : {err2}")

        check(not err2, "12 个并发同键请求全部得到 200/201", f"{err2}")
        check(created_count == 1, "**恰好 1 个**真正创建了订单", f"实际={created_count}")
        check(replay_count == 11, "其余 11 个都是幂等重放", f"实际={replay_count}")
        check(len(order_nos) == 1, "全部返回同一个 order_no", f"{order_nos}")
        check(fx.count_reservations(idempotency_like=same_key) == 1,
              "数据库中该幂等键只有 1 条订单", f"实际={fx.count_reservations(idempotency_like=same_key)}")

    finally:
        fx.close()
        print()

    print("=" * 78)
    failed = [name for ok, name in results if not ok]
    print(f"用例总数 {len(results)}，通过 {len(results) - len(failed)}，失败 {len(failed)}")
    if failed:
        print("失败用例：")
        for name in failed:
            print("  -", name)
    print("=" * 78)
    print("夹具数据与临时改动已清理")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
