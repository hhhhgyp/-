# -*- coding: utf-8 -*-
"""
第四阶段 · 批次 3A（管理端基础资料 M1 ~ M9）端到端验证。

真实 HTTP + 真实 MySQL。重点验证三件事：

1. **权限（BR-26）**：未登录 -> 401；普通用户 -> 403；管理员 -> 通过。
   这是 `require_admin` 的第一次真实使用。

2. **数据约束**：编码重复 -> 409 `DUPLICATE_CODE`；
   营业时间非法 / 尺寸超列范围 -> 400 `VALIDATION_ERROR`；
   资源不存在 -> 404 `RESOURCE_NOT_FOUND`。

3. **跨模块的真实影响**（这类断言才是这个项目真正的价值）：
   - M3 把寄存点置 CLOSED  ->  Q6 对该寄存点的柜格返回不可用（BR-11）
   - M5 把柜体置 MAINTENANCE -> Q6 对该柜体的柜格返回不可用（BR-10）
   - M7 对【有 IN_USE 订单】的柜格切维护 -> 409 `CABINET_NOT_AVAILABLE`；
     而对【只有未来 RESERVED 订单】的柜格切维护 -> 200（设计方案 M7 的口径）
   - M9 把规格 is_active 置 false -> 用该规格新下单 -> 409 `CABINET_TYPE_DISABLED`（BR-12）

【C12 全有或全无】批量新增柜格若与已有编号冲突，必须整批不创建。
脚本会先建 Z-01~Z-03，再请求 5 个（含冲突），然后断言 Z-04/Z-05 **不存在**。

运行前置：服务已启动（建议加 --no-scheduler 保证结果确定）。
    set PHASE4_BASE_URL=http://127.0.0.1:8138/api/v1
    python tools/phase4_e2e_admin.py
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, time, timedelta
from typing import Any

sys.path.insert(0, ".")

BASE = os.environ.get("PHASE4_BASE_URL", "http://127.0.0.1:8138/api/v1")

#: 本次测试创建的数据统一使用这几个前缀，便于收尾精确清理
POINT_CODE = "SPT9"
GROUP_CODE = "GT9"
CABINET_PREFIX = "ZT9-"
TYPE_CODE = "TT9"

#: 时间粒度（与 system_config.slot_minutes 默认值一致），造数时对齐用
SLOT_MINUTES = 30

results: list[tuple[bool, str]] = []


def check(ok: bool, name: str, extra: str = "") -> None:
    results.append((bool(ok), name))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {extra}" if extra else ""))


def call(
    method: str,
    path: str,
    *,
    token: str | None = None,
    body: dict | None = None,
    query: dict | None = None,
) -> tuple[int, Any]:
    url = BASE + path
    if query:
        clean = {k: v for k, v in query.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            return exc.code, (json.loads(raw) if raw else None)
        except json.JSONDecodeError:
            return exc.code, {"raw": raw}


def code_of(payload: Any) -> str | None:
    return payload.get("code") if isinstance(payload, dict) else None


def login(username: str, password: str = "Demo@123456") -> str:
    status, body = call("POST", "/auth/login", body={"username": username, "password": password})
    assert status == 200, f"登录失败 {username}: {status} {body}"
    return body["access_token"]


def dt(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H:%M:%S")


# ==================================================================
# 数据库夹具：清理、配置、直查
# ==================================================================
class Fixture:
    def __init__(self) -> None:
        from app.db.session import SessionLocal

        self.db = SessionLocal()
        self.config_backup: dict[str, str | None] = {}
        self.cleanup()

    # ---------- 清理 ----------
    def cleanup(self) -> None:
        """按前缀精确删除本次测试可能留下的数据（顺序满足外键约束）。"""
        from sqlalchemy import text

        point_ids = [
            r[0]
            for r in self.db.execute(
                text("SELECT id FROM storage_points WHERE code = :c"), {"c": POINT_CODE}
            ).all()
        ]
        for pid in point_ids:
            group_ids = [
                r[0]
                for r in self.db.execute(
                    text("SELECT id FROM cabinet_groups WHERE point_id = :p"), {"p": pid}
                ).all()
            ]
            for gid in group_ids:
                cab_ids = [
                    r[0]
                    for r in self.db.execute(
                        text("SELECT id FROM cabinets WHERE group_id = :g"), {"g": gid}
                    ).all()
                ]
                for cid in cab_ids:
                    res_ids = [
                        r[0]
                        for r in self.db.execute(
                            text("SELECT id FROM reservations WHERE cabinet_id = :c"), {"c": cid}
                        ).all()
                    ]
                    for rid in res_ids:
                        self.db.execute(
                            text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid}
                        )
                        self.db.execute(
                            text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"),
                            {"i": rid},
                        )
                        self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
                    self.db.execute(text("DELETE FROM cabinets WHERE id = :i"), {"i": cid})
                self.db.execute(text("DELETE FROM cabinet_groups WHERE id = :i"), {"i": gid})
            self.db.execute(text("DELETE FROM storage_points WHERE id = :i"), {"i": pid})
        self.db.execute(text("DELETE FROM cabinet_types WHERE code LIKE 'TT9%'"))
        self.db.commit()

    def register_cleanup_tail(self) -> None:
        """收尾时把配置还原。"""
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE system_config SET config_value = '15' WHERE config_key = 'checkin_early_minutes'")
        )
        self.db.commit()

    # ---------- 配置 ----------
    def set_config(self, key: str, value: str) -> None:
        from sqlalchemy import text

        if key not in self.config_backup:
            row = self.db.execute(
                text("SELECT config_value FROM system_config WHERE config_key = :k"), {"k": key}
            ).scalar()
            self.config_backup[key] = row
        self.db.execute(
            text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
            {"v": value, "k": key},
        )
        self.db.commit()

    def restore_config(self) -> None:
        from sqlalchemy import text

        for key, value in self.config_backup.items():
            self.db.execute(
                text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
                {"v": value, "k": key},
            )
        self.db.commit()

    # ---------- 直查（用于验证"数据库里到底发生了什么"）----------
    def count(self, sql: str, params: dict | None = None) -> int:
        from sqlalchemy import text

        self.db.commit()  # 结束可能存在的只读事务，避免读到 REPEATABLE READ 的旧快照
        return int(self.db.execute(text(sql), params or {}).scalar_one())

    def cabinet_codes(self, group_id: int) -> list[str]:
        from sqlalchemy import text

        self.db.commit()
        return [
            r[0]
            for r in self.db.execute(
                text("SELECT code FROM cabinets WHERE group_id = :g ORDER BY code"), {"g": group_id}
            ).all()
        ]

    def user_id(self, username: str) -> int | None:
        """按用户名取 id，用于断言语义（例如状态日志里的 operator_id 是不是 admin）。"""
        from sqlalchemy import text

        self.db.commit()
        return self.db.execute(
            text("SELECT id FROM users WHERE username = :u"), {"u": username}
        ).scalar()

    # ---------- 订单侧构造 / 直查（M10 ~ M14 用） ----------
    def shift_order_to_past(self, order_no: str, slot_count: int = 2) -> dict:
        """
        【数据构造】把订单时间窗整体挪到过去，等价于"快进时钟"。

        新窗口 = [floor30(now - 3 小时), +slot_count 个时段]，
        无论当前几点，`end_time` 都比 now 早至少 1.5 小时，
        于是「超时未签到释放」与「逾期标记」两个任务的条件都能命中。
        同时重建 reservation_slots，保证时段记录与时间窗一致（数据自洽）。

        声明：这是**造数**，不是绕过校验 —— 正常用户不可能预约到过去的时段，
        但"订单在预约时段内无人签到"这个场景必须能构造出来，
        否则定时任务根本没法验收。
        """
        from sqlalchemy import text

        now = self.db_now()
        base = now - timedelta(hours=3)
        new_start = base.replace(second=0, microsecond=0) - timedelta(
            minutes=base.minute % SLOT_MINUTES
        )
        new_end = new_start + timedelta(minutes=SLOT_MINUTES * slot_count)
        new_deadline = new_start + timedelta(minutes=30)  # BR-22：start + 30 分钟

        row = self.db.execute(
            text("SELECT id, cabinet_id FROM reservations WHERE order_no = :o"),
            {"o": order_no},
        ).first()
        assert row is not None, f"订单不存在：{order_no}"
        rid, cabinet_id = row[0], row[1]

        self.db.execute(
            text(
                "UPDATE reservations SET start_time = :s, end_time = :e, checkin_deadline = :d "
                "WHERE id = :i"
            ),
            {"s": new_start, "e": new_end, "d": new_deadline, "i": rid},
        )
        self.db.execute(
            text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid}
        )
        for index in range(slot_count):
            self.db.execute(
                text(
                    "INSERT INTO reservation_slots (reservation_id, cabinet_id, slot_start) "
                    "VALUES (:r, :c, :s)"
                ),
                {"r": rid, "c": cabinet_id, "s": new_start + timedelta(minutes=SLOT_MINUTES * index)},
            )
        self.db.commit()
        return {
            "order_no": order_no,
            "start_time": str(new_start),
            "end_time": str(new_end),
            "checkin_deadline": str(new_deadline),
        }

    def db_now(self) -> datetime:
        from sqlalchemy import text

        self.db.commit()
        return self.db.execute(text("SELECT NOW()")).scalar()

    def order_row(self, order_no: str) -> dict:
        from sqlalchemy import text

        self.db.commit()
        row = self.db.execute(
            text(
                "SELECT status, cancelled_at, cancel_reason FROM reservations WHERE order_no = :o"
            ),
            {"o": order_no},
        ).first()
        assert row is not None, f"订单不存在：{order_no}"
        return {"status": row[0], "cancelled_at": row[1], "cancel_reason": row[2]}

    def count_slots(self, order_no: str) -> int:
        from sqlalchemy import text

        self.db.commit()
        return int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) FROM reservation_slots rs "
                    "JOIN reservations r ON r.id = rs.reservation_id WHERE r.order_no = :o"
                ),
                {"o": order_no},
            ).scalar()
        )

    def last_status_log(self, order_no: str) -> dict:
        from sqlalchemy import text

        self.db.commit()
        row = self.db.execute(
            text(
                "SELECT l.from_status, l.to_status, l.operator_type, l.operator_id, l.remark "
                "FROM reservation_status_logs l JOIN reservations r ON r.id = l.reservation_id "
                "WHERE r.order_no = :o ORDER BY l.id DESC LIMIT 1"
            ),
            {"o": order_no},
        ).first()
        if row is None:
            return {}
        return {
            "from_status": row[0],
            "to_status": row[1],
            "operator_type": row[2],
            "operator_id": row[3],
            "remark": row[4],
        }

    def numerator_denominator(self) -> tuple[int, int]:
        """
        用与 M12 完全相同的口径，**独立地**在脚本里重算一遍分子分母。

        这是本脚本最有价值的断言之一：如果只是"接口返回了个数字就通过"，
        那这个测试实际上什么都没验证。这里用独立的 SQL 复算，
        两边必须完全一致，才说明接口算的是"定义"而不是"某个碰巧的数"。
        """
        from sqlalchemy import text

        self.db.commit()
        serviceable = (
            "FROM cabinets c "
            "JOIN cabinet_groups g ON g.id = c.group_id "
            "JOIN storage_points p ON p.id = g.point_id "
            "JOIN cabinet_types t ON t.id = c.type_id "
            "WHERE c.physical_status = 'AVAILABLE' AND g.status = 'NORMAL' "
            "AND p.status = 'OPEN' AND t.is_active = 1"
        )
        denominator = int(self.db.execute(text("SELECT COUNT(*) " + serviceable)).scalar())
        numerator = int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) " + serviceable + " AND EXISTS ("
                    "  SELECT 1 FROM reservations r WHERE r.cabinet_id = c.id AND ("
                    "    r.status = 'OVERDUE' OR (r.status IN ('RESERVED','IN_USE')"
                    "      AND r.start_time <= NOW() AND r.end_time > NOW())))"
                )
            ).scalar()
        )
        return numerator, denominator

    def residue(self) -> dict:
        from sqlalchemy import text

        self.db.commit()
        return {
            "测试寄存点": self.count(
                "SELECT COUNT(1) FROM storage_points WHERE code = :c", {"c": POINT_CODE}
            ),
            "测试柜体": self.count(
                "SELECT COUNT(1) FROM cabinet_groups WHERE code = :c", {"c": GROUP_CODE}
            ),
            "测试柜格": self.count(
                "SELECT COUNT(1) FROM cabinets WHERE code LIKE :p", {"p": CABINET_PREFIX + "%"}
            ),
            "测试规格": self.count(
                "SELECT COUNT(1) FROM cabinet_types WHERE code LIKE :p", {"p": TYPE_CODE + "%"}
            ),
            "全局订单数": self.count("SELECT COUNT(1) FROM reservations"),
        }


def text_update(sql: str):
    from sqlalchemy import text

    return text(sql)


# ==================================================================
# A. 权限（require_admin 第一次真实使用）
# ==================================================================
def run_permissions(admin_token: str, user_token: str, fx: Fixture) -> None:
    print("\n=== A. 权限：未登录 401 / 普通用户 403 / 管理员通过（BR-26）===")
    body = {
        "code": "SPT9X",
        "name": "越权测试",
        "city": "测试市",
        "address": "测试地址",
        "open_time": "08:00",
        "close_time": "22:00",
    }

    status, payload = call("POST", "/admin/points", body=body)
    check(
        status == 401 and code_of(payload) == "AUTH_TOKEN_MISSING",
        "未携带 token 访问 /admin/points -> 401 AUTH_TOKEN_MISSING",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("POST", "/admin/points", token=user_token, body=body)
    check(
        status == 403 and code_of(payload) == "AUTH_FORBIDDEN",
        "普通用户（user02）访问 /admin/points -> 403 AUTH_FORBIDDEN",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("POST", "/admin/points", token=admin_token, body=body)
    check(status == 201, "管理员访问 /admin/points -> 201", f"HTTP {status}")
    if status == 201:
        # 权限用例顺手建的数据立刻删掉（管理端刻意没有删除接口，用夹具清）
        fx.db.execute(text_update("DELETE FROM storage_points WHERE id = :i"), {"i": payload["id"]})
        fx.db.commit()

    # 其余管理接口同样受保护（抽查另外两个不同模块的端点）
    # 注：`GET /admin/reservations`（M10）等订单/运维接口属于批次 3B 新增，
    # 那时用不存在的路由去验权限只能拿到 404（FastAPI 先匹配路由、再跑依赖），
    # 所以 3A 阶段这里挑的是**当时已存在**的两个端点。
    for method, path, extra in (
        ("POST", "/admin/cabinet-types", {"code": TYPE_CODE, "name": "x", "size_level": "SMALL",
                                          "width_mm": 1, "height_mm": 1, "depth_mm": 1,
                                          "price_per_slot": "1.00"}),
        ("PATCH", "/admin/cabinets/1/status", {"physical_status": "AVAILABLE"}),
    ):
        status, payload = call(method, path, token=user_token, body=extra)
        check(
            status == 403 and code_of(payload) == "AUTH_FORBIDDEN",
            f"普通用户访问 {method} {path} -> 403",
            f"HTTP {status} {code_of(payload)}",
        )

    # ---- 批次 3B 新增的订单 / 运维 / 配置接口（现在这些路由已存在，403 才是有意义的断言）----
    # 这些接口能改订单、能动定时任务、能改全局业务参数，
    # 权限如果漏一个，普通用户就能自己把系统参数改坏 —— 所以逐个抽查。
    for method, path, extra in (
        ("GET", "/admin/reservations", None),
        ("POST", "/admin/reservations/LZ_PROBE_0001/force-cancel", {"reason": "越权试探"}),
        ("GET", "/admin/stats/overview", None),
        ("POST", "/admin/jobs/release-expired/run", None),
        ("GET", "/admin/jobs/logs", None),
        ("GET", "/admin/configs", None),
        ("PUT", "/admin/configs/max_advance_days", {"value": "1"}),
    ):
        status, payload = call(method, path, token=user_token, body=extra)
        check(
            status == 403 and code_of(payload) == "AUTH_FORBIDDEN",
            f"★ 普通用户访问 {method} {path} -> 403（3B 新接口逐个抽查）",
            f"HTTP {status} {code_of(payload)}",
        )

    # 未登录访问一个新接口也应 401，而不是 500 或 404
    status, payload = call("PUT", "/admin/configs/max_advance_days", body={"value": "1"})
    check(
        status == 401 and code_of(payload) == "AUTH_TOKEN_MISSING",
        "未登录修改系统配置 -> 401 AUTH_TOKEN_MISSING",
        f"HTTP {status} {code_of(payload)}",
    )


# ==================================================================
# B. M1 ~ M3 寄存点
# ==================================================================
def run_point_flow(admin_token: str, fx: Fixture) -> int:
    print("\n=== B. M1 ~ M3 寄存点 ===")
    create_body = {
        "code": POINT_CODE,
        "name": "批次3A测试寄存点",
        "city": "测试市",
        "address": "测试路 1 号",
        "open_time": "06:00",
        "close_time": "23:30",
        "contact_phone": "0571-0000000",
        "description": "自动化验证用，收尾会删除",
    }

    status, point = call("POST", "/admin/points", token=admin_token, body=create_body)
    check(status == 201, "M1 新建寄存点 -> 201", f"HTTP {status}")
    point_id = point.get("id") if status == 201 else None
    check(
        point.get("status") == "OPEN" and point.get("open_time") == "06:00:00",
        "M1 返回体含默认状态 OPEN 与规范化后的营业时间",
        f"status={point.get('status')} open_time={point.get('open_time')}",
    )

    status, payload = call("POST", "/admin/points", token=admin_token, body=create_body)
    check(
        status == 409 and code_of(payload) == "DUPLICATE_CODE",
        "M1 编码重复 -> 409 DUPLICATE_CODE",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/points", token=admin_token,
        body={**create_body, "code": "SPT9Y", "open_time": "22:00", "close_time": "08:00"},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M1 营业时间 close <= open -> 400 VALIDATION_ERROR",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/points", token=admin_token, body={**create_body, "code": "SPT9Y", "status": "OPENING"}
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M1 非法状态值 -> 400 VALIDATION_ERROR",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("POST", "/admin/points", token=admin_token, body={"code": "SPT9Y"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M1 缺少必填字段 -> 400 VALIDATION_ERROR",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- M2 ----
    status, updated = call(
        "PUT", f"/admin/points/{point_id}", token=admin_token, body={"name": "改过的名字"}
    )
    check(
        status == 200 and updated.get("name") == "改过的名字" and updated.get("code") == POINT_CODE,
        "M2 部分更新：只改名字，编码等其它字段保持不变",
        f"HTTP {status} name={updated.get('name')} code={updated.get('code')}",
    )

    status, payload = call(
        "PUT", f"/admin/points/{point_id}", token=admin_token, body={"code": "SP001"}
    )
    check(
        status == 409 and code_of(payload) == "DUPLICATE_CODE",
        "M2 改成已存在的编码 -> 409 DUPLICATE_CODE",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "PUT", f"/admin/points/{point_id}", token=admin_token, body={"close_time": "05:00"}
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M2 只改 close_time 导致营业区间非法 -> 400（用未传的 open_time 一起判定）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("PUT", "/admin/points/99999999", token=admin_token, body={"name": "x"})
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M2 寄存点不存在 -> 404 RESOURCE_NOT_FOUND",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- M3 ----
    # 这里刻意把寄存点切成 CLOSED 且**不还原**：
    # 后面柜格建好之后（M 段）才能验证 BR-11「寄存点不营业 -> 其下柜格不可用」，
    # 验完再改回 OPEN。用例之间靠一个明确的状态接力，而不是各自假设初始状态。
    status, closed = call(
        "PATCH", f"/admin/points/{point_id}/status", token=admin_token, body={"status": "CLOSED"}
    )
    check(
        status == 200 and closed.get("status") == "CLOSED",
        "M3 将寄存点置为 CLOSED -> 200",
        f"HTTP {status} status={closed.get('status')}",
    )

    status, payload = call(
        "PATCH", f"/admin/points/{point_id}/status", token=admin_token, body={"status": "OPENING"}
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M3 非法状态值 -> 400 VALIDATION_ERROR（枚举由 Pydantic 拦下）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "PATCH", "/admin/points/99999999/status", token=admin_token, body={"status": "CLOSED"}
    )
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M3 寄存点不存在 -> 404 RESOURCE_NOT_FOUND",
        f"HTTP {status} {code_of(payload)}",
    )

    return point_id


# ==================================================================
# C. M4 ~ M5 柜体
# ==================================================================
def run_group_flow(admin_token: str, fx: Fixture, point_id: int) -> int:
    print("\n=== C. M4 ~ M5 柜体 ===")

    status, group = call(
        "POST", f"/admin/points/{point_id}/groups", token=admin_token,
        body={"code": GROUP_CODE, "name": "批次3A测试柜体"},
    )
    check(status == 201, "M4 新建柜体 -> 201", f"HTTP {status}")
    group_id = group.get("id") if status == 201 else None
    check(
        group.get("cabinet_count") == 0,
        "M4 新柜体的 cabinet_count 为 0（统计口径与 Q3 一致）",
        f"cabinet_count={group.get('cabinet_count')}",
    )

    status, payload = call(
        "POST", f"/admin/points/{point_id}/groups", token=admin_token,
        body={"code": GROUP_CODE, "name": "重复"},
    )
    check(
        status == 409 and code_of(payload) == "DUPLICATE_CODE",
        "M4 同一寄存点下柜体编码重复 -> 409",
        f"HTTP {status} {code_of(payload)}",
    )

    # 唯一索引是 (point_id, code)：换一个寄存点用同一个 code 应该成功
    status, payload = call(
        "POST", "/admin/points/1/groups", token=admin_token,
        body={"code": GROUP_CODE, "name": "别的寄存点下的同名柜体"},
    )
    check(
        status == 201,
        "M4 唯一性范围是 (point_id, code)：另一个寄存点可用同编码 -> 201",
        f"HTTP {status} {code_of(payload)}",
    )
    other_group_id = payload.get("id") if status == 201 else None

    status, payload = call(
        "POST", "/admin/points/99999999/groups", token=admin_token, body={"code": "X", "name": "x"}
    )
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M4 寄存点不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- M5 ----
    status, updated = call(
        "PUT", f"/admin/groups/{group_id}", token=admin_token, body={"name": "改过的柜体名"}
    )
    check(
        status == 200 and updated.get("name") == "改过的柜体名",
        "M5 修改柜体名称 -> 200",
        f"HTTP {status} name={updated.get('name')}",
    )

    status, payload = call("PUT", "/admin/groups/99999999", token=admin_token, body={"name": "x"})
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M5 柜体不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    # 清理掉"另一个寄存点下的同名柜体"，避免污染 SP001
    if other_group_id:
        fx.db.execute(text_update("DELETE FROM cabinet_groups WHERE id = :i"), {"i": other_group_id})
        fx.db.commit()

    return group_id


# ==================================================================
# D. M6 批量新增柜格（C12 全有或全无）
# ==================================================================
def run_cabinet_batch(admin_token: str, fx: Fixture, group_id: int, type_id: int) -> list[dict]:
    print("\n=== D. M6 批量新增柜格（C12 全有或全无）===")

    status, result = call(
        "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 3, "type_id": type_id, "start_index": 1},
    )
    check(status == 201, "M6 批量新增 3 个柜格 -> 201", f"HTTP {status}")
    codes = [item["code"] for item in (result.get("created") or [])]
    check(
        codes == [CABINET_PREFIX + "01", CABINET_PREFIX + "02", CABINET_PREFIX + "03"],
        "M6 编号按 prefix + 两位序号连续生成",
        str(codes),
    )
    check(
        result.get("skipped") == [],
        "M6 成功时 skipped 为空数组",
        str(result.get("skipped")),
    )

    before = fx.cabinet_codes(group_id)

    # 关键：请求 5 个，前 3 个与已有冲突 -> 整批都不能创建
    status, payload = call(
        "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 5, "type_id": type_id, "start_index": 1},
    )
    check(
        status == 409 and code_of(payload) == "DUPLICATE_CODE",
        "M6 批次内存在冲突编号 -> 409 DUPLICATE_CODE",
        f"HTTP {status} {code_of(payload)}",
    )
    conflicts = (payload.get("detail") or {}).get("conflicts") if isinstance(payload, dict) else None
    check(
        conflicts == [CABINET_PREFIX + "01", CABINET_PREFIX + "02", CABINET_PREFIX + "03"],
        "M6 detail.conflicts 精确列出冲突编号",
        str(conflicts),
    )

    after = fx.cabinet_codes(group_id)
    check(
        after == before,
        "★ C12 全有或全无：409 之后数据库里没有多出任何柜格（Z-04/Z-05 不存在）",
        f"前={before} 后={after}",
    )
    check(
        CABINET_PREFIX + "04" not in after and CABINET_PREFIX + "05" not in after,
        "★ C12：未冲突的 Z-04 / Z-05 也没有被创建",
        str(after),
    )

    status, payload = call(
        "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 0, "type_id": type_id},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M6 count=0 -> 400（边界下界）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 51, "type_id": type_id},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M6 count=51 -> 400（边界上界，单批最多 50）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 1, "type_id": 99999999},
    )
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M6 规格不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/groups/99999999/cabinets", token=admin_token,
        body={"prefix": CABINET_PREFIX, "count": 1, "type_id": type_id},
    )
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M6 柜体不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    return result.get("created") or []


# ==================================================================
# E. M7 柜格状态
# ==================================================================
def run_cabinet_status(admin_token: str, user_token: str, fx: Fixture, cabinet: dict) -> None:
    print("\n=== E. M7 柜格运维状态 ===")
    cabinet_id = cabinet["id"]

    status, body = call(
        "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
        body={"physical_status": "MAINTENANCE", "remark": "测试维护"},
    )
    check(
        status == 200 and body.get("physical_status") == "MAINTENANCE",
        "M7 切为维护中 -> 200",
        f"HTTP {status} status={body.get('physical_status')}",
    )

    status, payload = call(
        "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
        body={"physical_status": "BROKEN"},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M7 非法状态值 -> 400",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "PATCH", "/admin/cabinets/99999999/status", token=admin_token,
        body={"physical_status": "MAINTENANCE"},
    )
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M7 柜格不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    # 维护中 -> Q6 应返回不可用
    start = datetime.combine(datetime.now().date() + timedelta(days=1), time(10, 0))
    end = start + timedelta(hours=1)
    status, avail = call(
        "GET", f"/cabinets/{cabinet_id}/availability",
        query={"start_time": dt(start), "end_time": dt(end)},
    )
    check(
        status == 200 and avail.get("available") is False and avail.get("derived_status") == "MAINTENANCE",
        "M7 维护中的柜格在 Q6 里不可用且 derived_status=MAINTENANCE（跨模块一致）",
        f"HTTP {status} available={avail.get('available')} derived={avail.get('derived_status')}",
    )

    # 改回可用
    status, body = call(
        "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
        body={"physical_status": "AVAILABLE"},
    )
    check(status == 200 and body.get("physical_status") == "AVAILABLE", "M7 改回可用 -> 200", f"HTTP {status}")

    # ---- 只有未来 RESERVED 订单时：允许切维护（设计方案 M7 的口径）----
    status, order = call(
        "POST", "/reservations", token=user_token,
        body={
            "cabinet_id": cabinet_id,
            "start_time": dt(start),
            "end_time": dt(end),
            "luggage_size": "SMALL",
            "idempotency_key": "e2e4admin_reserved_" + str(cabinet_id),
        },
    )
    check(status == 201, "为 M7 用例创建一条未来时段的订单 -> 201", f"HTTP {status}")
    order_no = order.get("order_no") if status == 201 else None

    if order_no:
        status, body = call(
            "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
            body={"physical_status": "MAINTENANCE"},
        )
        check(
            status == 200,
            "M7 仅有未来 RESERVED 订单时【允许】切维护（与设计方案原文口径一致）",
            f"HTTP {status}",
        )
        call(
            "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
            body={"physical_status": "AVAILABLE"},
        )

        # ---- 签到后变成 IN_USE：此时不允许切维护 ----
        fx.set_config("checkin_early_minutes", "2880")
        status, ci = call("POST", f"/reservations/{order_no}/check-in", token=user_token)
        check(
            status == 200 and ci.get("status") == "IN_USE",
            "该订单签到 -> IN_USE（为 M7 的占用场景造数）",
            f"HTTP {status}",
        )

        status, payload = call(
            "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
            body={"physical_status": "MAINTENANCE"},
        )
        orders = (payload.get("detail") or {}).get("orders") if isinstance(payload, dict) else None
        check(
            status == 409 and code_of(payload) == "CABINET_NOT_AVAILABLE",
            "★ M7 存在 IN_USE 订单时切维护 -> 409 CABINET_NOT_AVAILABLE",
            f"HTTP {status} {code_of(payload)}",
        )
        check(
            isinstance(orders, list) and any(o.get("order_no") == order_no for o in orders),
            "★ M7 detail.orders 列出了占用订单号",
            str(orders),
        )

        # 取件后释放，再切维护应成功
        status, done = call("POST", f"/reservations/{order_no}/complete", token=user_token)
        check(status == 200 and done.get("status") == "COMPLETED", "取件完成释放柜格", f"HTTP {status}")

        status, body = call(
            "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
            body={"physical_status": "MAINTENANCE"},
        )
        check(
            status == 200,
            "订单完成后柜格可正常切维护（占用判定是实时的）",
            f"HTTP {status}",
        )

        # 收尾还原为「可用」。
        # 【为什么要显式还原】上一行断言故意把柜格留在了维护中，
        # 后续用例（M10 下单、M11 强制取消、M13 触发任务）都需要这个柜格可预约。
        # 不给后续用例留垃圾状态，是用例互相独立的前提。
        status, body = call(
            "PATCH", f"/admin/cabinets/{cabinet_id}/status", token=admin_token,
            body={"physical_status": "AVAILABLE"},
        )
        check(
            status == 200 and body.get("physical_status") == "AVAILABLE",
            "M7 收尾还原柜格为可用",
            f"HTTP {status} status={body.get('physical_status')}",
        )

        fx.restore_config()


# ==================================================================
# F. M8 ~ M9 规格（含 BR-12 端到端）
# ==================================================================
def run_type_create(admin_token: str, fx: Fixture) -> int:
    print("\n=== F. M8 新建柜格规格 ===")

    status, ctype = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={
            "code": TYPE_CODE, "name": "批次3A测试规格", "size_level": "SMALL",
            "width_mm": 300, "height_mm": 300, "depth_mm": 400,
            "price_per_slot": "1.50", "slot_minutes": 30,
        },
    )
    check(status == 201, "M8 新建规格 -> 201", f"HTTP {status}")
    type_id = ctype.get("id") if status == 201 else None

    status, payload = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={"code": TYPE_CODE, "name": "重复", "size_level": "SMALL",
              "width_mm": 1, "height_mm": 1, "depth_mm": 1, "price_per_slot": "1.00"},
    )
    check(
        status == 409 and code_of(payload) == "DUPLICATE_CODE",
        "M8 编码重复 -> 409",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={"code": "TT9B", "name": "非法等级", "size_level": "HUGE",
              "width_mm": 1, "height_mm": 1, "depth_mm": 1, "price_per_slot": "1.00"},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M8 非法 size_level -> 400",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={"code": "TT9B", "name": "尺寸超范围", "size_level": "SMALL",
              "width_mm": 70000, "height_mm": 1, "depth_mm": 1, "price_per_slot": "1.00"},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M8 width_mm 超出 SMALLINT UNSIGNED 范围 -> 400（不会打到数据库才报错）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={"code": "TT9B", "name": "负价", "size_level": "SMALL",
              "width_mm": 1, "height_mm": 1, "depth_mm": 1, "price_per_slot": "-1.00"},
    )
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M8 单价为负 -> 400",
        f"HTTP {status} {code_of(payload)}",
    )

    return type_id


def run_type_update(
    admin_token: str, user_token: str, fx: Fixture, cabinet: dict, type_id: int
) -> None:
    print("\n=== G. M9 修改规格 + BR-12 端到端 ===")

    # ---- M9 ----
    status, updated = call(
        "PUT", f"/admin/cabinet-types/{type_id}", token=admin_token,
        body={"price_per_slot": "2.00", "name": "改过的规格名"},
    )
    check(
        status == 200 and str(updated.get("price_per_slot")) in ("2.00", "2.0")
        and updated.get("name") == "改过的规格名",
        "M9 改价格与名称 -> 200",
        f"HTTP {status} price={updated.get('price_per_slot')} name={updated.get('name')}",
    )

    status, payload = call("PUT", "/admin/cabinet-types/99999999", token=admin_token, body={"name": "x"})
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M9 规格不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    # BR-12：停用规格后，用该规格的柜格不能再被预约
    start = datetime.combine(datetime.now().date() + timedelta(days=2), time(10, 0))
    end = start + timedelta(hours=1)

    # 【防御性还原柜格为可用】
    # M7 最后一条断言故意把柜格切成了「维护中」以证明转换成功（M7 段结束时已自行还原）。
    # 这里再兜一次底：本段的断言依赖 R1 走到 BR-12，
    # 而 R1 的判定顺序是 BR-09（柜格维护中）先于 BR-12（规格停用）；
    # 一旦柜格处于维护中，拿到的 409 会是 CABINET_NOT_AVAILABLE ——
    # 用例会"失败得不明不白"。真实测试里最容易忽略的坑，就是用例之间通过共享数据互相污染。
    call(
        "PATCH", f"/admin/cabinets/{cabinet['id']}/status", token=admin_token,
        body={"physical_status": "AVAILABLE"},
    )

    status, ok_order = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinet["id"], "start_time": dt(start), "end_time": dt(end),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_br12_before"},
    )
    check(status == 201, "BR-12 前置：规格启用时可正常下单 -> 201", f"HTTP {status}")
    if status == 201:
        call("POST", f"/reservations/{ok_order['order_no']}/cancel", token=user_token, body={})

    status, payload = call(
        "PUT", f"/admin/cabinet-types/{type_id}", token=admin_token, body={"is_active": False}
    )
    check(
        status == 200 and payload.get("is_active") is False,
        "M9 停用规格 -> 200 is_active=false",
        f"HTTP {status} is_active={payload.get('is_active')}",
    )

    status, payload = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinet["id"], "start_time": dt(start), "end_time": dt(end),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_br12_after"},
    )
    check(
        status == 409 and code_of(payload) == "CABINET_TYPE_DISABLED",
        "★ BR-12 端到端：规格停用后用该柜格下单 -> 409 CABINET_TYPE_DISABLED",
        f"HTTP {status} {code_of(payload)}",
    )

    # 停用的规格不该出现在 Q4 规格列表里
    status, types = call("GET", "/cabinet-types")
    listed = [t["code"] for t in (types if isinstance(types, list) else [])]
    check(
        TYPE_CODE not in listed,
        "★ BR-12：停用规格不再出现在 Q4 规格列表中",
        f"列表={listed}",
    )


# ==================================================================
# H. M10 全量订单查询
# ==================================================================
def run_admin_reservation_query(
    admin_token: str, user_token: str, other_user_token: str, fx: Fixture, point_id: int,
    cabinets: list[dict],
) -> dict:
    print("\n=== H. M10 全量订单查询 ===")
    day3 = (datetime.now().date() + timedelta(days=3)).isoformat()

    def slot(day: int, hour: int) -> tuple[datetime, datetime]:
        start = datetime.combine(datetime.now().date() + timedelta(days=day), time(hour, 0))
        return start, start + timedelta(hours=1)

    s1, e1 = slot(3, 10)
    status, order_a = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinets[0]["id"], "start_time": dt(s1), "end_time": dt(e1),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m10_a"},
    )
    check(status == 201, "M10 造数：user02 创建订单 A -> 201", f"HTTP {status}")

    s2, e2 = slot(3, 12)
    status, order_b = call(
        "POST", "/reservations", token=other_user_token,
        body={"cabinet_id": cabinets[1]["id"], "start_time": dt(s2), "end_time": dt(e2),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m10_b"},
    )
    check(status == 201, "M10 造数：user01 创建订单 B -> 201", f"HTTP {status}")
    if status == 201:
        call("POST", f"/reservations/{order_b['order_no']}/cancel", token=other_user_token,
             body={"reason": "M10 造一个 CANCELLED 状态"})

    # ---- 无筛选：应同时看到两个用户、两种状态的订单 ----
    status, page1 = call("GET", "/admin/reservations", token=admin_token, query={"page_size": 100})
    items = page1.get("items") if isinstance(page1, dict) else []
    check(status == 200 and isinstance(items, list), "M10 全量查询 -> 200 分页结构", f"HTTP {status}")
    nos = [item["order_no"] for item in items]
    names = {item["username"] for item in items}
    check(
        order_a["order_no"] in nos and order_b["order_no"] in nos,
        "M10 两个用户的订单都能被管理员看到（普通用户只能看到自己的）",
        f"共 {len(nos)} 条",
    )
    check(
        names >= {"user02", "user01"},
        "M10 返回体带上 username（运营按人查单的前提）",
        str(sorted(names)),
    )
    check(
        nos.index(order_b["order_no"]) < nos.index(order_a["order_no"]),
        "M10 排序与 R2 一致：按创建时间倒序（后创建的 B 排在 A 前面）",
        f"B={nos.index(order_b['order_no'])} A={nos.index(order_a['order_no'])}",
    )

    # ---- order_no 精确筛选 ----
    status, page2 = call("GET", "/admin/reservations", token=admin_token,
                         query={"order_no": order_a["order_no"]})
    got = page2.get("items", []) if isinstance(page2, dict) else []
    check(
        status == 200 and len(got) == 1 and got[0]["order_no"] == order_a["order_no"],
        "M10 按 order_no 精确查询 -> 恰好命中 1 条",
        f"HTTP {status} 命中 {len(got)} 条",
    )

    # ---- username 模糊筛选 ----
    status, page3 = call("GET", "/admin/reservations", token=admin_token,
                         query={"username": "user0", "page_size": 100})
    got3 = page3.get("items", []) if isinstance(page3, dict) else []
    check(
        status == 200 and got3 and all(item["username"].startswith("user0") for item in got3),
        "M10 按 username 模糊搜索：只返回匹配用户名的订单",
        f"命中 {len(got3)} 条 {sorted({i['username'] for i in got3})}",
    )

    # ---- status 精确筛选（合法 / 非法）----
    status, page4 = call("GET", "/admin/reservations", token=admin_token,
                         query={"status": "CANCELLED", "page_size": 100})
    got4 = page4.get("items", []) if isinstance(page4, dict) else []
    check(
        status == 200 and got4 and all(item["status"] == "CANCELLED" for item in got4),
        "M10 按 status=CANCELLED 筛选：只返回已取消订单",
        f"命中 {len(got4)} 条",
    )
    status, payload = call("GET", "/admin/reservations", token=admin_token,
                          query={"status": "NOT_A_STATUS"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M10 非法 status -> 400 VALIDATION_ERROR",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- point_id 筛选 ----
    status, page5 = call("GET", "/admin/reservations", token=admin_token,
                         query={"point_id": point_id, "page_size": 100})
    got5 = page5.get("items", []) if isinstance(page5, dict) else []
    check(
        status == 200 and got5 and all(item["point_id"] == point_id for item in got5),
        "M10 按 point_id 筛选：只返回该寄存点的订单",
        f"命中 {len(got5)} 条",
    )

    # ---- 日期区间（含当天两端）----
    status, page6 = call("GET", "/admin/reservations", token=admin_token,
                         query={"start_date": day3, "end_date": day3, "page_size": 100})
    got6 = page6.get("items", []) if isinstance(page6, dict) else []
    check(
        status == 200 and {item["order_no"] for item in got6} >= {order_a["order_no"], order_b["order_no"]},
        "M10 start_date=end_date=第 3 天：当天开始的订单都被包含（右端含当天）",
        f"命中 {len(got6)} 条",
    )
    far = (datetime.now().date() + timedelta(days=30)).isoformat()
    status, page7 = call("GET", "/admin/reservations", token=admin_token,
                         query={"start_date": far, "end_date": far})
    check(
        status == 200 and page7.get("total") == 0,
        "M10 查询 30 天后的日期 -> 0 条（区间确实在过滤，不是摆设）",
        f"total={page7.get('total')}",
    )

    # ---- 分页 ----
    status, page8 = call("GET", "/admin/reservations", token=admin_token,
                         query={"page": 1, "page_size": 1})
    check(
        status == 200 and len(page8.get("items", [])) == 1 and page8.get("total", 0) >= 2,
        "M10 分页：page_size=1 只返回 1 条，total 仍是总数",
        f"items={len(page8.get('items', []))} total={page8.get('total')}",
    )
    status, payload = call("GET", "/admin/reservations", token=admin_token, query={"page_size": 101})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M10 page_size=101 超过上限 -> 400（与 Q1/Q2 同一约束）",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- can_force_cancel 由服务端算好 ----
    status, page9 = call("GET", "/admin/reservations", token=admin_token,
                         query={"order_no": order_a["order_no"]})
    item = (page9.get("items") or [{}])[0] if isinstance(page9, dict) else {}
    check(
        item.get("can_force_cancel") is True and item.get("cannot_force_cancel_reason") is None,
        "M10 RESERVED 订单 can_force_cancel=true",
        f"can_force_cancel={item.get('can_force_cancel')}",
    )
    status, page10 = call("GET", "/admin/reservations", token=admin_token,
                          query={"order_no": order_b["order_no"]})
    item_b = (page10.get("items") or [{}])[0] if isinstance(page10, dict) else {}
    check(
        item_b.get("can_force_cancel") is False and item_b.get("cannot_force_cancel_reason"),
        "M10 已取消（终态）订单 can_force_cancel=false 并给出原因（BR-34）",
        str(item_b.get("cannot_force_cancel_reason")),
    )

    return {"order_a": order_a["order_no"], "order_b": order_b["order_no"]}


# ==================================================================
# I. M11 强制取消
# ==================================================================
def run_force_cancel(
    admin_token: str, user_token: str, fx: Fixture, cabinets: list[dict]
) -> None:
    print("\n=== I. M11 管理员强制取消 ===")
    admin_id = fx.user_id("admin")

    def slot(day: int, hour: int) -> tuple[datetime, datetime]:
        start = datetime.combine(datetime.now().date() + timedelta(days=day), time(hour, 0))
        return start, start + timedelta(hours=1)

    # ---- 场景 1：强制取消一个 RESERVED 订单 ----
    s1, e1 = slot(4, 10)
    status, order1 = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinets[2]["id"], "start_time": dt(s1), "end_time": dt(e1),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m11_reserved"},
    )
    check(status == 201, "M11 造数：RESERVED 订单 -> 201", f"HTTP {status}")

    status, payload = call("POST", f"/admin/reservations/{order1['order_no']}/force-cancel",
                           token=user_token, body={"reason": "普通用户尝试强制取消"})
    check(
        status == 403 and code_of(payload) == "AUTH_FORBIDDEN",
        "M11 普通用户强制取消 -> 403（require_admin 对该路由同样生效）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, body = call("POST", f"/admin/reservations/{order1['order_no']}/force-cancel",
                        token=admin_token, body={"reason": "运营核实用户不会来了"})
    check(
        status == 200 and body.get("status") == "FORCE_CANCELLED"
        and body.get("previous_status") == "RESERVED",
        "M11 强制取消 RESERVED 订单 -> 200 FORCE_CANCELLED",
        f"HTTP {status} {body.get('status')}",
    )
    check(
        body.get("released_slot_count") == 2,
        "M11 释放的时段数 = 订单时长对应的时段数（2 小时 = 2 个时段）",
        f"released={body.get('released_slot_count')}",
    )
    check(fx.count_slots(order1["order_no"]) == 0,
          "★ M11 数据库里该订单的 reservation_slots 已全部删除（BR-31 事务生效）",
          f"slots={fx.count_slots(order1['order_no'])}")
    log1 = fx.last_status_log(order1["order_no"])
    check(
        log1.get("to_status") == "FORCE_CANCELLED" and log1.get("operator_type") == "ADMIN"
        and log1.get("operator_id") == admin_id,
        "★ M11 状态日志记录为 ADMIN 操作且带操作人 ID（BR-33 审计）",
        str(log1),
    )

    status, payload = call("POST", f"/admin/reservations/{order1['order_no']}/force-cancel",
                           token=admin_token, body={"reason": "再取消一次"})
    check(
        status == 409 and code_of(payload) == "ORDER_STATUS_NOT_ALLOWED",
        "M11 对已是终态的订单再次强制取消 -> 409 ORDER_STATUS_NOT_ALLOWED（BR-34）",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("POST", "/admin/reservations/LZ_NOT_EXIST_0001/force-cancel",
                           token=admin_token, body={"reason": "x"})
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M11 订单不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("POST", f"/admin/reservations/{order1['order_no']}/force-cancel",
                           token=admin_token, body={})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M11 缺少必填的 reason -> 400（强制取消必须留下原因）",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- 场景 2：强制取消一个 IN_USE 订单（行李还在柜内，这是强制取消存在的意义）----
    s2, e2 = slot(5, 10)
    status, order2 = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinets[0]["id"], "start_time": dt(s2), "end_time": dt(e2),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m11_inuse"},
    )
    check(status == 201, "M11 造数：再创建一单 -> 201", f"HTTP {status}")
    # 【数据构造】把「允许提前签到」放宽到规则允许的上限 10080 分钟（7 天），
    # 这样对第 5 天的订单也能立刻签到。
    # 不能随手写个更大的数：10080 正是 M15 里 checkin_early_minutes 的 max_value，
    # 用越界值做造数会让脚本本身变得"依赖一个系统根本不允许的状态"。
    fx.set_config("checkin_early_minutes", "10080")
    status, ci = call("POST", f"/reservations/{order2['order_no']}/check-in", token=user_token)
    check(status == 200 and ci.get("status") == "IN_USE", "该单签到 -> IN_USE", f"HTTP {status}")
    check(fx.count_slots(order2["order_no"]) == 2, "IN_USE 订单仍占着 2 个时段（未释放）",
          f"slots={fx.count_slots(order2['order_no'])}")

    status, body = call("POST", f"/admin/reservations/{order2['order_no']}/force-cancel",
                        token=admin_token, body={"reason": "用户失联，柜格需回收"})
    check(
        status == 200 and body.get("previous_status") == "IN_USE"
        and body.get("status") == "FORCE_CANCELLED",
        "★ M11 对 IN_USE 订单强制取消 -> 200（不受取消时间窗限制，这正是强制取消的意义）",
        f"HTTP {status} {body.get('previous_status')} -> {body.get('status')}",
    )
    check(fx.count_slots(order2["order_no"]) == 0,
          "★ M11 强制取消 IN_USE 订单后柜格时段被释放（柜格可以被重新预约了）",
          f"slots={fx.count_slots(order2['order_no'])}")
    log2 = fx.last_status_log(order2["order_no"])
    check(
        log2.get("from_status") == "IN_USE" and log2.get("to_status") == "FORCE_CANCELLED"
        and log2.get("remark") == "用户失联，柜格需回收",
        "★ M11 状态日志 from_status 记的是真实前态（IN_USE）且 remark 保存了原因",
        str(log2),
    )

    # 柜格重新可用（实时派生，跨模块一致）
    s3, e3 = slot(6, 9)
    status, avail = call("GET", f"/cabinets/{cabinets[0]['id']}/availability",
                         query={"start_time": dt(s3), "end_time": dt(e3)})
    check(
        status == 200 and avail.get("available") is True,
        "★ M11 被强制取消后，柜格在该时段重新变为可预约（占用判定是实时的，没有脏状态）",
        f"available={avail.get('available')} derived={avail.get('derived_status')}",
    )

    fx.restore_config()


# ==================================================================
# J. M12 总览统计
# ==================================================================
def run_stats(admin_token: str, fx: Fixture, cabinet: dict) -> None:
    print("\n=== J. M12 运营总览 ===")
    status, stats = call("GET", "/admin/stats/overview", token=admin_token)
    check(status == 200, "M12 总览 -> 200", f"HTTP {status}")

    numerator, denominator = fx.numerator_denominator()
    check(
        stats.get("occupancy_numerator") == numerator
        and stats.get("occupancy_denominator") == denominator,
        "★ M12 分子分母与脚本独立重算的结果完全一致（口径可复算，不是随手一个数）",
        f"接口={stats.get('occupancy_numerator')}/{stats.get('occupancy_denominator')} "
        f"重算={numerator}/{denominator}",
    )
    expected_rate = round(numerator / denominator, 4) if denominator else None
    check(
        stats.get("occupancy_rate") == expected_rate,
        "M12 occupancy_rate = 分子/分母（保留 4 位）",
        f"rate={stats.get('occupancy_rate')} 期望={expected_rate}",
    )
    check(
        stats.get("point_count", 0) >= 2 and stats.get("cabinet_count", 0) >= 30,
        "M12 point_count / cabinet_count 覆盖全部寄存点与柜格",
        f"point_count={stats.get('point_count')} cabinet_count={stats.get('cabinet_count')}",
    )
    check(
        stats.get("today_order_count", 0) >= 2,
        "M12 today_order_count 统计到本次测试今天创建的订单",
        f"today_order_count={stats.get('today_order_count')}",
    )

    # ---- 用另一个接口的口径交叉验证分母 ----
    # 【为什么这条断言比"接口返回了数字"有价值得多】
    # 脚本自己的 numerator_denominator() 是照着 M12 的定义重算的，
    # 如果定义本身写错了，两边会一起错、断言照样通过（自证陷阱）。
    # 这里改用**另一个接口**（Q5 的 total_count）作为第三方口径：
    #     Σ Q5.total_count  =  分母  +  「有生效规格但当前不可服务」的柜格数
    # 左边来自 Q5（用户视角，只算生效规格），中间来自 M12，
    # 右边用一条独立 SQL 直接数。三者相互印证，任何一处算错都会暴露。
    start = datetime.combine(datetime.now().date() + timedelta(days=2), time(10, 0))
    end = start + timedelta(hours=1)
    status, points_page = call("GET", "/points", query={"page_size": 100})
    q5_total = 0
    q5_all_ok = True
    for point in (points_page.get("items") or []):
        status, avail = call(
            "GET", "/cabinets/availability",
            query={"point_id": point["id"], "start_time": dt(start), "end_time": dt(end)},
        )
        # 必须显式断言状态码：Q5 在「时间窗落在营业时间之外」时返回 400，
        # 如果这里只看 groups，一次 400 会被静默当成"这个寄存点没有柜格"，
        # 于是下面那条等式会以一个莫名其妙的差值失败 —— 排查半天才发现是窗口选错了。
        if status != 200:
            q5_all_ok = False
        for group in (avail or {}).get("groups", []):
            for t in group.get("types", []):
                q5_total += t["total_count"]
    check(
        q5_all_ok,
        "M12 交叉验证前置：每个寄存点的 Q5 查询都返回 200（时间窗必须在营业时间内，BR-05）",
        f"窗口={start}~{end}",
    )

    not_serviceable = fx.count(
        "SELECT COUNT(1) FROM cabinets c "
        "JOIN cabinet_types t ON t.id = c.type_id "
        "JOIN cabinet_groups g ON g.id = c.group_id "
        "JOIN storage_points p ON p.id = g.point_id "
        "WHERE t.is_active = 1 AND (c.physical_status <> 'AVAILABLE' "
        "OR g.status <> 'NORMAL' OR p.status <> 'OPEN')"
    )
    check(
        q5_total == denominator + not_serviceable,
        "★ M12 分母由三个独立数据源互证：ΣQ5.total_count == M12 分母 + 「有生效规格但不可服务」的柜格数"
        "（含本次特意用停用规格建出来的 ZT9-90，它必须被排除在分母之外）",
        f"ΣQ5={q5_total} 分母={denominator} 不可服务={not_serviceable}",
    )

    # ---- 跨模块：把一个柜格切成维护中，分母必须正好减少 1 ----
    before_num = stats.get("occupancy_numerator")
    status, body = call("PATCH", f"/admin/cabinets/{cabinet['id']}/status", token=admin_token,
                        body={"physical_status": "MAINTENANCE"})
    check(status == 200, "M12 造数：把一个空闲柜格切成维护中 -> 200", f"HTTP {status}")
    status, stats2 = call("GET", "/admin/stats/overview", token=admin_token)
    check(
        stats2.get("occupancy_denominator") == denominator - 1,
        "★ M12 柜格转维护中后分母正好 -1（占用率的分母确实是实时的可服务柜格数）",
        f"{denominator} -> {stats2.get('occupancy_denominator')}",
    )
    check(
        stats2.get("occupancy_numerator") == before_num,
        "M12 空闲柜格转维护中不影响分子（它本来就没被占用）",
        f"{before_num} -> {stats2.get('occupancy_numerator')}",
    )
    call("PATCH", f"/admin/cabinets/{cabinet['id']}/status", token=admin_token,
         body={"physical_status": "AVAILABLE"})
    status, stats3 = call("GET", "/admin/stats/overview", token=admin_token)
    check(
        stats3.get("occupancy_denominator") == denominator,
        "M12 还原为可用后分母回到原值",
        f"denominator={stats3.get('occupancy_denominator')}",
    )


# ==================================================================
# K. M13 手动触发 + M14 任务日志
# ==================================================================
def run_jobs_manual(admin_token: str, user_token: str, fx: Fixture, cabinet: dict) -> None:
    print("\n=== K. M13 手动触发超时释放 + M14 任务日志 ===")
    release_job = "release_expired_reservations"

    start = datetime.combine(datetime.now().date() + timedelta(days=6), time(10, 0))
    status, order = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinet["id"], "start_time": dt(start),
              "end_time": dt(start + timedelta(hours=1)),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m13_expired"},
    )
    check(status == 201, "M13 造数：创建订单 -> 201", f"HTTP {status}")
    order_no = order["order_no"]

    # 数据构造：把时间窗整体挪到过去，使其成为"超时未签到"的候选
    shifted = fx.shift_order_to_past(order_no, slot_count=2)
    check(
        fx.order_row(order_no)["status"] == "RESERVED",
        "数据构造：订单时间窗已挪到过去，状态仍是 RESERVED（成为超时释放候选）",
        f"end_time={shifted['end_time']}",
    )

    status, run1 = call("POST", "/admin/jobs/release-expired/run", token=admin_token)
    check(
        status == 200 and run1.get("trigger_type") == "MANUAL",
        "M13 手动触发 -> 200 且 trigger_type=MANUAL（与调度器/命令行区分开）",
        f"HTTP {status} trigger={run1.get('trigger_type')}",
    )
    check(
        run1.get("affected_count") == 1 and run1.get("released_slot_count") == 2
        and run1.get("result") == "SUCCESS",
        "M13 第一次触发处理 1 单、释放 2 个时段、结果 SUCCESS",
        f"affected={run1.get('affected_count')} released={run1.get('released_slot_count')}",
    )
    check(
        fx.order_row(order_no)["status"] == "EXPIRED"
        and fx.count_slots(order_no) == 0,
        "★ M13 订单被释放：状态 EXPIRED 且时段占用清零",
        f"status={fx.order_row(order_no)['status']} slots={fx.count_slots(order_no)}",
    )
    log = fx.last_status_log(order_no)
    check(
        log.get("operator_type") == "SYSTEM" and log.get("operator_id") is None,
        "★ M13 释放动作记在 SYSTEM 名下（不是操作管理员，避免审计上张冠李戴）",
        str(log),
    )

    status, run2 = call("POST", "/admin/jobs/release-expired/run", token=admin_token)
    check(
        status == 200 and run2.get("affected_count") == 0 and run2.get("scanned_count") == 0,
        "★ BR-37 通过管理端一键复现：第二次触发 affected_count = 0（重复执行无副作用）",
        f"affected={run2.get('affected_count')} scanned={run2.get('scanned_count')}",
    )
    check(
        run2.get("trigger_type") == "MANUAL" and run2.get("result") == "SUCCESS",
        "M13 第二次触发同样是 200 / MANUAL / SUCCESS（幂等不是靠报错实现的）",
        f"trigger={run2.get('trigger_type')} result={run2.get('result')}",
    )

    # ---- M14 ----
    status, logs = call("GET", "/admin/jobs/logs", token=admin_token,
                        query={"job_name": release_job, "page_size": 5})
    items = logs.get("items", []) if isinstance(logs, dict) else []
    check(
        status == 200 and len(items) >= 2,
        "M14 按 job_name 查日志 -> 200", f"HTTP {status} 条数={len(items)}",
    )
    newest_two = items[:2]
    check(
        [i["affected_count"] for i in newest_two] == [0, 1]
        and all(i["trigger_type"] == "MANUAL" for i in newest_two),
        "★ M14 最新两条日志正好是刚才的 MANUAL 触发：1 -> 0（幂等证据可以直接在页面上看到）",
        str([(i["trigger_type"], i["affected_count"]) for i in newest_two]),
    )
    check(
        all(i.get("duration_ms") is not None and i["duration_ms"] >= 0 for i in newest_two),
        "M14 duration_ms 由 started_at/finished_at 推导（表里没有这一列）",
        str([i.get("duration_ms") for i in newest_two]),
    )
    check(
        all(i["result"] == "SUCCESS" for i in newest_two),
        "M14 结果字段正常返回", str([i["result"] for i in newest_two]),
    )
    status, payload = call("GET", "/admin/jobs/logs", token=admin_token,
                           query={"job_name": "not_a_job"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M14 非法 job_name -> 400（避免静默返回空列表让人误以为没有执行记录）",
        f"HTTP {status} {code_of(payload)}",
    )


# ==================================================================
# L. M15 系统配置
# ==================================================================
def run_config_flow(admin_token: str, user_token: str, fx: Fixture, cabinet: dict) -> None:
    print("\n=== L. M15 系统配置 ===")
    status, configs = call("GET", "/admin/configs", token=admin_token)
    check(
        status == 200 and isinstance(configs, list) and len(configs) >= 10,
        "M15 查询全部配置 -> 200", f"HTTP {status} 条数={len(configs) if isinstance(configs, list) else '?'}",
    )
    one = next((c for c in configs if c["key"] == "max_advance_days"), {})
    check(
        one.get("value") == "7" and one.get("default_value") == "7" and one.get("is_default") is True
        and one.get("min_value") == 1,
        "M15 返回当前值/默认值/上下限（前端可直接做输入校验）",
        f"value={one.get('value')} min={one.get('min_value')} is_default={one.get('is_default')}",
    )

    original = one.get("value", "7")

    # ---- BR-04 端到端：把 max_advance_days 改成 1，第 3 天的订单必须被拒 ----
    start = datetime.combine(datetime.now().date() + timedelta(days=3), time(20, 0))
    status, before = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinet["id"], "start_time": dt(start),
              "end_time": dt(start + timedelta(hours=1)),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m15_before"},
    )
    check(status == 201, "M15 前置：默认 7 天窗口下第 3 天的订单可创建 -> 201", f"HTTP {status}")
    if status == 201:
        call("POST", f"/reservations/{before['order_no']}/cancel", token=user_token, body={})

    status, updated = call("PUT", "/admin/configs/max_advance_days", token=admin_token, body={"value": "1"})
    check(
        status == 200 and updated.get("value") == "1" and updated.get("is_default") is False,
        "M15 修改 max_advance_days = 1 -> 200（is_default 变为 false）",
        f"HTTP {status} value={updated.get('value')}",
    )

    status, payload = call(
        "POST", "/reservations", token=user_token,
        body={"cabinet_id": cabinet["id"], "start_time": dt(start),
              "end_time": dt(start + timedelta(hours=1)),
              "luggage_size": "SMALL", "idempotency_key": "e2e4admin_m15_after"},
    )
    check(
        status == 400 and code_of(payload) == "BOOKING_WINDOW_EXCEEDED",
        "★ BR-04 端到端：改配置后第 3 天的订单立刻被拒 -> 400 BOOKING_WINDOW_EXCEEDED（无需重启服务）",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- 值非法 ----
    status, payload = call("PUT", "/admin/configs/max_advance_days", token=admin_token, body={"value": "abc"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M15 值不是整数 -> 400（不会把配置表写坏）",
        f"HTTP {status} {code_of(payload)}",
    )
    status, payload = call("PUT", "/admin/configs/max_advance_days", token=admin_token, body={"value": "0"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M15 值低于下限（0 < min=1）-> 400",
        f"HTTP {status} {code_of(payload)}",
    )
    status, payload = call("PUT", "/admin/configs/slot_minutes", token=admin_token, body={"value": "45"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "M15 时间粒度 45 不能整除 60 -> 400（否则整点对齐会失效）",
        f"HTTP {status} {code_of(payload)}",
    )
    status, payload = call("PUT", "/admin/configs/min_slot_count", token=admin_token,
                           body={"value": "200"})
    check(
        status == 400 and code_of(payload) == "VALIDATION_ERROR",
        "★ M15 组合校验：最短 200 > 最长 144 -> 400（否则 BR-02 永远无法满足）",
        f"HTTP {status} {code_of(payload)}",
    )
    status, payload = call("PUT", "/admin/configs/not_exist_key", token=admin_token, body={"value": "1"})
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M15 未知配置键 -> 404（不允许凭空造配置项）",
        f"HTTP {status} {code_of(payload)}",
    )
    check(
        next(c for c in call("GET", "/admin/configs", token=admin_token)[1]
             if c["key"] == "max_advance_days")["value"] == "1",
        "★ M15 上述 4 次非法写入全部没有落库（配置仍是 1，校验发生在写之前）",
        "max_advance_days 仍为 1",
    )

    # ---- 还原 ----
    status, restored = call("PUT", "/admin/configs/max_advance_days", token=admin_token,
                            body={"value": original})
    check(
        status == 200 and restored.get("value") == original and restored.get("is_default") is True,
        f"M15 还原 max_advance_days = {original}",
        f"value={restored.get('value')}",
    )


# ==================================================================
# M. BR-11 寄存点关闭的跨模块影响（3A 遗漏，3B 补上）
# ==================================================================
def run_point_closed_effect(admin_token: str, fx: Fixture, point_id: int, cabinet: dict) -> None:
    print("\n=== M. BR-11 寄存点 CLOSED 对可用性的影响（3A 遗漏，本批次补测）===")
    start = datetime.combine(datetime.now().date() + timedelta(days=2), time(hour=10))
    end = start + timedelta(hours=1)

    status, avail = call("GET", f"/cabinets/{cabinet['id']}/availability",
                         query={"start_time": dt(start), "end_time": dt(end)})
    check(
        status == 200 and avail.get("available") is False
        and avail.get("derived_status") == "UNAVAILABLE",
        "★ BR-11 寄存点为 CLOSED 时，其下柜格返回不可用且 derived_status=UNAVAILABLE",
        f"available={avail.get('available')} derived={avail.get('derived_status')}",
    )

    status, reopened = call("PATCH", f"/admin/points/{point_id}/status", token=admin_token,
                            body={"status": "OPEN"})
    check(status == 200 and reopened.get("status") == "OPEN", "M3 改回 OPEN -> 200", f"HTTP {status}")

    status, avail2 = call("GET", f"/cabinets/{cabinet['id']}/availability",
                          query={"start_time": dt(start), "end_time": dt(end)})
    check(
        status == 200 and avail2.get("available") is True,
        "★ BR-11 改回 OPEN 后同一柜格立刻恢复可用（营业状态是实时生效的）",
        f"available={avail2.get('available')} derived={avail2.get('derived_status')}",
    )


# ==================================================================
# N. M6b 管理端柜格列表（批次 4 新增接口，P11 的数据源）
# ==================================================================
def run_group_cabinets(
    admin_token: str, user_token: str, fx: Fixture, group_id: int
) -> None:
    print("\n=== N. M6b 管理端柜格列表（P11 数据源）===")

    status, page = call("GET", f"/admin/groups/{group_id}/cabinets", token=admin_token)
    check(status == 200, "M6b 查询柜体下的柜格 -> 200", f"HTTP {status}")
    items = page.get("items", []) if isinstance(page, dict) else []
    codes = [item["code"] for item in items]
    check(
        page.get("cabinet_count") == 3 and codes == ["ZT9-01", "ZT9-02", "ZT9-03"],
        "M6b 返回该柜体下全部柜格，按编号升序",
        f"cabinet_count={page.get('cabinet_count')} codes={codes}",
    )
    check(
        page.get("group_code") == GROUP_CODE and page.get("status") == "NORMAL",
        "M6b 带上柜体与寄存点上下文（前端不必再查一次）",
        f"group_code={page.get('group_code')} status={page.get('status')}",
    )

    # ---- 关键断言：原始运维状态 与 派生状态 是两件事 ----
    # 此刻寄存点仍是 CLOSED（B 段末刻意留下的），所以：
    #   physical_status = AVAILABLE（柜格自己没问题）
    #   derived_status  = UNAVAILABLE（但用户现在约不了）
    # 管理页必须同时看到这两者，否则运维会对着"可用"的柜格排查"为什么用户约不上"。
    first = items[0] if items else {}
    check(
        first.get("physical_status") == "AVAILABLE" and first.get("derived_status") == "UNAVAILABLE",
        "★ M6b 同时返回原始 physical_status(AVAILABLE) 与派生 derived_status(UNAVAILABLE)，两者不同也如实展示",
        f"physical={first.get('physical_status')} derived={first.get('derived_status')}",
    )

    status, payload = call("GET", "/admin/groups/99999999/cabinets", token=admin_token)
    check(
        status == 404 and code_of(payload) == "RESOURCE_NOT_FOUND",
        "M6b 柜体不存在 -> 404",
        f"HTTP {status} {code_of(payload)}",
    )

    status, payload = call("GET", f"/admin/groups/{group_id}/cabinets", token=user_token)
    check(
        status == 403 and code_of(payload) == "AUTH_FORBIDDEN",
        "M6b 普通用户访问 -> 403",
        f"HTTP {status} {code_of(payload)}",
    )

    # ---- 这条接口存在的**根本理由**：规格停用的柜格 Q5 看不到，管理端必须看得到 ----
    status, type_x = call(
        "POST", "/admin/cabinet-types", token=admin_token,
        body={"code": "TT9X", "name": "待停用规格", "size_level": "SMALL",
              "width_mm": 300, "height_mm": 300, "depth_mm": 300, "price_per_slot": "1.00"},
    )
    check(status == 201, "M6b 造数：新建一个规格 TT9X -> 201", f"HTTP {status}")
    if status == 201:
        call("PUT", f"/admin/cabinet-types/{type_x['id']}", token=admin_token, body={"is_active": False})
        status, batch = call(
            "POST", f"/admin/groups/{group_id}/cabinets", token=admin_token,
            body={"prefix": CABINET_PREFIX, "count": 1, "type_id": type_x["id"], "start_index": 90},
        )
        check(
            status == 201 and batch.get("created") and batch["created"][0]["code"] == "ZT9-90",
            "M6b 造数：用**已停用**规格新增一个柜格 ZT9-90 -> 201（M6 允许，便于构造此场景）",
            f"HTTP {status} {batch.get('created')}",
        )

        status, page2 = call("GET", f"/admin/groups/{group_id}/cabinets", token=admin_token)
        codes2 = [item["code"] for item in page2.get("items", [])]
        check(
            "ZT9-90" in codes2 and page2.get("cabinet_count") == 4,
            "★ M6b 规格停用的柜格仍在管理端列表里（否则运维看不到、也就改不了它的状态）",
            f"codes={codes2}",
        )

        start = datetime.combine(datetime.now().date() + timedelta(days=2), time(11, 0))
        status, avail = call(
            "GET", "/cabinets/availability",
            query={"point_id": page2.get("point_id"), "start_time": dt(start),
                   "end_time": dt(start + timedelta(hours=1))},
        )
        q5_codes = [
            cab["code"]
            for group in avail.get("groups", [])
            for t in group.get("types", [])
            for cab in t.get("cabinets", [])
        ]
        check(
            "ZT9-90" not in q5_codes and "ZT9-01" in q5_codes,
            "★ M6b 同一个柜格在 Q5（用户视角）里被 BR-12 排除，在管理端（M6b）里仍然可见 —— 这就是必须新增这条接口的原因",
            f"Q5 里包含 ZT9-90 吗={('ZT9-90' in q5_codes)}",
        )


# ==================================================================
# 主流程
# ==================================================================
def main() -> int:
    fx = Fixture()
    try:
        admin_token = login("admin")
        user_token = login("user02")
        other_token = login("user01")

        print("=" * 72)
        print("第四阶段 · 批次 3A + 3B：管理端 M1 ~ M15")
        print(f"接口地址 : {BASE}")
        print("=" * 72)

        run_permissions(admin_token, user_token, fx)

        # ---- 基础资料（M1 ~ M9）----
        point_id = run_point_flow(admin_token, fx)
        group_id = run_group_flow(admin_token, fx, point_id)
        # 先建规格（M8），再批量建柜格（M6）让柜格引用这个规格
        type_id = run_type_create(admin_token, fx)
        created = run_cabinet_batch(admin_token, fx, group_id, type_id)

        # ---- 订单 / 运维 / 配置（M10 ~ M15）----
        # 【为什么把这批放在 M9 之前】
        # M9 会停用规格 TT9 验证 BR-12，一旦停用，
        # 所有用这些柜格下单的用例都会先撞上 CABINET_TYPE_DISABLED。
        # 所以顺序刻意安排成"先把所有需要下单的用例跑完，最后再停用规格"。
        if created:
            # M6b：管理端柜格列表（批次 4 新增接口）。
            # 刻意放在 BR-11 之前：此刻寄存点还是 CLOSED，
            # 正好用来验证"原始 physical_status 与派生 derived_status 是两件事"。
            run_group_cabinets(admin_token, user_token, fx, group_id)

            # BR-11：寄存点 CLOSED（B 段末刻意留下的状态）-> 其下柜格不可用；
            # 验完立即改回 OPEN，供后续下单用例使用。
            run_point_closed_effect(admin_token, fx, point_id, created[0])

            run_cabinet_status(admin_token, user_token, fx, created[0])
            run_admin_reservation_query(admin_token, user_token, other_token, fx, point_id, created)
            run_force_cancel(admin_token, user_token, fx, created)
            run_stats(admin_token, fx, created[2])
            run_jobs_manual(admin_token, user_token, fx, created[1])
            run_config_flow(admin_token, user_token, fx, created[0])

            # M9 放到最后：停用规格会挡住后续所有下单
            run_type_update(admin_token, user_token, fx, created[0], type_id)
    except Exception as exc:  # noqa: BLE001
        results.append((False, f"脚本异常：{exc!r}"))
        print(f"\n[EXCEPTION] {exc!r}")
        import traceback

        traceback.print_exc()
    finally:
        fx.restore_config()
        fx.cleanup()
        residue = fx.residue()
        print("\n=== 收尾检查 ===")
        print(f"  数据库残留: {residue}")
        clean = all(value == 0 for value in residue.values())
        check(clean, "本次测试创建的数据已全部清理，数据库回到干净状态", str(residue))
        fx.db.close()

    passed = sum(1 for ok, _ in results if ok)
    failed = len(results) - passed
    print("\n" + "=" * 72)
    print(f"批次 3A + 3B 验证结果：{passed} 通过 / {failed} 失败 / 共 {len(results)} 项")
    if failed:
        print("失败项：")
        for ok, name in results:
            if not ok:
                print(f"  - {name}")
    print("=" * 72)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
