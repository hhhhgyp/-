# -*- coding: utf-8 -*-
"""
第四阶段 · 批次 2（超时释放 / 逾期标记定时任务）端到端验证。

真实 HTTP + 真实 MySQL + 真实子进程执行 CLI。

两个模式：

【默认模式】验证两个任务的处理逻辑与幂等性（需要服务以 --no-scheduler 启动）
  A. release_expired_reservations
     - 把「超时未签到」的订单置为 EXPIRED 并释放柜格时段
     - **幂等的关键证据（BR-37）**：连续跑两次 CLI，
       第一次 affected_count = N，第二次 affected_count = 0，
       且订单的 reservation_status_logs **始终只有 1 条**（没有被释放两次）
  C. mark_overdue_reservations
     - 把「到期末取件」的订单置为 OVERDUE
     - **不得释放柜格**（BR-39）：reservation_slots 记录数必须保持 2 条不变
     - 顺带补上批次 1 缺失的“OVERDUE 也能补取”路径：OVERDUE -> COMPLETED

【--scheduler-check 模式】验证 APScheduler 真的会自动触发（需要服务带调度器启动）
  - 构造一条超时订单，然后**什么都不做**，等调度器自己把它处理掉
  - 断言 job_execution_logs 里出现 trigger_type = 'SCHEDULER' 的记录
  这一条是手动触发（MANUAL/SCRIPT）永远证明不了的：
  它回答的是"定时任务到底有没有在跑"，而不是"任务逻辑对不对"。

==================================================================
【为什么时间窗要靠"改数据"来构造】
==================================================================
两个任务的触发条件都依赖"时间已经流逝"：
    超时释放：checkin_deadline <= NOW()   （至少要等到 start_time + 30 分钟）
    逾期标记：end_time < NOW()            （至少要等到 start_time + 30 分钟）
正常下单最早也只能约到 5 分钟之后，所以最短也要等 35 分钟才会命中。
测试不可能真的等 —— 标准做法是**把订单的时间窗整体挪到过去**，
这等价于"快进了时钟"。本脚本用一个明确的 `shift_order_to_past()`
集中做这件事，并把 reservation_slots 一起挪，保证数据自洽。
这是【数据构造】，不是绕过校验：接口层的时间规则该测的都测过了（第三阶段）。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timedelta
from typing import Any

sys.path.insert(0, ".")

BASE = os.environ.get("PHASE4_BASE_URL", "http://127.0.0.1:8134/api/v1")
KEY_PREFIX = "e2e4b_"
SLOT_MINUTES = 30

results: list[tuple[bool, str]] = []


def check(ok: bool, name: str, extra: str = "") -> None:
    results.append((bool(ok), name))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {extra}" if extra else ""))


def call(method: str, path: str, *, token: str | None = None, body: dict | None = None,
         query: dict | None = None) -> tuple[int, Any]:
    url = BASE + path
    if query:
        clean = {k: v for k, v in query.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            return exc.code, (json.loads(raw) if raw else None)
        except json.JSONDecodeError:
            return exc.code, {"raw": raw}


def code_of(payload: Any) -> str | None:
    return payload.get("code") if isinstance(payload, dict) else None


def detail_text(payload: Any) -> str:
    detail = payload.get("detail") if isinstance(payload, dict) else payload
    return json.dumps(detail, ensure_ascii=False)[:200]


def login(username: str, password: str = "Demo@123456") -> str:
    status, body = call("POST", "/auth/login", body={"username": username, "password": password})
    assert status == 200, f"登录失败 {username}: {status} {body}"
    return body["access_token"]


def run_cli() -> str:
    """
    以子进程执行 `python -m app.jobs.release_expired`。

    特意用子进程而不是直接调用函数：
    要验证的正是"不启服务也能跑"这个入口本身（设计方案 9.1 第三种触发方式）。
    """
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    proc = subprocess.run(
        [sys.executable, "-m", "app.jobs.release_expired"],
        capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=120,
    )
    return (proc.stdout or "") + (proc.stderr or "")


# ==================================================================
# 数据库夹具
# ==================================================================
class Fixture:
    def __init__(self) -> None:
        from sqlalchemy import text

        from app.db.session import SessionLocal

        self.db = SessionLocal()
        self.created_orders: list[str] = []
        self.t0: datetime | None = None
        self._cleanup_residue()
        row = self.db.execute(
            text(
                "SELECT c.id, c.code FROM cabinets c "
                "JOIN cabinet_types t ON t.id = c.type_id "
                "JOIN cabinet_groups g ON g.id = c.group_id "
                "JOIN storage_points p ON p.id = g.point_id "
                "WHERE c.physical_status = 'AVAILABLE' AND t.is_active = 1 "
                "AND g.status = 'NORMAL' AND p.status = 'OPEN' ORDER BY c.code LIMIT 1"
            )
        ).first()
        assert row is not None, "找不到可用柜格，请先执行 python -m app.db.seed"
        self.cab_id, self.cab_code = row[0], row[1]
        self.config_backup: dict[str, str | None] = {}
        self.t0 = self.db_now()

    # ---------- 残留清理 ----------
    def _cleanup_residue(self) -> None:
        from sqlalchemy import text

        ids = self.db.execute(
            text("SELECT id FROM reservations WHERE idempotency_key LIKE :p"),
            {"p": KEY_PREFIX + "%"},
        ).scalars().all()
        for rid in ids:
            self.db.execute(text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid})
            self.db.execute(text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"), {"i": rid})
            self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
        if ids:
            self.db.commit()
        self.db.execute(
            text("UPDATE system_config SET config_value = '15' WHERE config_key = 'checkin_early_minutes'")
        )
        self.db.commit()

    # ---------- 配置 ----------
    def _refresh(self) -> None:
        self.db.commit()

    def get_config(self, key: str) -> str | None:
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(
            text("SELECT config_value FROM system_config WHERE config_key = :k"), {"k": key}
        ).scalar()

    def set_config(self, key: str, value: str) -> None:
        from sqlalchemy import text

        if key not in self.config_backup:
            self.config_backup[key] = self.get_config(key)
        self.db.execute(
            text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
            {"v": value, "k": key},
        )
        self.db.commit()

    # ---------- 时间底座 ----------
    def db_now(self) -> datetime:
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(text("SELECT NOW()")).scalar_one()

    def shift_order_to_past(self, order_no: str, slot_count: int = 2) -> dict:
        """
        【数据构造】把订单的时间窗整体挪到过去，等价于"快进了时钟"。

        新窗口 = [floor30(now - 3 小时), +slot_count 个时段]
        无论当前是几点，end_time 至少比 now 早 1.5 小时，两个任务的条件都能命中。
        同时重建 reservation_slots，保证"时段散列位置"与时间窗一致（数据自洽）。
        """
        from sqlalchemy import text

        now = self.db_now()
        base = now - timedelta(hours=3)
        new_start = base.replace(second=0, microsecond=0) - timedelta(minutes=base.minute % SLOT_MINUTES)
        new_end = new_start + timedelta(minutes=SLOT_MINUTES * slot_count)
        new_deadline = new_start + timedelta(minutes=30)  # BR-22：start + 30 分钟

        row = self.db.execute(
            text("SELECT id, cabinet_id FROM reservations WHERE order_no = :o"), {"o": order_no}
        ).first()
        assert row is not None, f"订单不存在：{order_no}"
        rid, cabinet_id = row[0], row[1]

        self.db.execute(
            text(
                "UPDATE reservations SET start_time = :s, end_time = :e, checkin_deadline = :d "
                "WHERE id = :i"
            ),
            {"s": new_start, "e": new_end, "d": new_deadline, "i": rid},
        )
        self.db.execute(text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid})
        for index in range(slot_count):
            self.db.execute(
                text(
                    "INSERT INTO reservation_slots (reservation_id, cabinet_id, slot_start) "
                    "VALUES (:r, :c, :s)"
                ),
                {"r": rid, "c": cabinet_id, "s": new_start + timedelta(minutes=SLOT_MINUTES * index)},
            )
        self.db.commit()
        return {"order_no": order_no, "id": rid, "start_time": str(new_start), "end_time": str(new_end),
                "checkin_deadline": str(new_deadline)}

    # ---------- 读取 ----------
    def order_row(self, order_no: str) -> dict:
        from sqlalchemy import text

        self._refresh()
        row = self.db.execute(
            text(
                "SELECT status, start_time, end_time, checkin_deadline, cancelled_at, cancel_reason "
                "FROM reservations WHERE order_no = :o"
            ),
            {"o": order_no},
        ).first()
        assert row is not None
        return {"status": row[0], "start_time": row[1], "end_time": row[2],
                "checkin_deadline": row[3], "cancelled_at": row[4], "cancel_reason": row[5]}

    def count_slots(self, order_no: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(self.db.execute(
            text(
                "SELECT COUNT(*) FROM reservation_slots rs "
                "JOIN reservations r ON r.id = rs.reservation_id WHERE r.order_no = :o"
            ), {"o": order_no},
        ).scalar())

    def status_log_rows(self, order_no: str) -> list[tuple]:
        from sqlalchemy import text

        self._refresh()
        return [tuple(r) for r in self.db.execute(
            text(
                "SELECT l.from_status, l.to_status, l.operator_type, l.operator_id, l.remark "
                "FROM reservation_status_logs l JOIN reservations r ON r.id = l.reservation_id "
                "WHERE r.order_no = :o ORDER BY l.id"
            ), {"o": order_no},
        ).all()]

    def latest_job_log(self, job_name: str, trigger_type: str | None = None) -> dict | None:
        """
        读取某个任务最近一条执行日志。

        【为什么要按 trigger_type 过滤，而不是直接取"最新一行"】
        本机可能同时有**别的服务**在跑（例如开发者自己开着端口 8000 的服务），
        它的调度器也会往同一张表里写 SCHEDULER 记录。
        如果直接取"最新一行"，断言就可能读到别人的记录 ——
        于是出现"测试通过，但通过的原因根本不是被测代码"这种最危险的假阳性。

        因此：本脚本产生的 CLI 记录一律是 SCRIPT，
        断言时显式指定 trigger_type，把自己产生的记录与外部服务的记录隔离开。
        """
        from sqlalchemy import text

        self._refresh()
        sql = "SELECT scanned_count, affected_count, result, trigger_type, error_message FROM job_execution_logs WHERE job_name = :j"
        params: dict = {"j": job_name}
        if trigger_type is not None:
            sql += " AND trigger_type = :t"
            params["t"] = trigger_type
        row = self.db.execute(text(sql + " ORDER BY id DESC LIMIT 1"), params).first()
        if row is None:
            return None
        return {"scanned_count": row[0], "affected_count": row[1], "result": row[2],
                "trigger_type": row[3], "error_message": row[4]}

    def count_job_logs_since(self, trigger_type: str) -> int:
        """
        t0 之后写入的任务日志行数，按触发方式区分：
            SCRIPT    —— 本脚本调用的 CLI 产生的（收尾时必须清零）
            SCHEDULER —— 进程内调度器产生的（可能是外部正在运行的服务，不属于测试残留）
        """
        from sqlalchemy import text

        self._refresh()
        return int(self.db.execute(
            text(
                "SELECT COUNT(*) FROM job_execution_logs "
                "WHERE trigger_type = :t AND started_at >= :s"
            ), {"t": trigger_type, "s": self.t0},
        ).scalar())

    def count_scheduler_logs(self, job_name: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(self.db.execute(
            text(
                "SELECT COUNT(*) FROM job_execution_logs "
                "WHERE job_name = :j AND trigger_type = 'SCHEDULER' AND started_at >= :t"
            ), {"j": job_name, "t": self.t0},
        ).scalar())

    # ---------- 收尾 ----------
    def restore_all(self) -> None:
        from sqlalchemy import text

        for key, value in self.config_backup.items():
            self.db.execute(
                text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
                {"v": value, "k": key},
            )
        self.db.execute(
            text("UPDATE system_config SET config_value = '15' WHERE config_key = 'checkin_early_minutes'")
        )
        for order_no in self.created_orders:
            rid = self.db.execute(
                text("SELECT id FROM reservations WHERE order_no = :o"), {"o": order_no}
            ).scalar()
            if rid:
                self.db.execute(text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid})
                self.db.execute(text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"), {"i": rid})
                self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
        # 本次运行产生的任务日志也要清掉，否则"数据库干净"无法成立
        if self.t0 is not None:
            self.db.execute(
                text("DELETE FROM job_execution_logs WHERE started_at >= :t"), {"t": self.t0}
            )
        self.db.commit()

    def residue_report(self) -> dict:
        from sqlalchemy import text

        self._refresh()
        return {
            "reservations": int(self.db.execute(text("SELECT COUNT(*) FROM reservations")).scalar()),
            "reservation_slots": int(self.db.execute(text("SELECT COUNT(*) FROM reservation_slots")).scalar()),
            "reservation_status_logs": int(self.db.execute(text("SELECT COUNT(*) FROM reservation_status_logs")).scalar()),
            "job_execution_logs": int(self.db.execute(text("SELECT COUNT(*) FROM job_execution_logs")).scalar()),
            "checkin_early_minutes": self.get_config("checkin_early_minutes"),
            "release_job_interval_seconds": self.get_config("release_job_interval_seconds"),
        }


# ==================================================================
# 公共动作
# ==================================================================
def create_order(token: str, cabinet_id: int, start: datetime, end: datetime, tag: str) -> tuple[int, Any]:
    return call("POST", "/reservations", token=token, body={
        "cabinet_id": cabinet_id,
        "start_time": start.strftime("%Y-%m-%dT%H:%M:%S"),
        "end_time": end.strftime("%Y-%m-%dT%H:%M:%S"),
        "luggage_size": "SMALL",
        "idempotency_key": KEY_PREFIX + tag + "_" + uuid.uuid4().hex[:8],
    })


def future_window(fx: Fixture, hour: int = 10, hours: int = 1) -> tuple[datetime, datetime]:
    day = (fx.db_now() + timedelta(days=1)).date()
    start = datetime.combine(day, datetime.min.time()).replace(hour=hour)
    return start, start + timedelta(hours=hours)


# ==================================================================
# 默认模式：任务逻辑 + 幂等
# ==================================================================
def run_phase1(fx: Fixture) -> None:
    from app.core.constants import JobName

    token = login("user02")
    release_job = JobName.RELEASE_EXPIRED_RESERVATIONS.value
    overdue_job = JobName.MARK_OVERDUE_RESERVATIONS.value

    # ---------------- A. 超时释放 + 幂等 ----------------
    print("\n=== A. release_expired_reservations：释放 + 连续执行两次的幂等证据 ===")

    start, end = future_window(fx, hour=10)
    status, o1 = create_order(token, fx.cab_id, start, end, "o1")
    check(status == 201, "创建订单 O1 -> 201", f"HTTP {status} {detail_text(o1)}")
    o1no = o1["order_no"]
    fx.created_orders.append(o1no)
    print(f"        O1 = {o1no}")

    info = fx.shift_order_to_past(o1no)
    print(f"        数据构造：时间窗挪到过去 {info['start_time']} ~ {info['end_time']}"
          f"（checkin_deadline={info['checkin_deadline']}）")
    check(fx.count_slots(o1no) == 2, "挪动后时段占用重建为 2 条", f"实际 {fx.count_slots(o1no)}")

    print("\n  --- 第一次执行 CLI ---")
    out1 = run_cli()
    print("        " + out1.strip().replace("\n", "\n        ")[:600])

    row = fx.order_row(o1no)
    check(row["status"] == "EXPIRED", "第 1 次执行后：订单状态 -> EXPIRED", str(row["status"]))
    check(row["cancelled_at"] is not None, "第 1 次执行后：写入 cancelled_at", str(row["cancelled_at"]))
    check(
        "超时未签到" in (row["cancel_reason"] or ""),
        "第 1 次执行后：cancel_reason 记录了释放原因",
        str(row["cancel_reason"]),
    )
    check(fx.count_slots(o1no) == 0, "第 1 次执行后：柜格时段已释放（0 条）", f"实际 {fx.count_slots(o1no)}")

    logs1 = fx.status_log_rows(o1no)
    check(len(logs1) == 2, "第 1 次执行后：状态日志 = 创建 + 释放，共 2 条", str([(x[0], x[1]) for x in logs1]))
    check(
        logs1[-1][0] == "RESERVED" and logs1[-1][1] == "EXPIRED",
        "第 1 次执行后：新增日志为 RESERVED -> EXPIRED",
        str((logs1[-1][0], logs1[-1][1])),
    )
    check(
        logs1[-1][2] == "SYSTEM" and logs1[-1][3] is None,
        "第 1 次执行后：操作人为 SYSTEM 且 operator_id 为 null（BR-33）",
        f"{logs1[-1][2]} / {logs1[-1][3]}",
    )

    job1 = fx.latest_job_log(release_job, "SCRIPT")
    check(job1 is not None and job1["affected_count"] == 1, "第 1 次：任务日志 affected_count = 1", str(job1))
    check(job1 is not None and job1["result"] == "SUCCESS", "第 1 次：任务日志 result = SUCCESS", str(job1))
    check(
        job1 is not None and job1["trigger_type"] == "SCRIPT",
        "第 1 次：trigger_type = SCRIPT（CLI 入口）",
        str(job1),
    )

    print("\n  --- 第二次执行 CLI（什么都不该发生）---")
    out2 = run_cli()
    print("        " + out2.strip().replace("\n", "\n        ")[:600])

    row_after = fx.order_row(o1no)
    check(row_after["status"] == "EXPIRED", "第 2 次执行后：状态仍是 EXPIRED", str(row_after["status"]))
    check(fx.count_slots(o1no) == 0, "第 2 次执行后：时段占用仍是 0 条", f"实际 {fx.count_slots(o1no)}")

    logs2 = fx.status_log_rows(o1no)
    check(
        len(logs2) == 2,
        "★ BR-37 幂等关键证据：状态日志仍是 2 条，没有被重复释放两次",
        f"第 1 次后 2 条，第 2 次后 {len(logs2)} 条",
    )

    job2 = fx.latest_job_log(release_job, "SCRIPT")
    check(
        job2 is not None and job2["affected_count"] == 0,
        "★ BR-37：第 2 次任务日志 affected_count = 0（条件不再命中）",
        str(job2),
    )
    check(job2 is not None and job2["result"] == "SUCCESS", "第 2 次：任务日志 result = SUCCESS", str(job2))

    # ---------------- C. 逾期标记 + OVERDUE 补取 ----------------
    print("\n=== C. mark_overdue_reservations：标记逾期 + 不释放柜格 + OVERDUE 补取 ===")

    fx.set_config("checkin_early_minutes", "2880")
    check(fx.get_config("checkin_early_minutes") == "2880", "临时放宽签到窗口（数据构造，收尾还原）")

    start2, end2 = future_window(fx, hour=14)
    status, o2 = create_order(token, fx.cab_id, start2, end2, "o2")
    check(status == 201, "创建订单 O2 -> 201", f"HTTP {status} {detail_text(o2)}")
    o2no = o2["order_no"]
    fx.created_orders.append(o2no)
    print(f"        O2 = {o2no}")

    status, body = call("POST", f"/reservations/{o2no}/check-in", token=token)
    check(status == 200 and body.get("status") == "IN_USE", "O2 签到 -> IN_USE", f"HTTP {status}")

    fx.shift_order_to_past(o2no)
    row = fx.order_row(o2no)
    check(row["end_time"] < fx.db_now(), "数据构造：O2 的 end_time 已在过去", str(row["end_time"]))
    check(fx.count_slots(o2no) == 2, "挪动后 O2 的时段占用为 2 条", f"实际 {fx.count_slots(o2no)}")

    print("\n  --- 执行 CLI（应把 O2 标记为 OVERDUE）---")
    out3 = run_cli()
    print("        " + out3.strip().replace("\n", "\n        ")[:600])

    row = fx.order_row(o2no)
    check(row["status"] == "OVERDUE", "O2 -> OVERDUE（到期末取件）", str(row["status"]))
    check(
        fx.count_slots(o2no) == 2,
        "★ BR-39：标记逾期【不】释放柜格，时段占用仍为 2 条",
        f"实际 {fx.count_slots(o2no)}",
    )

    logs = fx.status_log_rows(o2no)
    check(
        (logs[-1][0], logs[-1][1]) == ("IN_USE", "OVERDUE"),
        "新增日志为 IN_USE -> OVERDUE",
        str((logs[-1][0], logs[-1][1])),
    )
    check(
        logs[-1][2] == "SYSTEM" and "不释放柜格" in (logs[-1][4] or ""),
        "逾期日志由 SYSTEM 写入，且备注说明不释放柜格",
        str(logs[-1][4]),
    )

    job3 = fx.latest_job_log(overdue_job, "SCRIPT")
    check(job3 is not None and job3["affected_count"] == 1, "逾期任务日志 affected_count = 1", str(job3))

    # 补上批次 1 的缺口：OVERDUE 状态下也能补取
    status, body = call("POST", f"/reservations/{o2no}/complete", token=token)
    check(
        status == 200 and body.get("status") == "COMPLETED",
        "★ OVERDUE 也能补取（BR-23）：-> 200 / COMPLETED",
        f"HTTP {status} {detail_text(body)}",
    )
    check(
        body.get("released_slot_count") == 2,
        "补取时释放剩余时段 2 条（BR-24）",
        f"released_slot_count={body.get('released_slot_count')}",
    )
    check(fx.count_slots(o2no) == 0, "补取后时段占用清空", f"实际 {fx.count_slots(o2no)}")

    logs = fx.status_log_rows(o2no)
    check(len(logs) == 4, "O2 状态日志共 4 条（创建/签到/逾期/取件）", str([(x[0], x[1]) for x in logs]))
    check(
        (logs[-1][0], logs[-1][1]) == ("OVERDUE", "COMPLETED"),
        "最后一条日志为 OVERDUE -> COMPLETED",
        str((logs[-1][0], logs[-1][1])),
    )


# ==================================================================
# --scheduler-check 模式
# ==================================================================
def run_scheduler_check(fx: Fixture) -> None:
    from app.core.constants import JobName

    release_job = JobName.RELEASE_EXPIRED_RESERVATIONS.value
    token = login("user02")

    print("\n=== D. APScheduler 自动触发（本模式下【不做任何手动触发】）===")

    start, end = future_window(fx, hour=10)
    status, o3 = create_order(token, fx.cab_id, start, end, "o3")
    check(status == 201, "创建订单 O3 -> 201", f"HTTP {status} {detail_text(o3)}")
    o3no = o3["order_no"]
    fx.created_orders.append(o3no)
    print(f"        O3 = {o3no}")

    before = fx.count_scheduler_logs(release_job)
    info = fx.shift_order_to_past(o3no)
    print(f"        数据构造：时间窗挪到过去 {info['start_time']} ~ {info['end_time']}")
    print(f"        构造前 SCHEDULER 触发次数 = {before}，现在开始等待调度器自己发现这条订单…")

    deadline = time.time() + 60
    observed = None
    waited = 0
    while time.time() < deadline:
        time.sleep(3)
        waited += 3
        if fx.order_row(o3no)["status"] == "EXPIRED":
            observed = waited
            break

    check(observed is not None, "调度器在等待期内自动把 O3 置为 EXPIRED", f"等待 {observed} 秒")
    if observed is not None:
        check(fx.count_slots(o3no) == 0, "自动释放后时段占用为 0 条", f"实际 {fx.count_slots(o3no)}")
        logs = fx.status_log_rows(o3no)
        check(
            len(logs) == 2 and (logs[-1][0], logs[-1][1]) == ("RESERVED", "EXPIRED"),
            "自动释放同样留下 RESERVED -> EXPIRED 审计日志（BR-33）",
            str([(x[0], x[1]) for x in logs]),
        )
        after = fx.count_scheduler_logs(release_job)
        check(after > before, "★ job_execution_logs 出现 trigger_type = SCHEDULER 的记录",
              f"{before} -> {after}")
        job = fx.latest_job_log(release_job, "SCHEDULER")
        check(
            job is not None and job["trigger_type"] == "SCHEDULER",
            "最近一条任务日志的 trigger_type = SCHEDULER",
            str(job),
        )


def main() -> int:
    scheduler_check = "--scheduler-check" in sys.argv
    fx = Fixture()
    try:
        print("=" * 70)
        print("第四阶段 · 批次 2：超时释放 / 逾期标记定时任务")
        print(f"接口地址 : {BASE}")
        print(f"测试柜格 : {fx.cab_code} (id={fx.cab_id})")
        print(f"模式     : {'调度器自动触发检查' if scheduler_check else '任务逻辑 + 幂等'}")
        print("=" * 70)
        if scheduler_check:
            run_scheduler_check(fx)
        else:
            run_phase1(fx)
    except Exception as exc:  # noqa: BLE001
        results.append((False, f"脚本异常：{exc!r}"))
        print(f"\n[EXCEPTION] {exc!r}")
    finally:
        fx.restore_all()
        report = fx.residue_report()
        own_logs = fx.count_job_logs_since("SCRIPT")
        external_logs = fx.count_job_logs_since("SCHEDULER")
        print("\n=== 收尾检查 ===")
        print(f"  业务数据残留 : {report}")
        print(f"  本次 CLI 产生的任务日志（SCRIPT，必须为 0）  : {own_logs}")
        print(f"  外部调度器写入的任务日志（SCHEDULER，不算残留）: {external_logs}")
        if external_logs and not scheduler_check:
            print("  [INFO] 本机还有其它服务在运行：它的调度器每隔一段时间就会往 job_execution_logs 写一行。")
            print("  [INFO] 这不影响上面的功能断言（断言已按 trigger_type 隔离），但做定时任务验证时")
            print("         建议给测试服务加 --no-scheduler，并暂停其它已开启的服务 —— 否则外部调度器")
            print("         可能抢先处理掉候选订单，让 affected_count 类断言变得难以复现。")
        # 调度器检查模式下，被测服务本身就在持续写 SCHEDULER 日志，无法与外部服务的记录区分，
        # 因此该模式只要求业务数据干净（停服后由外部统一清理任务日志）。
        clean = (
            report["reservations"] == 0
            and report["reservation_slots"] == 0
            and report["reservation_status_logs"] == 0
            and report["checkin_early_minutes"] == "15"
            and (scheduler_check or own_logs == 0)
        )
        check(clean, "业务数据与配置已还原，本次运行产生的任务日志已清空",
              f"业务残留 {report['reservations']}/{report['reservation_slots']}/{report['reservation_status_logs']}"
              f"，SCRIPT 日志 {own_logs}")
        fx.db.close()

    passed = sum(1 for ok, _ in results if ok)
    failed = len(results) - passed
    print("\n" + "=" * 70)
    print(f"批次 2 验证结果：{passed} 通过 / {failed} 失败 / 共 {len(results)} 项")
    if failed:
        print("失败项：")
        for ok, name in results:
            if not ok:
                print(f"  - {name}")
    print("=" * 70)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
