# -*- coding: utf-8 -*-
"""
第四阶段 · 批次 1（R5 签到存入 / R6 完成取件）端到端验证。

真实 HTTP + 真实 MySQL。分三部分：

  A. 前置条件不满足时必须被拦住（默认配置）
     - 提前太久签到      -> 409 CHECKIN_WINDOW_INVALID（BR-21 下界）
     - 没签到就取件      -> 409 ORDER_STATUS_NOT_ALLOWED（BR-23）
     - 他人订单签到/取件 -> 403（BR-27）
     - 订单不存在        -> 404
     - 且被拒绝的请求不得留下任何状态日志 / 时段变更（BR-31 / BR-32 的延伸）

  B. 走通完整生命周期 RESERVED -> IN_USE -> COMPLETED
     - 签到【不】释放时段（行李在柜内，柜格仍被占用）
     - 取件【立即】释放剩余时段（BR-24），该时段马上可被别人预约
     - 终态不可再变更（BR-34）

  C. 已取消的订单不能再签到 / 取件

【关于"不等到明天也能测签到窗口"】
BR-21 的签到窗口下界 = start_time - checkin_early_minutes，是**配置项**。
把 checkin_early_minutes 临时调大到 2880 分钟（2 天），
就等价于"把时钟拨到了明天"，于是可以直接对一个"明天开始"的订单签到。
这正是设计方案 5.10 节把这些边界参数做成 system_config 的目的 ——
让边界用例不必真的等，也不必改代码。
脚本结束会把配置改回原值（本用例的"数据构造"步骤，不是绕过规则）。

用法（先启动服务，再执行）：

    cd backend
    .\\.venv\\Scripts\\Activate.ps1
    python run.py --port 8133 --no-reload     # 另开一个窗口

    python tools\\phase4_e2e_lifecycle.py
    # 或者换个端口：
    $env:PHASE4_BASE_URL="http://127.0.0.1:8000/api/v1"
    python tools\\phase4_e2e_lifecycle.py

退出码 0 表示全部用例通过。脚本会自行清理它创建的订单与临时改动的配置项。
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timedelta
from typing import Any

sys.path.insert(0, ".")

BASE = os.environ.get("PHASE4_BASE_URL", "http://127.0.0.1:8133/api/v1")
KEY_PREFIX = "e2e4a_"
CONFIG_KEY = "checkin_early_minutes"
CONFIG_TEMP_VALUE = "2880"

results: list[tuple[bool, str]] = []


def check(ok: bool, name: str, extra: str = "") -> None:
    results.append((bool(ok), name))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {extra}" if extra else ""))


def call(
    method: str,
    path: str,
    *,
    token: str | None = None,
    body: dict | None = None,
    query: dict | None = None,
) -> tuple[int, Any]:
    url = BASE + path
    if query:
        clean = {k: v for k, v in query.items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            return exc.code, (json.loads(raw) if raw else None)
        except json.JSONDecodeError:
            return exc.code, {"raw": raw}


def code_of(payload: Any) -> str | None:
    return payload.get("code") if isinstance(payload, dict) else None


def detail_text(payload: Any) -> str:
    detail = payload.get("detail") if isinstance(payload, dict) else payload
    return json.dumps(detail, ensure_ascii=False)[:200]


def hint_of(payload: Any) -> str:
    detail = payload.get("detail") if isinstance(payload, dict) else None
    return (detail or {}).get("hint", "") if isinstance(detail, dict) else ""


def login(username: str, password: str = "Demo@123456") -> str:
    status, body = call("POST", "/auth/login", body={"username": username, "password": password})
    assert status == 200, f"登录失败 {username}: {status} {body}"
    return body["access_token"]


# ==================================================================
# 数据库夹具
# ==================================================================
class Fixture:
    def __init__(self) -> None:
        from sqlalchemy import text

        from app.db.session import SessionLocal

        self.db = SessionLocal()
        self.config_original: str | None = None
        self.created_orders: list[str] = []

        self._cleanup_residue()

        # 挑一个"可用 + 所属柜体 NORMAL + 所属寄存点 OPEN"的柜格
        row = self.db.execute(
            text(
                "SELECT c.id, c.code, t.size_level "
                "FROM cabinets c "
                "JOIN cabinet_types t ON t.id = c.type_id "
                "JOIN cabinet_groups g ON g.id = c.group_id "
                "JOIN storage_points p ON p.id = g.point_id "
                "WHERE c.physical_status = 'AVAILABLE' AND t.is_active = 1 "
                "AND g.status = 'NORMAL' AND p.status = 'OPEN' "
                "ORDER BY c.code LIMIT 1"
            )
        ).first()
        assert row is not None, "找不到可用柜格，请先执行 python -m app.db.seed"
        self.cab_id, self.cab_code, self.cab_size = row[0], row[1], row[2]

        self.config_original = self.get_config(CONFIG_KEY)

    # ---------- 残留清理 ----------
    def _cleanup_residue(self) -> None:
        from sqlalchemy import text

        ids = (
            self.db.execute(
                text("SELECT id FROM reservations WHERE idempotency_key LIKE :p"),
                {"p": KEY_PREFIX + "%"},
            )
            .scalars()
            .all()
        )
        for rid in ids:
            self.db.execute(text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid})
            self.db.execute(
                text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"), {"i": rid}
            )
            self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
        if ids:
            self.db.commit()
        # 配置项也可能被上次中断的运行改坏，先恢复默认
        self.db.execute(
            text("UPDATE system_config SET config_value = '15' WHERE config_key = :k"),
            {"k": CONFIG_KEY},
        )
        self.db.commit()

    # ---------- 配置 ----------
    def get_config(self, key: str) -> str | None:
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(
            text("SELECT config_value FROM system_config WHERE config_key = :k"), {"k": key}
        ).scalar()

    def set_config(self, key: str, value: str) -> None:
        from sqlalchemy import text

        self.db.execute(
            text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
            {"v": value, "k": key},
        )
        self.db.commit()

    # ---------- 读取辅助 ----------
    def _refresh(self) -> None:
        """
        结束当前只读事务。

        本 Session 与业务引擎同为 REPEATABLE READ：第一次查询就固定了读视图，
        不显式结束事务，后面所有计数都读不到服务端刚提交的新数据。
        """
        self.db.commit()

    def db_now(self) -> datetime:
        """以数据库时钟为准（BR-35），用于计算测试时间窗。"""
        from sqlalchemy import text

        self._refresh()
        return self.db.execute(text("SELECT NOW()")).scalar_one()

    def count_slots(self, order_no: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) FROM reservation_slots rs "
                    "JOIN reservations r ON r.id = rs.reservation_id WHERE r.order_no = :o"
                ),
                {"o": order_no},
            ).scalar()
        )

    def count_logs(self, order_no: str) -> int:
        from sqlalchemy import text

        self._refresh()
        return int(
            self.db.execute(
                text(
                    "SELECT COUNT(*) FROM reservation_status_logs l "
                    "JOIN reservations r ON r.id = l.reservation_id WHERE r.order_no = :o"
                ),
                {"o": order_no},
            ).scalar()
        )

    def status_log_rows(self, order_no: str) -> list[tuple]:
        """按发生顺序返回 (from_status, to_status, operator_type)。"""
        from sqlalchemy import text

        self._refresh()
        return [
            tuple(r)
            for r in self.db.execute(
                text(
                    "SELECT l.from_status, l.to_status, l.operator_type "
                    "FROM reservation_status_logs l "
                    "JOIN reservations r ON r.id = l.reservation_id "
                    "WHERE r.order_no = :o ORDER BY l.id"
                ),
                {"o": order_no},
            ).all()
        ]

    # ---------- 收尾 ----------
    def restore_all(self) -> None:
        from sqlalchemy import text

        if self.config_original is not None:
            self.db.execute(
                text("UPDATE system_config SET config_value = :v WHERE config_key = :k"),
                {"v": self.config_original, "k": CONFIG_KEY},
            )
        for order_no in self.created_orders:
            rid = self.db.execute(
                text("SELECT id FROM reservations WHERE order_no = :o"), {"o": order_no}
            ).scalar()
            if rid:
                self.db.execute(
                    text("DELETE FROM reservation_slots WHERE reservation_id = :i"), {"i": rid}
                )
                self.db.execute(
                    text("DELETE FROM reservation_status_logs WHERE reservation_id = :i"), {"i": rid}
                )
                self.db.execute(text("DELETE FROM reservations WHERE id = :i"), {"i": rid})
        self.db.commit()

    def residue_report(self) -> dict:
        from sqlalchemy import text

        self._refresh()
        return {
            "reservations": int(self.db.execute(text("SELECT COUNT(*) FROM reservations")).scalar()),
            "reservation_slots": int(
                self.db.execute(text("SELECT COUNT(*) FROM reservation_slots")).scalar()
            ),
            "reservation_status_logs": int(
                self.db.execute(text("SELECT COUNT(*) FROM reservation_status_logs")).scalar()
            ),
            CONFIG_KEY: self.get_config(CONFIG_KEY),
        }


# ==================================================================
# 用例
# ==================================================================
def create_order(token: str, cabinet_id: int, start: datetime, end: datetime, key: str) -> tuple[int, Any]:
    return call(
        "POST",
        "/reservations",
        token=token,
        body={
            "cabinet_id": cabinet_id,
            "start_time": start.strftime("%Y-%m-%dT%H:%M:%S"),
            "end_time": end.strftime("%Y-%m-%dT%H:%M:%S"),
            "luggage_size": "SMALL",
            "idempotency_key": KEY_PREFIX + key + "_" + uuid.uuid4().hex[:8],
        },
    )


def q6(cabinet_id: int, start: datetime, end: datetime) -> tuple[int, Any]:
    return call(
        "GET",
        f"/cabinets/{cabinet_id}/availability",
        query={
            "start_time": start.strftime("%Y-%m-%dT%H:%M:%S"),
            "end_time": end.strftime("%Y-%m-%dT%H:%M:%S"),
        },
    )


def run(fx: Fixture) -> int:
    now = fx.db_now()
    day = (now + timedelta(days=1)).date()
    t1_start = datetime.combine(day, datetime.min.time()).replace(hour=10)
    t1_end = t1_start + timedelta(hours=1)
    t2_start = t1_start.replace(hour=12)
    t2_end = t2_start + timedelta(hours=1)

    print("=" * 70)
    print("第四阶段 · 批次 1：R5 签到存入 / R6 完成取件")
    print(f"接口地址 : {BASE}")
    print(f"数据库时间: {now}")
    print(f"测试柜格 : {fx.cab_code} (id={fx.cab_id}, 规格={fx.cab_size})")
    print(f"时间窗 A : {t1_start} ~ {t1_end}")
    print(f"时间窗 B : {t2_start} ~ {t2_end}")
    print("=" * 70)

    tok_user = login("user02")
    tok_other = login("user01")

    # ---------------- A. 前置条件不满足 ----------------
    print("\n=== A. 前置条件不满足时必须被拦住（默认配置，签到窗口 = 开始前 15 分钟起）===")

    status, o1 = create_order(tok_user, fx.cab_id, t1_start, t1_end, "o1")
    check(status == 201, f"创建订单 O1 -> 201", f"HTTP {status} {detail_text(o1)}")
    o1no = o1["order_no"]
    fx.created_orders.append(o1no)
    print(f"        O1 = {o1no}")

    check(o1["can_checkin"] is False, "刚创建：can_checkin=false", str(o1.get("cannot_checkin_reason")))
    check(
        "尚未到签到时间" in (o1.get("cannot_checkin_reason") or ""),
        "不可签到原因指向 BR-21 窗口下界",
        str(o1.get("cannot_checkin_reason")),
    )
    check(o1["can_complete"] is False, "刚创建：can_complete=false（还没签到）")
    check(o1["can_cancel"] is True, "刚创建：can_cancel=true（BR-19 窗口内）")

    status, body = call("POST", f"/reservations/{o1no}/check-in", token=tok_user)
    check(
        status == 409 and code_of(body) == "CHECKIN_WINDOW_INVALID",
        "提前太久签到 -> 409 CHECKIN_WINDOW_INVALID（BR-21）",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", f"/reservations/{o1no}/complete", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "没签到就取件 -> 409 ORDER_STATUS_NOT_ALLOWED（BR-23）",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", f"/reservations/{o1no}/check-in", token=tok_other)
    check(
        status == 403 and code_of(body) == "AUTH_FORBIDDEN",
        "他人订单签到 -> 403 AUTH_FORBIDDEN（BR-27）",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", f"/reservations/{o1no}/complete", token=tok_other)
    check(
        status == 403 and code_of(body) == "AUTH_FORBIDDEN",
        "他人订单取件 -> 403 AUTH_FORBIDDEN（BR-27）",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", "/reservations/LZ00000000DEADBEEF/check-in", token=tok_user)
    check(
        status == 404 and code_of(body) == "RESOURCE_NOT_FOUND",
        "订单不存在时签到 -> 404",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", "/reservations/LZ00000000DEADBEEF/complete", token=tok_user)
    check(status == 404, "订单不存在时取件 -> 404", f"HTTP {status} {code_of(body)}")

    check(fx.count_logs(o1no) == 1, "被拒绝的请求未写入任何状态日志（仍只有创建那 1 条）", f"实际 {fx.count_logs(o1no)}")
    check(fx.count_slots(o1no) == 2, "被拒绝的请求未影响时段占用（仍为 2 条）", f"实际 {fx.count_slots(o1no)}")

    # ---------------- B. 完整生命周期 ----------------
    print("\n=== B. 放宽签到窗口后走通 RESERVED -> IN_USE -> COMPLETED ===")
    fx.set_config(CONFIG_KEY, CONFIG_TEMP_VALUE)
    check(
        fx.get_config(CONFIG_KEY) == CONFIG_TEMP_VALUE,
        f"临时把 {CONFIG_KEY} 调为 {CONFIG_TEMP_VALUE}（数据构造，非绕过规则；结束会还原）",
    )

    status, body = call("POST", f"/reservations/{o1no}/check-in", token=tok_user)
    check(
        status == 200 and body.get("status") == "IN_USE",
        "签到成功 -> 200 / IN_USE（BR-21）",
        f"HTTP {status} {detail_text(body)}",
    )
    check(
        sorted(body.keys()) == ["checked_in_at", "order_no", "status"],
        "R5 响应体字段正确（无 released_slot_count，因为签到不释放）",
        str(sorted(body.keys())),
    )
    check(bool(body.get("checked_in_at")), "R5 返回 checked_in_at", str(body.get("checked_in_at")))

    check(
        fx.count_slots(o1no) == 2,
        "签到【不】释放柜格时段：占用记录仍为 2 条",
        f"实际 {fx.count_slots(o1no)}",
    )
    status, av = q6(fx.cab_id, t1_start, t1_end)
    check(
        status == 200 and av.get("available") is False,
        "签到后该时段仍不可被预约（行李在柜内，柜格仍被占用）",
        f"derived_status={av.get('derived_status')}",
    )

    status, detail = call("GET", f"/reservations/{o1no}", token=tok_user)
    check(
        detail["status"] == "IN_USE" and detail["can_complete"] is True and detail["can_checkin"] is False,
        "R3 详情：IN_USE 下 can_complete=true、can_checkin=false",
        f"can_checkin={detail['can_checkin']} can_complete={detail['can_complete']}",
    )
    check(
        detail["can_cancel"] is False,
        "R3 详情：IN_USE 不可取消（BR-19）",
        str(detail.get("cannot_cancel_reason")),
    )

    status, body = call("POST", f"/reservations/{o1no}/check-in", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "重复签到 -> 409 ORDER_STATUS_NOT_ALLOWED",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", f"/reservations/{o1no}/cancel", token=tok_user, body={"reason": "已签到"})
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "签到后取消 -> 409 ORDER_STATUS_NOT_ALLOWED（BR-19）",
        f"HTTP {status} {code_of(body)}",
    )

    status, body = call("POST", f"/reservations/{o1no}/complete", token=tok_user)
    check(
        status == 200 and body.get("status") == "COMPLETED",
        "取件成功 -> 200 / COMPLETED（BR-23）",
        f"HTTP {status} {detail_text(body)}",
    )
    check(
        sorted(body.keys()) == ["completed_at", "order_no", "released_slot_count", "status"],
        "R6 响应体字段正确",
        str(sorted(body.keys())),
    )
    check(
        body.get("released_slot_count") == 2,
        "BR-24：取件立即释放剩余时段 2 条",
        f"released_slot_count={body.get('released_slot_count')}",
    )

    check(fx.count_slots(o1no) == 0, "取件后时段占用已清空", f"实际 {fx.count_slots(o1no)}")
    status, av = q6(fx.cab_id, t1_start, t1_end)
    check(
        status == 200 and av.get("available") is True,
        "BR-24：取件后该时段立刻可被重新预约",
        f"derived_status={av.get('derived_status')}",
    )

    status, body = call("POST", f"/reservations/{o1no}/complete", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "重复取件 -> 409（BR-34 终态不可再变更）",
        f"HTTP {status} {code_of(body)}",
    )
    status, body = call("POST", f"/reservations/{o1no}/check-in", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "终态订单签到 -> 409（BR-34）",
        f"HTTP {status} {code_of(body)}",
    )

    rows = fx.status_log_rows(o1no)
    check(len(rows) == 3, "BR-33：状态日志恰好 3 条（创建 + 签到 + 取件）", str(rows))
    check(
        [(r[0], r[1]) for r in rows]
        == [
            (None, "RESERVED"),
            ("RESERVED", "IN_USE"),
            ("IN_USE", "COMPLETED"),
        ],
        "BR-33：状态流转顺序与前后状态正确",
        str([(r[0], r[1]) for r in rows]),
    )
    check(
        all(r[2] == "USER" for r in rows),
        "BR-33：三条日志的 operator_type 均为 USER",
        str([r[2] for r in rows]),
    )

    # ---------------- C. 已取消的订单 ----------------
    print("\n=== C. 已取消的订单不能再签到 / 取件 ===")
    status, o2 = create_order(tok_user, fx.cab_id, t2_start, t2_end, "o2")
    check(status == 201, "创建订单 O2 -> 201", f"HTTP {status} {detail_text(o2)}")
    o2no = o2["order_no"]
    fx.created_orders.append(o2no)
    print(f"        O2 = {o2no}")

    status, body = call("POST", f"/reservations/{o2no}/cancel", token=tok_user, body={"reason": "批次1用例"})
    check(status == 200 and body.get("status") == "CANCELLED", "取消 O2 -> 200 / CANCELLED", f"HTTP {status}")

    status, body = call("POST", f"/reservations/{o2no}/check-in", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "已取消订单签到 -> 409",
        f"HTTP {status} {code_of(body)}",
    )
    status, body = call("POST", f"/reservations/{o2no}/complete", token=tok_user)
    check(
        status == 409 and code_of(body) == "ORDER_STATUS_NOT_ALLOWED",
        "已取消订单取件 -> 409",
        f"HTTP {status} {code_of(body)}",
    )
    check(fx.count_slots(o2no) == 0, "取消后 O2 的时段占用已释放", f"实际 {fx.count_slots(o2no)}")

    return 0


def main() -> int:
    fx = Fixture()
    try:
        run(fx)
    except Exception as exc:  # noqa: BLE001 - 脚本需要把异常也计入失败
        results.append((False, f"脚本异常：{exc!r}"))
        print(f"\n[EXCEPTION] {exc!r}")
    finally:
        fx.restore_all()
        report = fx.residue_report()
        print("\n=== 收尾检查 ===")
        print(f"  数据库残留: {report}")
        clean = (
            report["reservations"] == 0
            and report["reservation_slots"] == 0
            and report["reservation_status_logs"] == 0
            and report[CONFIG_KEY] == "15"
        )
        check(clean, "测试数据与配置已完全还原", str(report))
        fx.db.close()

    passed = sum(1 for ok, _ in results if ok)
    failed = len(results) - passed
    print("\n" + "=" * 70)
    print(f"批次 1 验证结果：{passed} 通过 / {failed} 失败 / 共 {len(results)} 项")
    if failed:
        print("失败项：")
        for ok, name in results:
            if not ok:
                print(f"  - {name}")
    print("=" * 70)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
