# -*- coding: utf-8 -*-
"""
一致性检查（第五阶段 / 整车验收）

【为什么需要这个脚本】
    这个项目没有"前端编译"这一步 —— 页面直接 fetch 后端接口，
    接口又直接映射数据库列。于是最容易发生的缺陷不是语法错误，而是**四方不一致**：
        设计方案文档  <->  后端路由  <->  数据库列  <->  前端调用
    例如：文档写了 M6b，代码漏了；前端调用了 api.admin.groups.cabinets()，
    但 api.js 里根本没这个方法；枚举值新增了 OVERDUE，前端文案表却没加，
    界面就会直接显示英文 "OVERDUE"。

    单元测试查不出这类问题（每一层单独看都是对的），所以单独写一条检查。

【检查项】
    A. 文档的接口清单（Q/R/M） -> 是否真的存在于 OpenAPI
    B. 文档的页面清单（P1~P14） -> 对应的 html 文件是否存在
    C. ORM 模型列 -> 是否与数据库实际列完全一致
    D. 前端 api.js 里的每一个请求路径 -> 是否命中 OpenAPI
    E. 前端页面里调用的 api.xxx.yyy() -> api.js 里是否真的有这个方法
    F. 前端引用的错误码 -> 后端 ErrorCode 里是否存在
    G. 前端的中文文案表 -> 后端的枚举值是否都有对应文案

【说明】
    D 项只证明"路径拼得对"，不证明"参数/权限/业务正确" ——
    后者由 tools/phase3_e2e_reservation.py 等 4 个真实 HTTP 脚本负责。

用法：
    cd backend
    .\\.venv\\Scripts\\Activate.ps1
    python tools/phase5_consistency_check.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent
DOC_PATH = PROJECT_DIR / "docs" / "01-项目设计方案.md"
FRONTEND_DIR = BACKEND_DIR / "frontend"

# 直接 `python tools/xxx.py` 运行时，sys.path[0] 是 tools/ 而不是 backend/，
# 因此需要手动把 backend/ 加进去，否则 `import app` 会失败
# （其余 e2e 脚本只发 HTTP 请求、不导入 app，所以没有这个问题）
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

_failures: list[str] = []


def check(ok: bool, title: str, detail: str = "") -> bool:
    """统一输出一行结果；失败计入 _failures。"""
    mark = "PASS" if ok else "FAIL"
    if ok:
        print(f"  [{mark}] {title}")
    else:
        print(f"  [{mark}] {title}" + (f"   <-- {detail}" if detail else ""))
        _failures.append(title)
    return ok


def section(title: str) -> None:
    print(f"\n=== {title} ===")


# ==================================================================
# 路径归一化：把任意路径参数名统一成 {}，便于文档 / openapi / 前端三方比较
# ==================================================================
def normalize_path(path: str) -> str:
    path = path.split("?")[0].strip()
    path = re.sub(r"\{[^}]*\}", "{}", path)
    if len(path) > 1:
        path = path.rstrip("/")
    return path


def load_openapi() -> tuple[set[tuple[str, str]], set[str]]:
    """返回 ({(METHOD, 归一化路径)}, {归一化路径})。"""
    from app.main import app

    pairs: set[tuple[str, str]] = set()
    paths: set[str] = set()
    for raw_path, methods in app.openapi()["paths"].items():
        norm = normalize_path(raw_path)
        paths.add(norm)
        for method in methods:
            if method.lower() in {"get", "post", "put", "patch", "delete"}:
                pairs.add((method.upper(), norm))
    return pairs, paths


# ==================================================================
# A. 文档接口清单 -> OpenAPI
# ==================================================================
API_ROW = re.compile(r"^\|\s*\*{0,2}(A\d+|Q\d+|R\d+|M\d+)\*{0,2}\s*\|(.*)$")
METHOD_TOKEN = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE)\b")
BACKTICK_PATH = re.compile(r"`(/[^`]*)`")

#: 文档里没写进接口表、但正文明确记录过的接口（逐条给出出处）
EXTRA_DOCUMENTED = {
    # 设计方案「S0 环境与骨架」验收标准里写着 `GET /api/v1/health` 返回 200
    ("GET", "/api/v1/health"),
    # 设计方案 6.4 节 M15 之后的「补充」段落（批次 4 实装时新增，理由见该段）
    ("GET", "/api/v1/admin/groups/{}/cabinets"),
}


def parse_api_rows(text: str) -> list[tuple[str, str, str]]:
    """
    解析接口表，返回 [(编号, HTTP 方法, 文档里的路径)]。

    【为什么只取前三个单元格】
    整行里到处都有反引号（错误码表一格里就写了 5 个 `XXX` 并用 / 分隔），
    如果对整个行做"反引号里以 / 开头"的匹配，
    `TIME_NOT_ALIGNED`/`DURATION_OUT_OF_RANGE` 这种写法会被误当成路径 "/"。
    接口表的结构是固定的：| 编号 | 方法 | 路径 | 权限 | ...
    所以只解析第 2、3 个单元格。

    M15 这一行把两个接口写在一起：`/admin/configs` / PUT `/admin/configs/{key}`，
    此时第 2 格是 GET、第 3 格里还有 PUT，两边的 token 合起来才是全部方法，
    路径数与方法数相同则按顺序一一配对。
    """
    rows: list[tuple[str, str, str]] = []
    for line in text.splitlines():
        m = API_ROW.match(line)
        if not m:
            continue

        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 3:
            continue

        ident = cells[0].strip("*").strip()
        method_cell = cells[1]
        path_cell = cells[2]

        methods = METHOD_TOKEN.findall(method_cell + " " + path_cell)
        paths = [p for p in BACKTICK_PATH.findall(path_cell) if p.startswith("/") and len(p) > 1]
        if not methods or not paths:
            continue

        if len(paths) == 1:
            rows.extend((ident, mth, paths[0]) for mth in methods)
        elif len(paths) == len(methods):
            rows.extend((ident, mth, p) for mth, p in zip(methods, paths))
        else:
            rows.extend((ident, mth, p) for p in paths for mth in methods)

    return rows


def check_doc_api(openapi_pairs: set[tuple[str, str]]) -> None:
    section("A. 设计方案 6.2 / 6.3 / 6.4 的接口清单 -> 是否都在 OpenAPI 里")

    text = DOC_PATH.read_text(encoding="utf-8")
    rows = parse_api_rows(text)

    check(len(rows) >= 30, f"从文档接口表解析出 {len(rows)} 条「方法 + 路径」")

    missing = [
        f"{ident} {method} {path}"
        for ident, method, path in rows
        if (method, normalize_path("/api/v1" + path)) not in openapi_pairs
    ]
    check(not missing, "文档里的每一条接口都真实存在于 OpenAPI",
          "缺少：" + "、".join(missing) if missing else "")

    # 反向检查：OpenAPI 里不应有"文档没写"的接口
    documented = {(mth, normalize_path("/api/v1" + p)) for _, mth, p in rows}
    documented |= EXTRA_DOCUMENTED

    undocumented = sorted(
        f"{mth} {path}" for mth, path in openapi_pairs if (mth, path) not in documented
        and path.startswith("/api/v1")
    )
    check(not undocumented, "OpenAPI 里没有「文档未记录」的接口",
          "未记录：" + "、".join(undocumented) if undocumented else "")


# ==================================================================
# B. 文档页面清单 -> 前端文件
# ==================================================================
PAGE_ROW = re.compile(r"^\|\s*P\d+\s*\|\s*`([^`]+)`", re.M)


def check_doc_pages() -> None:
    section("B. 设计方案 7.1 的页面清单 -> 前端文件是否存在")

    text = DOC_PATH.read_text(encoding="utf-8")
    pages = [p.split("?")[0] for p in PAGE_ROW.findall(text) if p.startswith("/")]

    check(len(pages) >= 14, f"从文档页面表解析出 {len(pages)} 个页面路径")
    missing = [p for p in pages if not (FRONTEND_DIR / p.lstrip("/")).exists()]
    check(not missing, "文档里的每个页面都有对应的 html 文件",
          "缺少：" + "、".join(missing) if missing else "")


# ==================================================================
# C. ORM 模型 -> 数据库实际列
# ==================================================================
def check_model_columns() -> None:
    section("C. ORM 模型定义的列 -> 数据库实际列是否完全一致")

    from sqlalchemy import inspect

    from app.db.session import engine
    from app.models import Base

    inspector = inspect(engine)
    db_tables = set(inspector.get_table_names())
    model_tables = set(Base.metadata.tables)

    check(not (model_tables - db_tables), "模型里的表都已建在数据库中",
          "缺表：" + "、".join(sorted(model_tables - db_tables)))

    problems: list[str] = []
    for table_name in sorted(model_tables):
        if table_name not in db_tables:
            continue
        model_cols = {c.name for c in Base.metadata.tables[table_name].columns}
        db_cols = {c["name"] for c in inspector.get_columns(table_name)}
        if model_cols != db_cols:
            only_model = sorted(model_cols - db_cols)
            only_db = sorted(db_cols - model_cols)
            problems.append(f"{table_name}: 仅模型有={only_model} 仅库里有={only_db}")

    check(not problems, f"{len(model_tables)} 张表的列与 ORM 完全一致",
          "；".join(problems))


# ==================================================================
# D. 前端请求路径 -> OpenAPI
# ==================================================================
def _path_template(expr: str) -> str | None:
    """
    把 request() 的第一个参数表达式还原成路径模板。

    表达式是字符串拼接，例如：
        '/admin/groups/' + groupId            -> /admin/groups/{}
        '/points/' + pointId + '/groups'      -> /points/{}/groups
        '/admin/stats/overview'               -> /admin/stats/overview

    【为什么按 '+' 拆而不是只取字符串字面量】
    只取字面量会把 `'/admin/groups/' + groupId` 变成 `/admin/groups`（丢掉末尾的 id），
    于是这条路径就"找不到"了 —— 这是第一版检查脚本自己的 bug，不是后端的问题。
    拼接的每个非字面量片段都必须还原成 `{}`。
    """
    parts = [p.strip() for p in expr.split("+")]
    out: list[str] = []
    has_literal = False
    for part in parts:
        m = re.fullmatch(r"'([^']*)'", part) or re.fullmatch(r'"([^"]*)"', part)
        if m:
            out.append(m.group(1))
            has_literal = True
        else:
            out.append("{}")
    if not has_literal:
        return None
    template = re.sub(r"\{\}+", "{}", "".join(out))
    return template


def extract_js_paths(js: str) -> set[str]:
    """从 api.js 里提取所有 request(<path>) 的路径模板（供与 OpenAPI 比较）。"""
    paths: set[str] = set()
    for m in re.finditer(r"request\(", js):
        # 从 request( 后面开始，取到同层的逗号为止
        i = m.end()
        depth = 0
        j = i
        while j < len(js):
            ch = js[j]
            if ch in "([{":
                depth += 1
            elif ch in ")]}":
                if depth == 0:
                    break
                depth -= 1
            elif ch == "," and depth == 0:
                break
            j += 1
        expr = js[i:j]
        if "/" not in expr:
            continue

        template = _path_template(expr)
        if template is None:
            continue

        if not template.startswith("/api"):
            template = "/api/v1" + template
        paths.add(normalize_path(template))
    return paths


def check_frontend_paths(openapi_paths: set[str]) -> None:
    section("D. 前端 api.js 的每个请求路径 -> 是否命中 OpenAPI")

    js = (FRONTEND_DIR / "js" / "api.js").read_text(encoding="utf-8")
    js_paths = extract_js_paths(js)
    check(len(js_paths) >= 20, f"从 api.js 提取出 {len(js_paths)} 条请求路径模板")

    missing = sorted(p for p in js_paths if p not in openapi_paths)
    check(not missing, "api.js 的每条路径都能在 OpenAPI 里找到",
          "对不上：" + "、".join(missing) if missing else "")

    # 页面里如果有直接 fetch('/api/v1/...') 的写法，也要能对上
    inline: list[str] = []
    for page in FRONTEND_DIR.rglob("*.html"):
        text = page.read_text(encoding="utf-8")
        for p in re.findall(r"fetch\(\s*['\"](/api/v1[^'\"]*)['\"]", text):
            inline.append(p)
            if normalize_path(p) not in openapi_paths:
                missing.append(p)
    check(not [p for p in inline if normalize_path(p) not in openapi_paths],
          f"页面里 {len(inline)} 处直接 fetch 的路径也都命中 OpenAPI"
          if inline else "页面里没有绕过 api.js 直接 fetch 的写法")


# ==================================================================
# E. 页面调用的 api.xxx.yyy() -> api.js 里是否定义
# ==================================================================
API_METHOD_DEF = re.compile(r"^\s{4,}(\w+):\s*function\s*\(", re.M)


def parse_api_methods(js: str) -> set[str]:
    """
    解析 api.js，返回所有可调用成员的**点分路径**集合：
        auth.login / points.list / admin.points.create / admin.jobs.logs / getToken ...

    做法：按缩进维护一个"当前所在的命名空间栈"。
    api.js 的层级是固定的（4 空格 = api 的直接成员，6 空格 = 二级成员/子命名空间，
    8 空格 = admin 下的方法），所以缩进足够可靠，不需要真的解析 JS 语法。
    """
    stack: list[tuple[int, str]] = []
    paths: set[str] = set()

    for line in js.splitlines():
        m_obj = re.match(r"^(\s{2,})(\w+):\s*\{\s*$", line)
        if m_obj:
            indent = len(m_obj.group(1))
            while stack and stack[-1][0] >= indent:
                stack.pop()
            stack.append((indent, m_obj.group(2)))
            continue

        m_fn = re.match(r"^(\s{2,})(\w+):\s*function\s*\(", line)
        if m_fn:
            indent = len(m_fn.group(1))
            while stack and stack[-1][0] >= indent:
                stack.pop()
            paths.add(".".join([k for _, k in stack] + [m_fn.group(2)]))
            continue

        # api 对象顶层的简写成员，如 `getToken: getToken,` / `base: API_BASE,`
        if not stack:
            m_short = re.match(r"^\s{4}(\w+):\s*[\w.]+\s*,?\s*$", line)
            if m_short:
                paths.add(m_short.group(1))

    return paths


def check_frontend_api_calls() -> None:
    section("E. 页面里调用的 api.<命名空间>.<方法>() -> api.js 里是否真的存在")

    js = (FRONTEND_DIR / "js" / "api.js").read_text(encoding="utf-8")
    methods = parse_api_methods(js)

    check(len(methods) >= 30, f"从 api.js 解析出 {len(methods)} 个可调用成员")

    # api.xxx / api.xxx.yyy / api.xxx.yyy.zzz（最多三级）
    CALL = re.compile(r"\bapi\.((?:\w+\.)*\w+)\s*\(")

    problems: list[str] = []
    checked = 0
    for page in sorted(FRONTEND_DIR.rglob("*.html")):
        text = page.read_text(encoding="utf-8")
        for m in CALL.finditer(text):
            dotted = m.group(1)
            checked += 1
            if dotted not in methods:
                problems.append(f"{page.name}: api.{dotted}()")

    check(checked > 0, f"页面里共发现 {checked} 处 api.* 调用")
    check(not problems, "页面调用的每个 api 方法都在 api.js 里定义过",
          "未定义：" + "、".join(sorted(set(problems))) if problems else "")


# ==================================================================
# F. 前端引用的错误码 -> 后端 ErrorCode
# ==================================================================
def check_error_codes() -> None:
    section("F. 前端引用的错误码 -> 后端 ErrorCode 里是否存在")

    from app.core.codes import ErrorCode

    codes = {v for k, v in vars(ErrorCode).items() if k.isupper() and isinstance(v, str)}

    referenced: set[str] = set()
    for path in list(FRONTEND_DIR.rglob("*.js")) + list(FRONTEND_DIR.rglob("*.html")):
        text = path.read_text(encoding="utf-8")
        for m in re.finditer(r"(?:code\s*===?\s*|code\s*!==?\s*)'([A-Z][A-Z0-9_]{3,})'", text):
            referenced.add(m.group(1))

    check(bool(referenced), f"前端按错误码分支处理的位置共 {len(referenced)} 个：{sorted(referenced)}")
    unknown = sorted(referenced - codes)
    check(not unknown, "前端引用的错误码后端都存在",
          "未知：" + "、".join(unknown) if unknown else "")


# ==================================================================
# G. 前端文案表 -> 后端枚举值
# ==================================================================
def check_enum_labels() -> None:
    section("G. 前端中文文案表 -> 后端枚举值是否都有对应文案")

    from app.core.constants import (
        CabinetGroupStatus,
        CabinetPhysicalStatus,
        JobName,
        JobResult,
        JobTriggerType,
        PayStatus,
        ReservationStatus,
        StoragePointStatus,
    )

    common_js = (FRONTEND_DIR / "js" / "common.js").read_text(encoding="utf-8")

    def keys_of_map(var_name: str) -> set[str]:
        m = re.search(var_name + r"\s*=\s*\{(.*?)\};", common_js, re.S)
        if not m:
            return set()
        return set(re.findall(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*:", m.group(1), re.M))

    def keys_of_inline(function_name: str) -> set[str]:
        """匹配 `return { A: 'x', B: 'y' }[status]` 这种内联映射。"""
        m = re.search(
            r"function " + function_name + r"\([^)]*\)\s*\{\s*return\s*\{(.*?)\}\s*\[",
            common_js,
            re.S,
        )
        if not m:
            return set()
        return set(re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*:", m.group(1)))

    # 派生状态不是枚举，是 derive_status() 的返回值集合
    DERIVED = {"AVAILABLE", "RESERVED", "IN_USE", "MAINTENANCE", "DISABLED", "UNAVAILABLE"}

    cases: list[tuple[str, set[str], set[str]]] = [
        ("订单状态 ORDER_STATUS_TEXT", keys_of_map("ORDER_STATUS_TEXT"),
         {x.value for x in ReservationStatus}),
        ("派生状态 DERIVED_STATUS_TEXT", keys_of_map("DERIVED_STATUS_TEXT"), DERIVED),
        ("寄存点状态 pointStatusText", keys_of_inline("pointStatusText"),
         {x.value for x in StoragePointStatus}),
        ("柜体状态 groupStatusText", keys_of_inline("groupStatusText"),
         {x.value for x in CabinetGroupStatus}),
        ("柜格运维状态 physicalStatusText", keys_of_inline("physicalStatusText"),
         {x.value for x in CabinetPhysicalStatus}),
        ("任务名 JOB_NAME_TEXT", keys_of_map("JOB_NAME_TEXT"), {x.value for x in JobName}),
        ("触发类型 jobTriggerText", keys_of_inline("jobTriggerText"),
         {x.value for x in JobTriggerType}),
        ("任务结果 jobResultText", keys_of_inline("jobResultText"),
         {x.value for x in JobResult}),
        ("支付状态 payStatusText", keys_of_inline("payStatusText"), {x.value for x in PayStatus}),
    ]

    for title, frontend_keys, backend_values in cases:
        missing = sorted(backend_values - frontend_keys)
        extra = sorted(frontend_keys - backend_values)
        ok = not missing and not extra and bool(frontend_keys)
        detail = ""
        if missing:
            detail = "后端有但前端没文案：" + "、".join(missing)
        if extra:
            detail += ("；" if detail else "") + "前端多出（后端已无）：" + "、".join(extra)
        check(ok, f"{title} 与后端枚举一一对应（{len(frontend_keys)} 项）", detail)


# ==================================================================
# 主流程
# ==================================================================
def main() -> int:
    print("一致性检查：设计方案文档 / 后端路由 / 数据库列 / 前端调用")
    print(f"文档：{DOC_PATH}")
    print(f"前端：{FRONTEND_DIR}")

    openapi_pairs, openapi_paths = load_openapi()
    print(f"OpenAPI：{len(openapi_paths)} 个路径 / {len(openapi_pairs)} 个「方法+路径」")

    check_doc_api(openapi_pairs)
    check_doc_pages()
    check_model_columns()
    check_frontend_paths(openapi_paths)
    check_frontend_api_calls()
    check_error_codes()
    check_enum_labels()

    print()
    if _failures:
        print(f"一致性检查未通过：{len(_failures)} 项")
        for item in _failures:
            print(f"  - {item}")
        return 1
    print("一致性检查通过：文档 / 接口 / 数据库 / 前端 四方一致")
    return 0


if __name__ == "__main__":
    sys.exit(main())
