"""
B1 批次执行器：认证与账号（11）+ 查询与可用性（15）。

定位：
- 这是 docs/04 中 B1 26 条用例的**自动化执行脚本**，不是人工点击记录；
- 每条用例都保留独立断言，失败不会阻断后续用例；
- 结果写入 docs/execution/b1-auth-query-results.{json,md}，并更新执行跟踪表；
- 所有创建的测试用户/预约/状态变更都会在 finally 中清理或恢复。

运行：
    cd backend
    .\.venv\Scripts\python.exe tools\run_b1_auth_query.py

依赖真实后端（默认 http://127.0.0.1:8138/api/v1）和 MySQL。
"""

from __future__ import annotations

import json
import re
import sys
import time
import uuid
from datetime import datetime, time as dtime, timedelta
from pathlib import Path
from typing import Any, Callable

import jwt
import requests
from sqlalchemy import text

# 直接执行 tools/xxx.py 时，sys.path[0] 是 tools/，需要补上 backend/
_BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))

from app.core.config import settings
from app.db.session import SessionLocal, db_now

BASE_URL = "http://127.0.0.1:8138/api/v1"
BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = BACKEND_DIR.parent
OUT_DIR = PROJECT_ROOT / "docs" / "execution"
JSON_PATH = OUT_DIR / "b1-auth-query-results.json"
MD_PATH = OUT_DIR / "b1-auth-query-results.md"
TRACKER_PATH = OUT_DIR / "123-case-execution-tracker.csv"

PASSWORD = settings.user_seed_password
RUN_ID = uuid.uuid4().hex[:8]
NOW = datetime.now()
TARGET_DATE = NOW.date() + timedelta(days=1)
TARGET_DATE_2 = TARGET_DATE + timedelta(days=1)


def at(day, hour: int, minute: int = 0) -> datetime:
    return datetime.combine(day, dtime(hour, minute))


def iso(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H:%M:%S")


D1_1000 = at(TARGET_DATE, 10, 0)
D1_1030 = at(TARGET_DATE, 10, 30)
D1_1100 = at(TARGET_DATE, 11, 0)
D1_1130 = at(TARGET_DATE, 11, 30)
D1_1200 = at(TARGET_DATE, 12, 0)
D1_0800 = at(TARGET_DATE, 8, 0)
D1_2200 = at(TARGET_DATE, 22, 0)


class CaseFailure(AssertionError):
    pass


def check(condition: bool, message: str) -> None:
    if not condition:
        raise CaseFailure(message)


def response_json(response: requests.Response) -> Any:
    try:
        data = response.json()
    except Exception:
        return {"_raw": response.text[:500]}
    # Q1/Q3/Q8 等接口直接返回数组，Q5/Q6 返回对象；都要原样保留。
    return data if isinstance(data, (dict, list)) else {"_data": data}


def request(
    method: str,
    path: str,
    *,
    token: str | None = None,
    expected: int | None = None,
    **kwargs: Any,
) -> requests.Response:
    headers = dict(kwargs.pop("headers", {}) or {})
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response = requests.request(
        method,
        f"{BASE_URL}{path}",
        headers=headers,
        timeout=15,
        **kwargs,
    )
    if expected is not None and response.status_code != expected:
        body = response_json(response)
        raise CaseFailure(
            f"{method} {path} 期望 HTTP {expected}，实际 {response.status_code}；"
            f"code={body.get('code')!r} message={body.get('message')!r} "
            f"request_id={body.get('request_id')!r}"
        )
    return response


def expect_error(
    response: requests.Response,
    http_status: int,
    code: str,
    *,
    field_contains: str | None = None,
) -> dict:
    body = response_json(response)
    check(
        response.status_code == http_status,
        f"期望 HTTP {http_status}，实际 {response.status_code}；code={body.get('code')!r}",
    )
    check(
        body.get("code") == code,
        f"期望业务码 {code}，实际 {body.get('code')!r}",
    )
    if field_contains:
        errors = (body.get("detail") or {}).get("errors") or []
        fields = [str(item.get("field", "")) for item in errors if isinstance(item, dict)]
        check(
            any(field_contains in field for field in fields),
            f"detail.errors 未包含字段 {field_contains!r}，实际 fields={fields}",
        )
    return body


def login(username: str, password: str | None = None, expected: int = 200) -> tuple[requests.Response, dict]:
    response = request(
        "POST",
        "/auth/login",
        json={"username": username, "password": password or PASSWORD},
        expected=expected,
    )
    return response, response_json(response)


def valid_token(username: str = "user01") -> str:
    _response, body = login(username)
    token = body.get("access_token")
    check(bool(token), f"{username} 登录未返回 access_token")
    return token


def db_scalar(sql: str, **params: Any) -> Any:
    db = SessionLocal()
    try:
        return db.execute(text(sql), params).scalar()
    finally:
        db.close()


def db_all(sql: str, **params: Any) -> list[tuple]:
    db = SessionLocal()
    try:
        return [tuple(row) for row in db.execute(text(sql), params).all()]
    finally:
        db.close()


def db_exec(sql: str, **params: Any) -> None:
    db = SessionLocal()
    try:
        db.execute(text(sql), params)
        db.commit()
    finally:
        db.close()


def cleanup_user(username: str) -> None:
    # 仅用于 tst_ 前缀下的测试账号，避免误删业务账号
    if not username.startswith("tst_"):
        return
    db_exec("DELETE FROM users WHERE username = :username", username=username)


def cleanup_reservation(key: str) -> None:
    db = SessionLocal()
    try:
        row = db.execute(
            text("SELECT id FROM reservations WHERE idempotency_key = :key"), {"key": key}
        ).first()
        if row:
            reservation_id = int(row[0])
            db.execute(
                text("DELETE FROM reservation_status_logs WHERE reservation_id = :rid"),
                {"rid": reservation_id},
            )
            db.execute(
                text("DELETE FROM reservation_slots WHERE reservation_id = :rid"),
                {"rid": reservation_id},
            )
            db.execute(text("DELETE FROM reservations WHERE id = :rid"), {"rid": reservation_id})
            db.commit()
    finally:
        db.close()


def cleanup_b1_reservations() -> None:
    db = SessionLocal()
    try:
        rows = db.execute(
            text("SELECT id, idempotency_key FROM reservations WHERE idempotency_key LIKE 'b1-%'")
        ).all()
        for reservation_id, _key in rows:
            db.execute(
                text("DELETE FROM reservation_status_logs WHERE reservation_id = :rid"),
                {"rid": int(reservation_id)},
            )
            db.execute(
                text("DELETE FROM reservation_slots WHERE reservation_id = :rid"),
                {"rid": int(reservation_id)},
            )
            db.execute(
                text("DELETE FROM reservations WHERE id = :rid"), {"rid": int(reservation_id)}
            )
        db.commit()
    finally:
        db.close()


def create_reservation(
    token: str,
    cabinet_id: int,
    start_time: datetime,
    end_time: datetime,
    key: str,
    luggage_size: str = "SMALL",
) -> dict:
    response = request(
        "POST",
        "/reservations",
        token=token,
        expected=201,
        json={
            "cabinet_id": cabinet_id,
            "start_time": iso(start_time),
            "end_time": iso(end_time),
            "luggage_size": luggage_size,
            "luggage_count": 1,
            "idempotency_key": key,
        },
    )
    body = response_json(response)
    check(body.get("status") == "RESERVED", f"新订单状态不是 RESERVED：{body.get('status')!r}")
    check(body.get("idempotent_replay") is False, "新订单 idempotent_replay 不是 false")
    return body


def q5(
    point_id: int,
    start_time: datetime,
    end_time: datetime,
    *,
    luggage_size: str | None = None,
) -> dict:
    params: dict[str, Any] = {
        "point_id": point_id,
        "start_time": iso(start_time),
        "end_time": iso(end_time),
    }
    if luggage_size:
        params["luggage_size"] = luggage_size
    response = request("GET", "/cabinets/availability", params=params, expected=200)
    return response_json(response)


def group_map(body: dict) -> dict[str, dict]:
    return {item["group_code"]: item for item in body.get("groups", [])}


def type_map(group: dict) -> dict[str, dict]:
    return {item["type_code"]: item for item in group.get("types", [])}


def cabinet_map(group: dict) -> dict[str, dict]:
    result: dict[str, dict] = {}
    for type_item in group.get("types", []):
        for cabinet in type_item.get("cabinets", []):
            result[cabinet["code"]] = cabinet
    return result


# ======================================================================
# AUTH 11
# ======================================================================
def case_auth_01() -> str:
    before = db_all(
        "SELECT token_version, last_login_at FROM users WHERE username = 'user01'"
    )[0]
    before_version, before_login = before
    response, body = login("user01")
    token = body.get("access_token")
    check(body.get("token_type") == "bearer", f"token_type={body.get('token_type')!r}")
    check(body.get("expires_in") == 7200, f"expires_in={body.get('expires_in')!r}")
    check(bool(token), "access_token 为空")
    user = body.get("user") or {}
    check(user.get("username") == "user01", f"user.username={user.get('username')!r}")
    check(user.get("role") == "USER", f"user.role={user.get('role')!r}")
    check(user.get("status") == "ACTIVE", f"user.status={user.get('status')!r}")
    me = request("GET", "/auth/me", token=token, expected=200)
    check(response_json(me).get("username") == "user01", "/auth/me username 不是 user01")
    after_version, after_login = db_all(
        "SELECT token_version, last_login_at FROM users WHERE username = 'user01'"
    )[0]
    check(int(after_version) == int(before_version), "登录后 token_version 发生变化")
    check(after_login is not None, "登录后 last_login_at 仍为空")
    return (
        f"200 bearer/7200；/auth/me=user01；token_version={after_version} 未变；"
        f"last_login_at 已更新（{after_login}）"
    )


def case_auth_02() -> str:
    before = db_scalar("SELECT last_login_at FROM users WHERE username = 'user01'")
    response, _body = login("user01", "Demo@123457", expected=401)
    body = expect_error(response, 401, "AUTH_INVALID_CREDENTIALS")
    check("access_token" not in body, "错误登录响应包含 access_token")
    after = db_scalar("SELECT last_login_at FROM users WHERE username = 'user01'")
    check(before == after, "密码错误仍更新了 last_login_at")
    return "401 AUTH_INVALID_CREDENTIALS；响应无 token；last_login_at 未更新"


def case_auth_03() -> str:
    r1, _ = login("user01", "Demo@123457", expected=401)
    b1 = expect_error(r1, 401, "AUTH_INVALID_CREDENTIALS")
    r2, _ = login("tst_nobody_01", PASSWORD, expected=401)
    b2 = expect_error(r2, 401, "AUTH_INVALID_CREDENTIALS")
    check(b1.get("message") == b2.get("message"), "不存在用户与密码错误的 message 不一致")
    return f"两次均 401 AUTH_INVALID_CREDENTIALS；message 一致（{b2.get('message')!r}）"


def case_auth_04() -> str:
    username = "tst_user01"
    cleanup_user(username)
    try:
        response = request(
            "POST",
            "/auth/register",
            expected=201,
            json={"username": username, "password": "Abcd1234", "phone": "13900000001"},
        )
        body = response_json(response)
        check(body.get("username") == username, f"username={body.get('username')!r}")
        check(body.get("role") == "USER", f"role={body.get('role')!r}")
        check(body.get("status") == "ACTIVE", f"status={body.get('status')!r}")
        check("password" not in body and "password_hash" not in body, "响应泄露了密码字段")
        row = db_all(
            "SELECT username, role, status, password_hash FROM users WHERE username = :u",
            u=username,
        )
        check(len(row) == 1, f"DB 用户行数={len(row)}")
        _u, role, status, password_hash = row[0]
        check(role == "USER" and status == "ACTIVE", f"DB role/status={role}/{status}")
        check(str(password_hash).startswith("$2"), "password_hash 不是 bcrypt（$2 开头）")
        check(password_hash != "Abcd1234", "password_hash 等于明文")
        return "201；role=USER/status=ACTIVE；响应无密码字段；DB bcrypt 哈希且非明文"
    finally:
        cleanup_user(username)


def case_auth_05() -> str:
    before = int(db_scalar("SELECT COUNT(*) FROM users"))
    r1 = request(
        "POST",
        "/auth/register",
        json={"username": "user01", "password": "Abcd1234"},
    )
    expect_error(r1, 409, "USERNAME_EXISTS")
    # 用例原文写 13900000002，实际种子 user02 的手机号是 13800000002。
    # 按实际数据验证同一规则，并在结果里记录这处用例数据笔误。
    r2 = request(
        "POST",
        "/auth/register",
        json={"username": f"tst_user02_{RUN_ID}", "password": "Abcd1234", "phone": "13800000002"},
    )
    expect_error(r2, 409, "PHONE_EXISTS")
    after = int(db_scalar("SELECT COUNT(*) FROM users"))
    check(before == after, f"唯一冲突后用户数变化：{before}->{after}")
    return (
        "用户名冲突=409 USERNAME_EXISTS；手机号冲突=409 PHONE_EXISTS；"
        "用户数未增加。注：用例写 13900000002，实际种子为 13800000002，按实际数据执行"
    )


def case_auth_06() -> str:
    before = int(db_scalar("SELECT COUNT(*) FROM users"))
    variants = [
        ("username=ab", {"username": "ab", "password": "Abcd1234"}),
        ("username=ab-cd", {"username": "ab-cd", "password": "Abcd1234"}),
        ("password=12345678", {"username": f"tst_v1_{RUN_ID}", "password": "12345678"}),
        ("password=abcdefgh", {"username": f"tst_v2_{RUN_ID}", "password": "abcdefgh"}),
        (
            "phone=12345678901",
            {"username": f"tst_v3_{RUN_ID}", "password": "Abcd1234", "phone": "12345678901"},
        ),
    ]
    observed: list[str] = []
    for label, payload in variants:
        response = request("POST", "/auth/register", json=payload)
        body = response_json(response)
        check(response.status_code == 400, f"{label} 期望 400，实际 {response.status_code}")
        check(body.get("code") == "VALIDATION_ERROR", f"{label} code={body.get('code')!r}")
        errors = (body.get("detail") or {}).get("errors") or []
        check(bool(errors), f"{label} detail.errors 为空")
        observed.append(f"{label}->{errors[0].get('field')}")
    after = int(db_scalar("SELECT COUNT(*) FROM users"))
    check(before == after, f"非法注册后用户数变化：{before}->{after}")
    return "五条均 400 VALIDATION_ERROR 且 detail 指向字段；无用户落库；" + "；".join(observed)


def case_auth_07() -> str:
    username_32 = "tst_" + "a" * 28
    username_33 = username_32 + "a"
    check(len(username_32) == 32 and len(username_33) == 33, "用户名长度构造错误")
    cleanup_user(username_32)
    try:
        r1 = request(
            "POST",
            "/auth/register",
            expected=201,
            json={"username": username_32, "password": "Abcd1234"},
        )
        check(response_json(r1).get("username") == username_32, "32 位用户名注册返回不匹配")
        r2 = request(
            "POST",
            "/auth/register",
            json={"username": username_33, "password": "Abcd1234"},
        )
        expect_error(r2, 400, "VALIDATION_ERROR", field_contains="username")
        return "32 位=201；33 位=400 VALIDATION_ERROR（username 字段）"
    finally:
        cleanup_user(username_32)


def case_auth_08() -> str:
    for path in ("/auth/me", "/reservations/my"):
        response = request("GET", path)
        expect_error(response, 401, "AUTH_TOKEN_MISSING")
    return "GET /auth/me 与 /reservations/my 均 401 AUTH_TOKEN_MISSING"


def case_auth_09() -> str:
    token = valid_token("user01")
    tampered = token[:-1] + ("a" if token[-1] != "a" else "b")
    r1 = request("GET", "/auth/me", token=tampered)
    expect_error(r1, 401, "AUTH_TOKEN_INVALID")

    claims = jwt.decode(
        token,
        settings.JWT_SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM],
        options={"verify_exp": False},
    )
    claims["exp"] = datetime.now().timestamp() - 60
    expired = jwt.encode(claims, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
    r2 = request("GET", "/auth/me", token=expired)
    expect_error(r2, 401, "AUTH_TOKEN_EXPIRED")
    return "篡改签名=401 AUTH_TOKEN_INVALID；过期 token=401 AUTH_TOKEN_EXPIRED"


def case_auth_10() -> str:
    token_old = valid_token("user02")
    old_version = int(db_scalar("SELECT token_version FROM users WHERE username = 'user02'"))
    try:
        response = request("POST", "/auth/logout", token=token_old, expected=200)
        check(response_json(response).get("message"), "登出响应缺少 message")
        new_version = int(db_scalar("SELECT token_version FROM users WHERE username = 'user02'"))
        check(new_version == old_version + 1, f"token_version {old_version}->{new_version}")
        old_me = request("GET", "/auth/me", token=token_old)
        expect_error(old_me, 401, "AUTH_TOKEN_INVALID")
        _r, body = login("user02")
        token_new = body.get("access_token")
        check(bool(token_new), "重新登录未返回 token")
        request("GET", "/auth/me", token=token_new, expected=200)
        return f"登出 200；token_version {old_version}->{new_version}；旧 token 401；新 token 200"
    finally:
        # 恢复测试前版本，避免影响后续用例；本次验证已经完成
        db_exec(
            "UPDATE users SET token_version = :v WHERE username = 'user02'",
            v=old_version,
        )


def case_auth_11() -> str:
    token_old = valid_token("user02")
    try:
        db_exec("UPDATE users SET status = 'DISABLED' WHERE username = 'user02'")
        r1 = request(
            "POST",
            "/auth/login",
            json={"username": "user02", "password": PASSWORD},
        )
        expect_error(r1, 403, "USER_DISABLED")
        r2 = request("GET", "/auth/me", token=token_old)
        expect_error(r2, 403, "USER_DISABLED")
        db_exec("UPDATE users SET status = 'ACTIVE' WHERE username = 'user02'")
        _r, body = login("user02")
        check(bool(body.get("access_token")), "恢复后登录未返回 token")
        return "禁用后登录=403 USER_DISABLED；旧 token=403；恢复 ACTIVE 后登录=200"
    finally:
        db_exec("UPDATE users SET status = 'ACTIVE' WHERE username = 'user02'")


# ======================================================================
# QUERY 15
# ======================================================================
def case_qry_01() -> str:
    response = request("GET", "/points", expected=200)
    body = response_json(response)
    check(body.get("total") == 2, f"total={body.get('total')!r}")
    check(body.get("page") == 1, f"page={body.get('page')!r}")
    check(body.get("page_size") == 20, f"page_size={body.get('page_size')!r}")
    items = body.get("items") or []
    check(len(items) == 2, f"items 长度={len(items)}")
    required = {"id", "code", "name", "city", "address", "open_time", "close_time", "status"}
    for item in items:
        missing = required - set(item)
        check(not missing, f"{item.get('code')} 缺少字段 {sorted(missing)}")
    return "200；total=2/page=1/page_size=20；两项字段完整"


def case_qry_02() -> str:
    by_city = response_json(request("GET", "/points", params={"city": "杭州"}, expected=200))
    check(by_city.get("total") == 2, f"city=杭州 total={by_city.get('total')!r}")
    check(all(item.get("city") == "杭州" for item in by_city.get("items", [])), "城市筛选混入其他城市")
    by_keyword = response_json(request("GET", "/points", params={"keyword": "东站"}, expected=200))
    check(by_keyword.get("total") == 1, f"keyword=东站 total={by_keyword.get('total')!r}")
    check(
        by_keyword.get("items", [{}])[0].get("code") == "SP002",
        f"keyword=东站 首项={by_keyword.get('items', [{}])[0].get('code')!r}",
    )
    empty = response_json(request("GET", "/points", params={"city": "上海"}, expected=200))
    check(empty.get("total") == 0 and empty.get("items") == [], "city=上海 未返回空集")
    return "city=杭州→2；keyword=东站→SP002；city=上海→0"


def case_qry_03() -> str:
    cases = [
        ({"page": 0}, "page"),
        ({"page_size": 0}, "page_size"),
        ({"page_size": 101}, "page_size"),
    ]
    observed: list[str] = []
    for params, field in cases:
        response = request("GET", "/points", params=params)
        expect_error(response, 400, "VALIDATION_ERROR", field_contains=field)
        observed.append(f"{params}->{field}")
    return "三条均 400 VALIDATION_ERROR 且 detail 指向字段；" + "；".join(observed)


def case_qry_04() -> str:
    body = response_json(request("GET", "/points/1", expected=200))
    check(body.get("group_count") == 2, f"group_count={body.get('group_count')!r}")
    check(body.get("cabinet_count") == 20, f"cabinet_count={body.get('cabinet_count')!r}")
    missing = request("GET", "/points/99999")
    expect_error(missing, 404, "RESOURCE_NOT_FOUND")
    return "point 1：group_count=2/cabinet_count=20；99999→404 RESOURCE_NOT_FOUND"


def case_qry_05() -> str:
    body = response_json(request("GET", "/points/1/groups", expected=200))
    check(len(body) == 2, f"柜体数量={len(body)}")
    groups = {item["code"]: item for item in body}
    check(groups["A"]["cabinet_count"] == 12, f"A cabinet_count={groups['A']['cabinet_count']}")
    check(
        groups["A"]["available_cabinet_count"] == 11,
        f"A available={groups['A']['available_cabinet_count']}",
    )
    check(groups["B"]["cabinet_count"] == 8, f"B cabinet_count={groups['B']['cabinet_count']}")
    check(
        groups["B"]["available_cabinet_count"] == 8,
        f"B available={groups['B']['available_cabinet_count']}",
    )
    return "2 项；A=12/11（A-12 维护中）；B=8/8"


def case_qry_06() -> str:
    body = response_json(request("GET", "/points/cities", expected=200))
    check(body == ["杭州"], f"cities={body!r}")
    return f"200；去重升序 {body!r}"


def case_qry_07() -> str:
    body = q5(1, D1_1000, D1_1200)
    check(body.get("slot_count") == 4, f"slot_count={body.get('slot_count')!r}")
    check(body.get("luggage_size") is None, f"luggage_size={body.get('luggage_size')!r}")
    groups = group_map(body)
    check(set(groups) == {"A", "B"}, f"groups={sorted(groups)}")
    a_cabs = cabinet_map(groups["A"])
    check(a_cabs["A-01"]["available"] is True, "A-01 available != true")
    check(
        a_cabs["A-12"]["derived_status"] == "MAINTENANCE"
        and a_cabs["A-12"]["available"] is False,
        f"A-12={a_cabs['A-12']}",
    )
    a_s = type_map(groups["A"])["S"]
    check(
        a_s["total_count"] == 6 and a_s["available_count"] == 6,
        f"A/S total/available={a_s['total_count']}/{a_s['available_count']}",
    )
    return "200；slot_count=4；A-01 可用；A-12 MAINTENANCE；A/S=6/6"


def case_qry_08() -> str:
    variants = [
        (at(TARGET_DATE, 10, 15), at(TARGET_DATE, 11, 15)),
        (at(TARGET_DATE, 10, 0).replace(second=30), at(TARGET_DATE, 11, 0).replace(second=30)),
    ]
    for start, end in variants:
        response = request(
            "GET",
            "/cabinets/availability",
            params={"point_id": 1, "start_time": iso(start), "end_time": iso(end)},
        )
        expect_error(response, 400, "TIME_NOT_ALIGNED")
    return "10:15 与 10:00:30 均 400 TIME_NOT_ALIGNED"


def case_qry_09() -> str:
    # 用例原文写 D0+4 10:00 为 145 段；实际是 144 段（允许上限）。
    # 为了验证 145 段，结束时间取 D0+4 10:30。
    variants = [
        (D1_1000, D1_1000),
        (D1_1000, at(TARGET_DATE, 9, 0)),
        (D1_1000, at(TARGET_DATE + timedelta(days=3), 10, 30)),
    ]
    for start, end in variants:
        response = request(
            "GET",
            "/cabinets/availability",
            params={"point_id": 1, "start_time": iso(start), "end_time": iso(end)},
        )
        expect_error(response, 400, "DURATION_OUT_OF_RANGE")
    return "end=start、end<start、145 段均 400 DURATION_OUT_OF_RANGE（145 段用 D0+4 10:30）"


def case_qry_10() -> str:
    bad = [
        (at(TARGET_DATE, 7, 30), at(TARGET_DATE, 9, 0)),
        (at(TARGET_DATE, 20, 0), at(TARGET_DATE, 22, 30)),
    ]
    for start, end in bad:
        response = request(
            "GET",
            "/cabinets/availability",
            params={"point_id": 1, "start_time": iso(start), "end_time": iso(end)},
        )
        expect_error(response, 400, "OUT_OF_BUSINESS_HOURS")
    good = q5(1, D1_0800, D1_2200)
    check(good.get("point_id") == 1, "营业时间闭区间查询未返回 point 1")
    return "07:30→09:00、20:00→22:30 均 400；08:00→22:00 返回 200"


def case_qry_11() -> str:
    body = q5(1, D1_1000, D1_1100, luggage_size="LARGE")
    groups = group_map(body)
    a_types = type_map(groups["A"])
    b_types = type_map(groups["B"])
    check(a_types["S"]["available_count"] == 0, f"A/S available={a_types['S']['available_count']}")
    check(a_types["M"]["available_count"] == 0, f"A/M available={a_types['M']['available_count']}")
    check(a_types["L"]["available_count"] == 1, f"A/L available={a_types['L']['available_count']}")
    check(b_types["L"]["available_count"] == 3, f"B/L available={b_types['L']['available_count']}")
    return "LARGE：A/S=0、A/M=0、A/L=1（A-12 维护）、B/L=3"


def case_qry_12() -> str:
    key = f"b1-qry12-{RUN_ID}"
    cleanup_reservation(key)
    token = valid_token("user01")
    try:
        order = create_reservation(token, 1, D1_1000, D1_1100, key)
        check(order.get("cabinet_code") == "A-01", f"cabinet_code={order.get('cabinet_code')!r}")
        overlap = q5(1, D1_1000, D1_1200)
        a_cabs = cabinet_map(group_map(overlap)["A"])
        check(
            a_cabs["A-01"]["derived_status"] == "RESERVED"
            and a_cabs["A-01"]["available"] is False,
            f"重叠时段 A-01={a_cabs['A-01']}",
        )
        adjacent = q5(1, D1_1100, D1_1200)
        a_cabs_2 = cabinet_map(group_map(adjacent)["A"])
        check(
            a_cabs_2["A-01"]["derived_status"] == "AVAILABLE"
            and a_cabs_2["A-01"]["available"] is True,
            f"相邻时段 A-01={a_cabs_2['A-01']}",
        )
        return "10:00–11:00 预约 A-01；10:00–12:00 重叠→RESERVED/false；11:00–12:00 相邻→AVAILABLE/true"
    finally:
        cleanup_reservation(key)


def case_qry_13() -> str:
    try:
        db_exec("UPDATE storage_points SET status = 'CLOSED' WHERE id = 2")
        closed = q5(2, D1_1000, D1_1100)
        all_cabinets = []
        for group in closed.get("groups", []):
            all_cabinets.extend(cabinet_map(group).values())
        check(bool(all_cabinets), "关闭寄存点后未返回柜格")
        check(
            all(item["derived_status"] == "UNAVAILABLE" and item["available"] is False for item in all_cabinets),
            "关闭寄存点后仍有柜格不是 UNAVAILABLE/false",
        )
        db_exec("UPDATE storage_points SET status = 'OPEN' WHERE id = 2")
        reopened = q5(2, D1_1000, D1_1100)
        d01 = cabinet_map(group_map(reopened)["D"])["D-01"]
        check(
            d01["derived_status"] == "AVAILABLE" and d01["available"] is True,
            f"恢复后 D-01={d01}",
        )
        return f"关闭 SP002→{len(all_cabinets)} 个柜格均 UNAVAILABLE/false；恢复 OPEN 后 D-01=AVAILABLE/true"
    finally:
        db_exec("UPDATE storage_points SET status = 'OPEN' WHERE id = 2")


def case_qry_14() -> str:
    key = f"b1-qry14-{RUN_ID}"
    cleanup_reservation(key)
    token = valid_token("user01")
    try:
        create_reservation(token, 1, D1_1000, D1_1100, key)
        conflict = request(
            "GET",
            "/cabinets/1/availability",
            params={"start_time": iso(D1_1030), "end_time": iso(D1_1130)},
            expected=200,
        )
        body = response_json(conflict)
        check(body.get("available") is False, f"重叠查询 available={body.get('available')!r}")
        conflicts = body.get("conflicts") or []
        check(bool(conflicts), "重叠查询 conflicts 为空")
        check(conflicts[0].get("status") == "RESERVED", f"conflicts[0].status={conflicts[0].get('status')!r}")
        check("order_no" not in conflicts[0], "冲突项泄露了 order_no")
        free = response_json(
            request(
                "GET",
                "/cabinets/1/availability",
                params={"start_time": iso(D1_1100), "end_time": iso(D1_1200)},
                expected=200,
            )
        )
        check(free.get("available") is True, f"相邻查询 available={free.get('available')!r}")
        check(free.get("conflicts") == [], f"相邻查询 conflicts={free.get('conflicts')!r}")
        missing = request(
            "GET",
            "/cabinets/99999/availability",
            params={"start_time": iso(D1_1030), "end_time": iso(D1_1130)},
        )
        expect_error(missing, 404, "RESOURCE_NOT_FOUND")
        return "重叠 10:30–11:30→false/RESERVED 且无 order_no；11:00–12:00→true/[]；99999→404"
    finally:
        cleanup_reservation(key)


def case_qry_15() -> str:
    c12 = response_json(request("GET", "/cabinets/12", expected=200))
    check(c12.get("physical_status") == "MAINTENANCE", f"12 physical={c12.get('physical_status')!r}")
    check(c12.get("derived_status") == "MAINTENANCE", f"12 derived={c12.get('derived_status')!r}")
    c1 = response_json(request("GET", "/cabinets/1", expected=200))
    check(c1.get("physical_status") == "AVAILABLE", f"1 physical={c1.get('physical_status')!r}")
    check(c1.get("derived_status") == "AVAILABLE", f"1 derived={c1.get('derived_status')!r}")
    columns = db_all("SHOW COLUMNS FROM cabinets LIKE 'derived_status'")
    check(columns == [], f"cabinets 表存在 derived_status 列：{columns}")
    return "12→MAINTENANCE/MAINTENANCE；1→AVAILABLE/AVAILABLE；DB cabinets 无 derived_status 列"


# ======================================================================
# 执行与输出
# ======================================================================
CASES: list[tuple[str, str, Callable[[], str]]] = [
    ("TC-AUTH-01", "用户登录成功", case_auth_01),
    ("TC-AUTH-02", "密码错误", case_auth_02),
    ("TC-AUTH-03", "用户名不存在", case_auth_03),
    ("TC-AUTH-04", "注册成功", case_auth_04),
    ("TC-AUTH-05", "注册唯一性冲突", case_auth_05),
    ("TC-AUTH-06", "注册参数非法（逐项）", case_auth_06),
    ("TC-AUTH-07", "用户名长度边界", case_auth_07),
    ("TC-AUTH-08", "未携带 token 访问受保护接口", case_auth_08),
    ("TC-AUTH-09", "非法 token 与过期 token", case_auth_09),
    ("TC-AUTH-10", "登出后旧 token 立即失效", case_auth_10),
    ("TC-AUTH-11", "禁用账号", case_auth_11),
    ("TC-QRY-01", "寄存点列表默认分页", case_qry_01),
    ("TC-QRY-02", "城市与关键字筛选", case_qry_02),
    ("TC-QRY-03", "分页参数越界", case_qry_03),
    ("TC-QRY-04", "寄存点详情与不存在", case_qry_04),
    ("TC-QRY-05", "柜体列表的柜格统计", case_qry_05),
    ("TC-QRY-06", "城市列表", case_qry_06),
    ("TC-QRY-07", "按时间段查询可用柜格（Q5）", case_qry_07),
    ("TC-QRY-08", "查询时间未对齐", case_qry_08),
    ("TC-QRY-09", "查询时长非法", case_qry_09),
    ("TC-QRY-10", "查询超出营业时间", case_qry_10),
    ("TC-QRY-11", "行李尺寸过滤", case_qry_11),
    ("TC-QRY-12", "已预约时段与相邻时段", case_qry_12),
    ("TC-QRY-13", "寄存点关闭时的派生状态", case_qry_13),
    ("TC-QRY-14", "单柜格可用性（Q6）", case_qry_14),
    ("TC-QRY-15", "柜格详情：物理状态与派生状态", case_qry_15),
]


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    cleanup_b1_reservations()
    results = []
    print(f"B1 run id={RUN_ID} date={TARGET_DATE} cases={len(CASES)}")
    for case_id, title, func in CASES:
        started = time.perf_counter()
        try:
            detail = func()
            status = "PASS"
            error = ""
        except Exception as exc:  # noqa: BLE001 - 单条失败不应阻断批次
            status = "FAIL"
            detail = ""
            error = f"{type(exc).__name__}: {exc}"
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        results.append(
            {
                "case_id": case_id,
                "title": title,
                "status": status,
                "detail": detail,
                "error": error,
                "elapsed_ms": elapsed_ms,
            }
        )
        print(f"{case_id} {status} {elapsed_ms}ms" + (f" {error}" if error else ""))

    # 清理可能残留的测试账号
    for name in ("tst_user01", "tst_" + "a" * 28):
        cleanup_user(name)
    for row in db_all("SELECT username FROM users WHERE username LIKE 'tst\\_%'"):
        cleanup_user(row[0])

    passed = sum(1 for item in results if item["status"] == "PASS")
    failed = len(results) - passed
    summary = {
        "run_id": RUN_ID,
        "executed_at": datetime.now().isoformat(timespec="seconds"),
        "target_date": TARGET_DATE.isoformat(),
        "base_url": BASE_URL,
        "execution_mode": "自动化脚本（API + MySQL 断言），不是人工点击",
        "total": len(results),
        "passed": passed,
        "failed": failed,
        "cases": results,
    }
    JSON_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# B1 认证与查询执行结果",
        "",
        f"- 执行时间：{summary['executed_at']}",
        f"- 执行方式：{summary['execution_mode']}",
        f"- 目标日期：D0+1 = {TARGET_DATE}",
        f"- 结果：**{passed}/{len(results)} 通过，{failed} 失败**",
        "",
        "| 用例 | 标题 | 结果 | 实际结果 / 失败原因 | 耗时 |",
        "|---|---|---|---|---:|",
    ]
    for item in results:
        text_value = item["detail"] if item["status"] == "PASS" else item["error"]
        text_value = text_value.replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| {item['case_id']} | {item['title']} | {item['status']} | {text_value} | {item['elapsed_ms']} ms |"
        )
    lines.extend(
        [
            "",
            "> 脚本执行结果只代表本次环境、本次数据；不把脚本执行写成“人工执行”。",
            "",
        ]
    )
    MD_PATH.write_text("\n".join(lines), encoding="utf-8")

    # 更新 123 条跟踪表中 B1 行
    if TRACKER_PATH.exists():
        import csv

        with TRACKER_PATH.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        by_id = {item["case_id"]: item for item in results}
        for row in rows:
            item = by_id.get(row["case_id"])
            if not item:
                continue
            row["status"] = "已执行（脚本）"
            row["execution_date"] = summary["executed_at"][:10]
            row["actual_result"] = item["detail"] if item["status"] == "PASS" else item["error"]
            row["evidence"] = f"docs/execution/b1-auth-query-results.md#{item['case_id']}"
            row["defect_or_note"] = "" if item["status"] == "PASS" else "B1 执行失败，待定位"
        with TRACKER_PATH.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

    print(f"RESULT {passed}/{len(results)} passed, {failed} failed")
    print(f"JSON {JSON_PATH}")
    print(f"MD {MD_PATH}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
