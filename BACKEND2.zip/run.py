"""
开发环境启动脚本。

用法（在 backend 目录下执行）：
    python run.py                    # 默认 127.0.0.1:8000，开启热重载
    python run.py --port 8001        # 换端口
    python run.py --no-reload        # 关闭热重载（排查问题时推荐）
    python run.py --force            # 跳过端口占用检查，强行启动

设计说明（为什么要有这个文件，而不是直接 uvicorn app.main:app）：

1. 【端口占用友好提示】
   uvicorn 端口被占用时只抛 `[Errno 10048] 通常每个套接字地址只允许使用一次`，
   新手很难判断是谁占的。这里先查占用进程并直接给出结束命令。

2. 【workers 必须为 1】
   见设计方案 BR-41：超时释放任务用 APScheduler 内嵌在进程内执行，
   多进程会导致同一个任务被并发执行，虽然逻辑幂等但会产生重复的任务日志，
   干扰测试断言。

3. 【热重载只监视 app 目录】
   uvicorn 默认监视整个 backend 目录。把 logs/、frontend/ 排除在外，
   避免日志写入或前端改动触发无意义的重启。
   注意：排除规则依赖 watchfiles 包；未安装时 uvicorn 会退回 StatReload，
   该模式下排除规则不生效（此时只监视 *.py，也不会被日志文件触发）。
"""

from __future__ import annotations

import argparse
import os
import socket
import subprocess
import sys

import uvicorn

#: 热重载只监视业务代码目录（需要在导入 app.core.config 之后才能得到 BACKEND_DIR，
#: 因此在 main() 里才真正赋值 —— 见下面关于 --no-scheduler 的说明）
WATCH_DIRS: list[str] = []
RELOAD_EXCLUDES = ["*/logs/*", "*.log", "*/__pycache__/*", "*/tests/*"]


def find_port_owners(port: int) -> list[int]:
    """通过 netstat 查找正在 LISTEN 指定端口的进程号。"""
    pids: set[int] = set()
    try:
        result = subprocess.run(
            ["netstat", "-ano", "-p", "TCP"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except Exception:  # noqa: BLE001 - 查不到就当没占用，后面还有真实绑定兜底
        return []

    for line in result.stdout.splitlines():
        parts = line.split()
        # 形如：  TCP    127.0.0.1:8000    0.0.0.0:0    LISTENING    29012
        if len(parts) >= 5 and parts[3] == "LISTENING" and parts[1].endswith(f":{port}"):
            try:
                pids.add(int(parts[4]))
            except ValueError:
                continue
    return sorted(pids)


def port_is_free(host: str, port: int) -> bool:
    """
    真正尝试绑定一次，确认端口可用。
    比只看 netstat 更可靠（例如端口被 TIME_WAIT 短时占用时 netstat 查不到监听者）。
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if sys.platform == "win32":
            # 避免 SO_REUSEADDR 让"已被占用"的端口看起来仍然可用
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        sock.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def report_port_conflict(port: int) -> None:
    owners = find_port_owners(port)
    print()
    print("!" * 68)
    print(f"启动失败：端口 {port} 已被占用")
    print("!" * 68)
    if owners:
        print("占用该端口的进程：")
        for pid in owners:
            print(f"    PID = {pid}")
        print()
        print("请任选一种方式处理：")
        print(f"    1) 结束占用进程（需要【管理员】终端）: taskkill /PID {owners[0]} /F")
        print("    2) 换一个端口启动            : python run.py --port 8001")
    else:
        print("未找到 LISTEN 该端口的进程，可能处于 TIME_WAIT 状态或权限不足无法读取。")
        print("建议：换端口启动  ->  python run.py --port 8001")
    print()
    print("常见原因：")
    print("    - 之前启动的服务没有正常关闭（直接关掉了黑窗口，子进程被留了下来）")
    print("    - 上一次以管理员权限启动，普通权限的 taskkill 无法结束它")
    print("!" * 68)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="启动智能行李寄存柜预约系统后端")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--no-reload", action="store_true", help="关闭热重载")
    parser.add_argument(
        "--no-scheduler",
        action="store_true",
        help="不启动内嵌定时任务（ENABLE_SCHEDULER=false），"
             "用于需要确定性结果的定时任务测试或单独跑 CLI 任务",
    )
    parser.add_argument("--force", action="store_true", help="跳过端口占用检查")
    args = parser.parse_args(argv)

    # 【必须在导入 app.core.config 之前设置】
    # settings 是 @lru_cache 单例，一旦构建完成就不再受环境变量影响；
    # 而且在 --no-reload 时 uvicorn 会在**本进程**内导入 app.main，
    # 所以只能在导入配置之前把环境变量设好，否则这个开关会静默失效。
    if args.no_scheduler:
        os.environ["ENABLE_SCHEDULER"] = "false"

    from app.core.config import BACKEND_DIR, settings

    global WATCH_DIRS
    WATCH_DIRS = [str(BACKEND_DIR / "app")]

    host = args.host or settings.HOST
    port = args.port or settings.PORT

    if not args.force and not port_is_free(host, port):
        report_port_conflict(port)
        return 1

    reload_enabled = settings.DEBUG and not args.no_reload

    print("=" * 68)
    print(f"  {settings.APP_NAME}")
    print("=" * 68)
    print(f"  环境        : {settings.APP_ENV}")
    print(f"  监听地址    : http://{host}:{port}")
    print(f"  前端首页    : http://{host}:{port}/")
    print(f"  接口文档    : http://{host}:{port}/docs")
    print(f"  健康检查    : http://{host}:{port}{settings.API_PREFIX}/health")
    print(f"  热重载      : {'开启（仅监视 app 目录）' if reload_enabled else '关闭'}")
    print(f"  定时任务    : {'关闭（--no-scheduler）' if args.no_scheduler else '随服务启动'}")
    print("-" * 68)
    print("  停止服务请按 Ctrl + C")
    print("  【重要】不要用鼠标在窗口里点击或拖选，Windows 控制台会进入")
    print("          「选择模式」并挂起进程，导致浏览器一直转圈不响应。")
    print("          若标题栏出现「选择」字样，按 Esc 或回车即可恢复。")
    print("=" * 68)
    print()

    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=reload_enabled,
        workers=1,
        reload_dirs=WATCH_DIRS if reload_enabled else None,
        reload_excludes=RELOAD_EXCLUDES if reload_enabled else None,
        log_level="debug" if settings.DEBUG else "info",
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
