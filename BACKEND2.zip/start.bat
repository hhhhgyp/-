@echo off
chcp 65001 >nul
setlocal

rem ============================================================
rem  智能行李寄存柜预约系统 - 一键启动（Windows）
rem  双击本文件即可启动后端服务
rem ============================================================

cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [错误] 未找到虚拟环境 .venv
    echo         请先执行：
    echo             python -m venv .venv
    echo             .venv\Scripts\python.exe -m pip install -r requirements.txt
    pause
    exit /b 1
)

if not exist ".env" (
    echo [提示] 未找到 .env，正在从 .env.example 复制...
    copy /y ".env.example" ".env" >nul
    echo [重要] 请先编辑 .env 填写 DB_PASSWORD，然后重新运行本脚本。
    pause
    exit /b 1
)

echo 正在启动服务，首次启动请确认 MySQL 已运行...
echo.
".venv\Scripts\python.exe" run.py %*

echo.
echo 服务已退出。
pause
