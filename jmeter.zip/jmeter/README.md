# JMeter 并发预约测试

本目录是「智能行李寄存柜预约系统」的 JMeter 并发测试资产，详细设计、接口核实、执行步骤和实际结果见：

**[docs/08-JMeter并发预约测试.md](../docs/08-JMeter并发预约测试.md)**

## 目录

```text
plans/
  same-cabinet.jmx        # S1 多用户竞争同一柜格
  limited-cabinets.jmx    # S2 多用户竞争有限柜格
  duplicate-submit.jmx    # S3 同一用户重复提交同一幂等键
  concurrent-cancel.jmx   # S4 同一订单并发取消
tools/
  build_plans.py          # 生成四个 JMX
  jmeter_data.py          # prepare / verify / cleanup
run.ps1                   # 一键执行
data/                     # 运行时生成的 CSV/properties/run.json（含临时 token，勿提交）
results/                  # JTL、HTML Dashboard、verify JSON
```

## 前置条件

1. 后端已启动：`python run.py --port 8138 --no-reload --no-scheduler`
2. 已安装 JMeter 5.6.3（Java 8+），并设置 `JMETER_HOME`，或让 `jmeter` 在 `PATH` 中
3. `backend/.venv` 已安装项目依赖

## 一键运行

```powershell
$env:JMETER_HOME = "C:\apache-jmeter-5.6.3"

# 小规模验证
.\jmeter\run.ps1 -Scenario same -Threads 4 -Ramp 1 -Loops 1
.\jmeter\run.ps1 -Scenario limited -Threads 12 -Cabinets 6 -Ramp 2 -Loops 1
.\jmeter\run.ps1 -Scenario duplicate -Threads 8 -Ramp 1 -Loops 1
.\jmeter\run.ps1 -Scenario cancel -Threads 8 -Ramp 1 -Loops 1
```

每次运行会自动：

1. 清理上一轮 JMeter 测试数据；
2. 创建独立寄存点、柜体、柜格、临时用户和待取消订单；
3. 以非 GUI 模式执行 JMeter，写出 JTL 和 HTML Dashboard；
4. 解析 JTL 并直接查询 MySQL，核对活动订单、时段唯一性、幂等订单号、取消状态；
5. 再次清理测试数据。

> 409 是竞争场景的**预期**结果，JMeter 控制台的 `Err: 0` 不代表业务一定正确；通过与否以 `verify` 的数据库事实为准。
