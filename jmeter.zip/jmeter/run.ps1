param(
    [ValidateSet("same", "limited", "duplicate", "cancel")]
    [string]$Scenario = "same",
    [int]$Threads = 0,
    [int]$Cabinets = 0,
    [int]$Ramp = 0,
    [int]$Loops = 1,
    [switch]$KeepData,
    [switch]$Monitor
)

$ErrorActionPreference = "Stop"
$JmeterDir = $PSScriptRoot
$ProjectRoot = Split-Path $JmeterDir -Parent
$Python = Join-Path $ProjectRoot "backend\.venv\Scripts\python.exe"
$Tool = Join-Path $JmeterDir "tools\jmeter_data.py"

if (-not (Test-Path $Python)) {
    throw "Python not found: $Python. Create backend/.venv and install dependencies first."
}

if (-not $env:JMETER_CMD) {
    $command = Get-Command jmeter -ErrorAction SilentlyContinue
    if ($command) {
        $env:JMETER_CMD = $command.Source
    } elseif ($env:JMETER_HOME) {
        $env:JMETER_CMD = Join-Path $env:JMETER_HOME "bin\jmeter.bat"
    } else {
        throw "JMeter not found. Set JMETER_HOME (for example C:\apache-jmeter-5.6.3) or JMETER_CMD."
    }
}
$Jmeter = $env:JMETER_CMD

if ($Threads -le 0) {
    $Threads = switch ($Scenario) {
        "same" { 4 }
        "limited" { 12 }
        "duplicate" { 8 }
        "cancel" { 8 }
    }
}
if ($Cabinets -le 0) {
    $Cabinets = if ($Scenario -eq "limited") { 6 } else { 1 }
}
if ($Ramp -le 0) {
    $Ramp = if ($Scenario -eq "limited") { 2 } else { 1 }
}
if ($Loops -le 0) {
    throw "Loops must be greater than 0."
}

$Plan = switch ($Scenario) {
    "same" { "plans\same-cabinet.jmx" }
    "limited" { "plans\limited-cabinets.jmx" }
    "duplicate" { "plans\duplicate-submit.jmx" }
    "cancel" { "plans\concurrent-cancel.jmx" }
}
$Name = "$Scenario-$Threads"
$Jtl = "results\$Name.jtl"
$Html = "results\$Name-html"
$Log = "results\$Name.log"
$MonitorScript = Join-Path $JmeterDir "tools\resource_monitor.py"
$ResourceCsv = Join-Path $JmeterDir "results\$Name-resources.csv"
$ResourceSummary = Join-Path $JmeterDir "results\$Name-resources.summary.json"
$ResourceStop = Join-Path $JmeterDir "results\.monitor-$Name.stop"

Push-Location $JmeterDir
$exitCode = 0
$monitorProcess = $null
try {
    # Always start from clean data so previous orders/keys/cancel state cannot pollute the result.
    & $Python $Tool cleanup
    if ($LASTEXITCODE -ne 0) { throw "cleanup failed" }

    $prepareArgs = @(
        $Tool, "prepare",
        "--scenario", $Scenario,
        "--users", "$Threads",
        "--cabinets", "$Cabinets"
    )
    & $Python @prepareArgs
    if ($LASTEXITCODE -ne 0) { throw "prepare failed" }

    if ($Monitor) {
        Remove-Item $ResourceCsv, $ResourceSummary, $ResourceStop -Force -ErrorAction SilentlyContinue
        $monitorArgs = @(
            "`"$MonitorScript`"",
            "--output", "`"$ResourceCsv`"",
            "--stop-file", "`"$ResourceStop`"",
            "--interval", "1"
        ) -join " "
        $monitorProcess = Start-Process -FilePath $Python -ArgumentList $monitorArgs -PassThru -WindowStyle Hidden
        Start-Sleep -Milliseconds 3000
        Write-Host "Resource monitor started: PID $($monitorProcess.Id), CSV $ResourceCsv" -ForegroundColor Cyan
    }

    if (Test-Path $Jtl) { Remove-Item $Jtl -Force }
    if (Test-Path $Html) { Remove-Item $Html -Recurse -Force }

    $jmeterArgs = @(
        "-n",
        "-t", $Plan,
        "-q", "data\scenario.properties",
        "-Jthreads=$Threads",
        "-Jramp=$Ramp",
        "-Jloops=$Loops",
        "-Jsample_variables=jm_code,jm_order_no,jm_idem_replay",
        "-Jjmeter.save.saveservice.output_format=csv",
        "-Jjmeter.save.saveservice.response_data=false",
        "-Jjmeter.save.saveservice.assertion_results_failure_message=true",
        "-l", $Jtl,
        "-e", "-o", $Html
    )
    & $Jmeter @jmeterArgs 2>&1 | Tee-Object -FilePath $Log
    if ($LASTEXITCODE -ne 0) { throw "JMeter failed, see $Log" }

    $expectedSamples = $Threads * $Loops
    & $Python $Tool verify --jtl $Jtl --samples $expectedSamples
    if ($LASTEXITCODE -ne 0) {
        $exitCode = $LASTEXITCODE
        Write-Host "Verification failed: HTTP success rate alone is not accepted." -ForegroundColor Red
    }
} catch {
    Write-Host "Run failed: $($_.Exception.Message)" -ForegroundColor Red
    $exitCode = 1
} finally {
    if ($Monitor -and $monitorProcess) {
        New-Item -ItemType File -Path $ResourceStop -Force | Out-Null
        try {
            Wait-Process -Id $monitorProcess.Id -Timeout 12 -ErrorAction Stop
        } catch {
            Stop-Process -Id $monitorProcess.Id -Force -ErrorAction SilentlyContinue
        }
        Remove-Item $ResourceStop -Force -ErrorAction SilentlyContinue
        if (Test-Path $ResourceSummary) {
            Write-Host "Resource summary: $ResourceSummary" -ForegroundColor Cyan
        }
    }
    if (-not $KeepData) {
        & $Python $Tool cleanup
    } else {
        Write-Host "Test data kept (-KeepData): $JmeterDir\data\run.json"
    }
    Pop-Location
}

exit $exitCode
