"""生成 JMeter 5.6.3 测试计划（.jmx）。

把四个场景的公共结构放在模板里，避免手写 JMX 时出现不一致。
运行：python jmeter/tools/build_plans.py
"""

from __future__ import annotations

from pathlib import Path

HERE = Path(__file__).resolve().parent
PLAN_DIR = HERE.parent / "plans"
PLAN_DIR.mkdir(parents=True, exist_ok=True)


PRE_CSV = r"""        <JSR223PreProcessor guiclass="TestBeanGUI" testclass="JSR223PreProcessor" testname="构造预约 JSON" enabled="true">
          <stringProp name="cacheKey"></stringProp>
          <stringProp name="filename"></stringProp>
          <stringProp name="parameters"></stringProp>
          <stringProp name="scriptLanguage">groovy</stringProp>
          <stringProp name="script"><![CDATA[
import groovy.json.JsonOutput
// 每轮请求使用新的幂等键：竞争场景的正确性只看“同一柜格同一时段只能成功一次”，
// 不能因为 CSV 循环导致第二轮变成幂等重放，从而误判为资源仍然可用。
def key = props.get('run_id') + '-' + UUID.randomUUID().toString()
def body = [
    cabinet_id: Integer.parseInt(vars.get('cabinet_id')),
    start_time: props.get('start_time'),
    end_time: props.get('end_time'),
    luggage_size: 'SMALL',
    idempotency_key: key
]
vars.put('payload', JsonOutput.toJson(body))
]]></stringProp>
        </JSR223PreProcessor>
        <hashTree/>"""

PRE_FIXED = r"""        <JSR223PreProcessor guiclass="TestBeanGUI" testclass="JSR223PreProcessor" testname="构造预约 JSON" enabled="true">
          <stringProp name="cacheKey"></stringProp>
          <stringProp name="filename"></stringProp>
          <stringProp name="parameters"></stringProp>
          <stringProp name="scriptLanguage">groovy</stringProp>
          <stringProp name="script"><![CDATA[
import groovy.json.JsonOutput
def body = [
    cabinet_id: Integer.parseInt(props.get('cabinet_id')),
    start_time: props.get('start_time'),
    end_time: props.get('end_time'),
    luggage_size: 'SMALL',
    idempotency_key: props.get('idempotency_key')
]
vars.put('payload', JsonOutput.toJson(body))
]]></stringProp>
        </JSR223PreProcessor>
        <hashTree/>"""

CSV_DATASET = r"""        <CSVDataSet guiclass="TestBeanGUI" testclass="CSVDataSet" testname="用户与柜格 CSV" enabled="true">
          <stringProp name="filename">data/threads.csv</stringProp>
          <stringProp name="fileEncoding">UTF-8</stringProp>
          <stringProp name="variableNames">token,username,cabinet_id,idempotency_key</stringProp>
          <boolProp name="ignoreFirstLine">true</boolProp>
          <stringProp name="delimiter">,</stringProp>
          <boolProp name="quotedData">false</boolProp>
          <boolProp name="recycle">true</boolProp>
          <boolProp name="stopThread">false</boolProp>
          <stringProp name="shareMode">shareMode.all</stringProp>
        </CSVDataSet>
        <hashTree/>"""

ALLOW = r"""          <ResponseAssertion guiclass="AssertionGui" testclass="ResponseAssertion" testname="允许 4xx 由业务断言判定" enabled="true">
            <collectionProp name="Asserion.test_strings"/>
            <stringProp name="Assertion.custom_message"></stringProp>
            <stringProp name="Assertion.test_field">Assertion.response_code</stringProp>
            <boolProp name="Assertion.assume_success">true</boolProp>
            <intProp name="Assertion.test_type">16</intProp>
          </ResponseAssertion>
          <hashTree/>"""

POST = r"""          <JSR223PostProcessor guiclass="TestBeanGUI" testclass="JSR223PostProcessor" testname="提取响应字段到 JTL" enabled="true">
            <stringProp name="cacheKey"></stringProp>
            <stringProp name="filename"></stringProp>
            <stringProp name="parameters"></stringProp>
            <stringProp name="scriptLanguage">groovy</stringProp>
            <stringProp name="script"><![CDATA[
import groovy.json.JsonSlurper
def raw = prev.getResponseDataAsString() ?: ''
try {
    def json = new JsonSlurper().parseText(raw)
    vars.put('jm_code', (json.code ?: '') as String)
    vars.put('jm_order_no', (json.order_no ?: '') as String)
    vars.put('jm_idem_replay', String.valueOf(json.idempotent_replay ?: false))
} catch (Exception ignored) {
    // 非 JSON 响应不在这里失败，交给断言给出更明确的错误。
}
]]></stringProp>
          </JSR223PostProcessor>
          <hashTree/>"""

ASSERT = r"""          <JSR223Assertion guiclass="TestBeanGUI" testclass="JSR223Assertion" testname="业务语义断言" enabled="true">
            <stringProp name="cacheKey"></stringProp>
            <stringProp name="filename"></stringProp>
            <stringProp name="parameters"></stringProp>
            <stringProp name="scriptLanguage">groovy</stringProp>
            <stringProp name="script"><![CDATA[
import groovy.json.JsonSlurper

def mode = '@@MODE@@'
def http = prev.getResponseCode() as int
def raw = prev.getResponseDataAsString() ?: ''
def json = null
try {
    json = new JsonSlurper().parseText(raw)
} catch (Exception ignored) {
}

def fail = { String message ->
    AssertionResult.setFailure(true)
    AssertionResult.setFailureMessage(message)
}

// 503 是服务端锁等待超时/资源饱和，不是“正常的业务冲突”。
// 小规模验证中若出现，应停止加负载并排查环境，而不是把它算作业务失败或成功。
if (http == 503) {
    fail('HTTP 503 ' + (json?.code ?: 'LOCK_TIMEOUT') + '：服务端锁等待超时，属环境饱和信号；请降低并发或延长等待，不要据此判断超卖')
    return
}

if (json == null) {
    fail('响应不是 JSON：HTTP ' + http + '，body=' + raw.take(200))
    return
}

if (mode == 'same' || mode == 'limited') {
    if (http == 201) {
        if (!json.order_no) fail('201 响应缺少 order_no')
        if (json.status != 'RESERVED') fail('201 状态不是 RESERVED: ' + json.status)
        if (json.idempotent_replay != false) fail('201 的 idempotent_replay 应为 false')
    } else if (http == 409) {
        if (json.code != 'CABINET_TIME_CONFLICT') {
            fail('409 业务码不是 CABINET_TIME_CONFLICT: ' + json.code)
        }
    } else {
        fail('非预期 HTTP ' + http + '，code=' + (json.code ?: '') + '，body=' + raw.take(200))
    }
} else if (mode == 'duplicate') {
    if (http != 200 && http != 201) {
        fail('幂等提交只允许 200/201，实际 ' + http + '，code=' + (json.code ?: '') + '，body=' + raw.take(200))
        return
    }
    if (!json.order_no) fail('幂等响应缺少 order_no')
    if (http == 200 && json.idempotent_replay != true) fail('200 必须是 idempotent_replay=true')
    if (http == 201 && json.idempotent_replay != false) fail('201 必须是 idempotent_replay=false')
} else if (mode == 'cancel') {
    if (http == 200) {
        if (json.status != 'CANCELLED') fail('取消成功但 status=' + json.status)
        if (json.released_slot_count != 2) fail('取消成功但释放时段数=' + json.released_slot_count)
    } else if (http == 409) {
        if (json.code != 'ORDER_STATUS_NOT_ALLOWED') {
            fail('并发取消的 409 业务码不是 ORDER_STATUS_NOT_ALLOWED: ' + json.code)
        }
    } else {
        fail('非预期 HTTP ' + http + '，code=' + (json.code ?: '') + '，body=' + raw.take(200))
    }
} else {
    fail('未知 mode: ' + mode)
}
]]></stringProp>
          </JSR223Assertion>
          <hashTree/>"""

PLAN = r"""<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="@@TITLE@@" enabled="true">
      <stringProp name="TestPlan.comments">@@COMMENT@@</stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.user_defined_variables" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
        <collectionProp name="Arguments.arguments"/>
      </elementProp>
      <stringProp name="TestPlan.user_define_classpath"></stringProp>
    </TestPlan>
    <hashTree>
      <ConfigTestElement guiclass="HttpDefaultsGui" testclass="ConfigTestElement" testname="HTTP Request Defaults" enabled="true">
        <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
          <collectionProp name="Arguments.arguments"/>
        </elementProp>
        <stringProp name="HTTPSampler.domain">${__P(host,127.0.0.1)}</stringProp>
        <stringProp name="HTTPSampler.port">${__P(port,8138)}</stringProp>
        <stringProp name="HTTPSampler.protocol">${__P(protocol,http)}</stringProp>
        <stringProp name="HTTPSampler.contentEncoding">UTF-8</stringProp>
        <stringProp name="HTTPSampler.path"></stringProp>
        <stringProp name="HTTPSampler.method">POST</stringProp>
        <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
        <boolProp name="HTTPSampler.follow_redirects">false</boolProp>
        <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
        <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
        <stringProp name="HTTPSampler.implementation">HttpClient4</stringProp>
        <stringProp name="HTTPSampler.connect_timeout">5000</stringProp>
        <stringProp name="HTTPSampler.response_timeout">30000</stringProp>
      </ConfigTestElement>
      <hashTree/>
      <HeaderManager guiclass="HeaderPanel" testclass="HeaderManager" testname="Authorization / JSON" enabled="true">
        <collectionProp name="HeaderManager.headers">
          <elementProp name="" elementType="Header">
            <stringProp name="Header.name">Authorization</stringProp>
            <stringProp name="Header.value">@@AUTH@@</stringProp>
          </elementProp>
          <elementProp name="" elementType="Header">
            <stringProp name="Header.name">Content-Type</stringProp>
            <stringProp name="Header.value">application/json</stringProp>
          </elementProp>
        </collectionProp>
      </HeaderManager>
      <hashTree/>
      <ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="@@TG@@" enabled="true">
        <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
        <elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlPanel" testclass="LoopController" testname="Loop Controller" enabled="true">
          <boolProp name="LoopController.continue_forever">false</boolProp>
          <stringProp name="LoopController.loops">${__P(loops,1)}</stringProp>
        </elementProp>
        <stringProp name="ThreadGroup.num_threads">${__P(threads,4)}</stringProp>
        <stringProp name="ThreadGroup.ramp_time">${__P(ramp,1)}</stringProp>
        <boolProp name="ThreadGroup.scheduler">false</boolProp>
        <stringProp name="ThreadGroup.duration"></stringProp>
        <stringProp name="ThreadGroup.delay"></stringProp>
        <boolProp name="ThreadGroup.same_user_on_next_iteration">true</boolProp>
      </ThreadGroup>
      <hashTree>
@@DATASET@@@@PRE@@        <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="@@SAMPLER@@" enabled="true">
          <elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
            <collectionProp name="Arguments.arguments">
              <elementProp name="" elementType="HTTPArgument">
                <boolProp name="HTTPArgument.always_encode">false</boolProp>
                <stringProp name="Argument.value">@@PAYLOAD@@</stringProp>
                <stringProp name="Argument.metadata">=</stringProp>
              </elementProp>
            </collectionProp>
          </elementProp>
          <stringProp name="HTTPSampler.path">@@PATH@@</stringProp>
          <stringProp name="HTTPSampler.method">POST</stringProp>
          <boolProp name="HTTPSampler.follow_redirects">false</boolProp>
          <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
          <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
          <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
          <boolProp name="HTTPSampler.postBodyRaw">true</boolProp>
        </HTTPSamplerProxy>
        <hashTree>
@@ALLOW@@@@POST@@@@ASSERT@@        </hashTree>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
"""


def build(
    *,
    filename: str,
    title: str,
    comment: str,
    thread_group: str,
    sampler: str,
    auth: str,
    path: str,
    payload: str,
    mode: str,
    dataset: str,
    pre: str,
) -> None:
    text = (
        PLAN.replace("@@TITLE@@", title)
        .replace("@@COMMENT@@", comment)
        .replace("@@TG@@", thread_group)
        .replace("@@SAMPLER@@", sampler)
        .replace("@@AUTH@@", auth)
        .replace("@@PATH@@", path)
        .replace("@@PAYLOAD@@", payload)
        .replace("@@DATASET@@", dataset)
        .replace("@@PRE@@", pre)
        .replace("@@ALLOW@@", ALLOW)
        .replace("@@POST@@", POST)
        .replace("@@ASSERT@@", ASSERT)
        # 必须在 ASSERT 插入模板后再替换 mode，否则断言脚本里仍是占位符。
        .replace("@@MODE@@", mode)
    )
    (PLAN_DIR / filename).write_text(text, encoding="utf-8")
    print(f"wrote {PLAN_DIR / filename}")


def main() -> None:
    build(
        filename="same-cabinet.jmx",
        title="S1 多用户竞争同一柜格",
        comment="全部线程使用不同用户、不同幂等键，请求同一柜格同一时段。期望 1 个 201，其余 409；最终以 DB 事实校验为准。",
        thread_group="S1 竞争同一柜格",
        sampler="POST /reservations（同一柜格）",
        auth="Bearer ${token}",
        path="/api/v1/reservations",
        payload="${payload}",
        mode="same",
        dataset=CSV_DATASET,
        pre=PRE_CSV,
    )
    build(
        filename="limited-cabinets.jmx",
        title="S2 多用户竞争有限柜格",
        comment="线程数大于柜格数，按 CSV 轮转分配柜格。期望 201 数 = min(线程数, 柜格数)，其余 409；最终以 DB 事实校验为准。",
        thread_group="S2 竞争有限柜格",
        sampler="POST /reservations（有限柜格）",
        auth="Bearer ${token}",
        path="/api/v1/reservations",
        payload="${payload}",
        mode="limited",
        dataset=CSV_DATASET,
        pre=PRE_CSV,
    )
    build(
        filename="duplicate-submit.jmx",
        title="S3 同一用户重复提交同一幂等键",
        comment="全部线程使用同一用户、同一幂等键、同一柜格同一时段。期望 1 个 201，其余 200 重放，订单号一致；最终以 DB 事实校验为准。",
        thread_group="S3 幂等重复提交",
        sampler="POST /reservations（同一幂等键）",
        auth="Bearer ${__P(token)}",
        path="/api/v1/reservations",
        payload="${payload}",
        mode="duplicate",
        dataset="",
        pre=PRE_FIXED,
    )
    build(
        filename="concurrent-cancel.jmx",
        title="S4 同一订单并发取消",
        comment="数据准备阶段先创建一个待取消订单，全部线程使用订单所有者 token 并发取消。期望 1 个 200，其余 409 ORDER_STATUS_NOT_ALLOWED；最终以 DB 状态和时段释放校验为准。",
        thread_group="S4 并发取消同一订单",
        sampler="POST /reservations/{order_no}/cancel",
        auth="Bearer ${__P(token)}",
        path="/api/v1/reservations/${__P(order_no)}/cancel",
        payload='{"reason":"JMeter 并发取消测试"}',
        mode="cancel",
        dataset="",
        pre="",
    )


if __name__ == "__main__":
    main()
