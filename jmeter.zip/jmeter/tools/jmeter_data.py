"""
JMeter 并发预约测试的数据准备 / 校验 / 清理工具。

它只负责“测试数据”和“结果事实核对”，不负责产生性能结论：
- prepare：创建独立寄存点/柜体/柜格/临时用户，生成 tokens CSV 与 scenario.properties
- verify：解析 JTL 的 HTTP 状态计数，并直接查 MySQL 验证订单/时段/唯一性
- cleanup：按 run 元数据删除本次测试数据

运行前提：后端服务已启动、MySQL 可连接、backend/.venv 已安装依赖。
"""

from __future__ import annotations

import argparse
import csv
import json
import secrets
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import requests
from sqlalchemy import text

ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.db.session import SessionLocal  # noqa: E402

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
RESULT_DIR = Path(__file__).resolve().parents[1] / "results"
DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULT_DIR.mkdir(parents=True, exist_ok=True)

PASSWORD = "Jmeter@123456"
TYPE_CODE = "S"
TIME_DAY_OFFSET = 2
TIME_HOUR = 10


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
class Api:
    def __init__(self, base_url: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()

    def request(self, method: str, path: str, *, token: str | None = None, **kwargs):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        response = self.session.request(
            method, f"{self.base_url}{path}", headers=headers, timeout=20, **kwargs
        )
        return response

    def login(self, username: str, password: str) -> str:
        response = self.request(
            "POST", "/auth/login", json={"username": username, "password": password}
        )
        if response.status_code != 200:
            raise RuntimeError(f"登录失败 {username}: {response.status_code} {response.text[:300]}")
        return response.json()["access_token"]


def _at(day_offset: int, hour: int, minute: int = 0) -> datetime:
    now = datetime.now()
    return (now + timedelta(days=day_offset)).replace(
        hour=hour, minute=minute, second=0, microsecond=0
    )


def _iso(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H:%M:%S")


def _create_user(api: Api, username: str) -> str:
    response = api.request(
        "POST", "/auth/register", json={"username": username, "password": PASSWORD}
    )
    if response.status_code != 201:
        raise RuntimeError(f"创建用户失败 {username}: {response.status_code} {response.text[:300]}")
    return api.login(username, PASSWORD)


def _create_sandbox(api: Api, admin_token: str, run_id: str, cabinets: int) -> dict[str, Any]:
    types = api.request("GET", "/cabinet-types", token=admin_token).json()
    small = next((item for item in types if item["code"] == TYPE_CODE), None)
    if not small or not small["is_active"]:
        raise RuntimeError("种子数据中缺少启用的 S 规格")

    point = api.request(
        "POST",
        "/admin/points",
        token=admin_token,
        json={
            "code": f"JM-{run_id}",
            "name": f"JMeter 并发测试 {run_id}",
            "city": "测试城市",
            "address": "JMeter 专用，测试结束自动删除",
            "open_time": "08:00",
            "close_time": "22:00",
            "status": "OPEN",
            "description": "JMeter 并发预约测试，禁止人工使用",
        },
    )
    if point.status_code != 201:
        raise RuntimeError(f"创建寄存点失败: {point.status_code} {point.text[:500]}")
    point_body = point.json()

    group = api.request(
        "POST",
        f"/admin/points/{point_body['id']}/groups",
        token=admin_token,
        json={"code": f"JMG-{run_id}", "name": f"JMeter 柜体 {run_id}", "status": "NORMAL"},
    )
    if group.status_code != 201:
        raise RuntimeError(f"创建柜体失败: {group.status_code} {group.text[:500]}")
    group_body = group.json()

    batch = api.request(
        "POST",
        f"/admin/groups/{group_body['id']}/cabinets",
        token=admin_token,
        json={
            "prefix": f"JM{run_id[:4]}-",
            "count": cabinets,
            "type_id": small["id"],
            "start_index": 1,
            "remark": "JMeter 并发测试",
        },
    )
    if batch.status_code != 201:
        raise RuntimeError(f"批量创建柜格失败: {batch.status_code} {batch.text[:500]}")
    created = batch.json()["created"]
    if len(created) != cabinets:
        raise RuntimeError(f"柜格数量不符：期望 {cabinets}，实际 {len(created)}")

    return {
        "point_id": point_body["id"],
        "point_code": point_body["code"],
        "point_name": point_body["name"],
        "group_id": group_body["id"],
        "group_code": group_body["code"],
        "cabinet_ids": [item["id"] for item in created],
        "cabinet_codes": [item["code"] for item in created],
        "type_s_id": small["id"],
    }


# ---------------------------------------------------------------------------
# prepare
# ---------------------------------------------------------------------------
def prepare(args: argparse.Namespace) -> int:
    if not args.base_url:
        raise SystemExit("必须提供 --base-url")

    run_id = secrets.token_hex(3)
    scenario = args.scenario
    cabinets = args.cabinets if scenario == "limited" else 1
    users = args.users if scenario in {"same", "limited"} else 1
    start = _at(TIME_DAY_OFFSET, TIME_HOUR)
    end = start + timedelta(hours=1)

    api = Api(args.base_url)
    admin_token = api.login(args.admin_username, args.admin_password)
    sandbox = _create_sandbox(api, admin_token, run_id, cabinets)

    usernames = [f"jmeter_{run_id}_{index:02d}" for index in range(1, users + 1)]
    tokens = [_create_user(api, username) for username in usernames]

    cabinet_ids = sandbox["cabinet_ids"]
    rows: list[dict[str, str]] = []
    for index, (username, token) in enumerate(zip(usernames, tokens)):
        cabinet_id = cabinet_ids[0] if scenario == "same" else cabinet_ids[index % len(cabinet_ids)]
        rows.append(
            {
                "token": token,
                "username": username,
                "cabinet_id": str(cabinet_id),
                "idempotency_key": f"jm-{run_id}-u{index + 1:02d}",
            }
        )

    csv_path = DATA_DIR / "threads.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["token", "username", "cabinet_id", "idempotency_key"]
        )
        writer.writeheader()
        writer.writerows(rows)

    order_no = ""
    owner_token = tokens[0]
    duplicate_key = f"jm-{run_id}-dup"
    if scenario == "cancel":
        response = api.request(
            "POST",
            "/reservations",
            token=owner_token,
            json={
                "cabinet_id": cabinet_ids[0],
                "start_time": _iso(start),
                "end_time": _iso(end),
                "luggage_size": "SMALL",
                "idempotency_key": f"jm-{run_id}-cancel",
            },
        )
        if response.status_code != 201:
            raise RuntimeError(f"准备待取消订单失败: {response.status_code} {response.text[:500]}")
        order_no = response.json()["order_no"]

    properties = {
        "mode": scenario,
        "run_id": run_id,
        "point_id": str(sandbox["point_id"]),
        "group_id": str(sandbox["group_id"]),
        "host": args.host,
        "port": str(args.port),
        "protocol": args.protocol,
        "start_time": _iso(start),
        "end_time": _iso(end),
        "cabinet_id": str(cabinet_ids[0]),
        "token": owner_token,
        "order_no": order_no,
        "idempotency_key": duplicate_key,
        "expected_success": str(min(users, cabinets) if scenario == "limited" else 1),
        "users": str(users),
        "cabinets": str(cabinets),
    }
    properties_path = DATA_DIR / "scenario.properties"
    with properties_path.open("w", encoding="utf-8") as handle:
        for key, value in properties.items():
            if value:
                handle.write(f"{key}={value}\n")

    run = {
        **sandbox,
        "run_id": run_id,
        "scenario": scenario,
        "users": usernames,
        "start_time": _iso(start),
        "end_time": _iso(end),
        "order_no": order_no,
        "duplicate_key": duplicate_key,
        "base_url": args.base_url,
    }
    (DATA_DIR / "run.json").write_text(
        json.dumps(run, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("prepare ok")
    print(f"  run_id       = {run_id}")
    print(f"  scenario     = {scenario}")
    print(f"  point        = {sandbox['point_code']} (id={sandbox['point_id']})")
    print(f"  cabinets     = {len(cabinet_ids)} -> {sandbox['cabinet_codes']}")
    print(f"  users        = {len(usernames)}")
    print(f"  window       = {_iso(start)} ~ {_iso(end)}")
    if order_no:
        print(f"  cancel order = {order_no}")
    print(f"  csv          = {csv_path}")
    print(f"  properties   = {properties_path}")
    return 0


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------
def _jtl_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _db_facts(run: dict[str, Any]) -> dict[str, Any]:
    with SessionLocal() as session:
        point_id = int(run["point_id"])
        start = run["start_time"]
        end = run["end_time"]
        active_orders = session.execute(
            text(
                """
                SELECT COUNT(*) FROM reservations
                WHERE point_id = :point_id AND start_time = :start AND end_time = :end
                  AND status IN ('RESERVED','IN_USE','OVERDUE')
                """
            ),
            {"point_id": point_id, "start": start, "end": end},
        ).scalar_one()

        slots = session.execute(
            text(
                """
                SELECT COUNT(*) FROM reservation_slots s
                JOIN reservations r ON r.id = s.reservation_id
                WHERE r.point_id = :point_id AND r.start_time = :start AND r.end_time = :end
                """
            ),
            {"point_id": point_id, "start": start, "end": end},
        ).scalar_one()

        distinct_cabinets = session.execute(
            text(
                """
                SELECT COUNT(DISTINCT cabinet_id) FROM reservations
                WHERE point_id = :point_id AND start_time = :start AND end_time = :end
                  AND status IN ('RESERVED','IN_USE','OVERDUE')
                """
            ),
            {"point_id": point_id, "start": start, "end": end},
        ).scalar_one()

        duplicate_slots = session.execute(
            text(
                """
                SELECT COUNT(*) FROM (
                    SELECT cabinet_id, slot_start, COUNT(*) AS c
                    FROM reservation_slots
                    WHERE reservation_id IN (
                        SELECT id FROM reservations
                        WHERE point_id = :point_id AND start_time = :start
                    )
                    GROUP BY cabinet_id, slot_start
                    HAVING c > 1
                ) x
                """
            ),
            {"point_id": point_id, "start": start},
        ).scalar_one()

        result: dict[str, Any] = {
            "active_orders": int(active_orders),
            "slots": int(slots),
            "distinct_cabinets": int(distinct_cabinets),
            "duplicate_slot_groups": int(duplicate_slots),
        }

        if run["scenario"] == "duplicate":
            result.update(
                session.execute(
                    text(
                        """
                        SELECT COUNT(*) AS orders, COUNT(DISTINCT order_no) AS order_nos,
                               COUNT(DISTINCT idempotency_key) AS keys_
                        FROM reservations
                        WHERE point_id = :point_id AND idempotency_key = :key
                        """
                    ),
                    {"point_id": point_id, "key": run["duplicate_key"]},
                ).mappings().one()
            )
        elif run["scenario"] == "cancel":
            row = session.execute(
                text(
                    """
                    SELECT status, order_no FROM reservations WHERE order_no = :order_no
                    """
                ),
                {"order_no": run["order_no"]},
            ).mappings().one()
            logs = session.execute(
                text(
                    """
                    SELECT COUNT(*) FROM reservation_status_logs l
                    JOIN reservations r ON r.id = l.reservation_id
                    WHERE r.order_no = :order_no AND l.to_status = 'CANCELLED'
                    """
                ),
                {"order_no": run["order_no"]},
            ).scalar_one()
            result.update(
                {
                    "order_no": row["order_no"],
                    "status": row["status"],
                    "cancel_logs": int(logs),
                }
            )
        return result


def verify(args: argparse.Namespace) -> int:
    run = json.loads((DATA_DIR / "run.json").read_text(encoding="utf-8"))
    rows = _jtl_rows(Path(args.jtl))
    codes: dict[str, int] = {}
    business_codes: dict[str, int] = {}
    order_nos: set[str] = set()
    assertion_failures = 0
    for row in rows:
        codes[row.get("responseCode", "")] = codes.get(row.get("responseCode", ""), 0) + 1
        bcode = (row.get("jm_code") or "").strip()
        if bcode:
            business_codes[bcode] = business_codes.get(bcode, 0) + 1
        order = (row.get("jm_order_no") or "").strip()
        if order:
            order_nos.add(order)
        if str(row.get("success", "")).lower() == "false":
            assertion_failures += 1

    facts = _db_facts(run)
    scenario = run["scenario"]
    props: dict[str, str] = {}
    for line in (DATA_DIR / "scenario.properties").read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            props[key] = value
    expected = int(props["expected_success"])
    checks: list[tuple[str, bool, str]] = []
    if args.samples is not None:
        checks.append(
            (
                "JTL 样本数与计划线程/循环一致",
                len(rows) == args.samples,
                f"samples={len(rows)}, expected={args.samples}",
            )
        )

    if scenario == "same":
        checks.append(
            (
                "失败业务码均为 CABINET_TIME_CONFLICT",
                business_codes.get("CABINET_TIME_CONFLICT", 0) == len(rows) - 1,
                f"CABINET_TIME_CONFLICT={business_codes.get('CABINET_TIME_CONFLICT', 0)}",
            )
        )
        checks.append(("恰好 1 个 HTTP 201", codes.get("201", 0) == 1, f"201={codes.get('201', 0)}"))
        checks.append(
            ("其余均为 409 冲突", codes.get("409", 0) == len(rows) - 1, f"409={codes.get('409', 0)}, samples={len(rows)}")
        )
        checks.append(("无 HTTP 503", codes.get("503", 0) == 0, f"503={codes.get('503', 0)}"))
        checks.append(("无断言失败", assertion_failures == 0, f"assertion_failures={assertion_failures}"))
        checks.append(("DB 仅 1 个活动订单", facts["active_orders"] == 1, str(facts["active_orders"])))
        checks.append(("DB 仅 2 条时段", facts["slots"] == 2, str(facts["slots"])))
        checks.append(("DB 仅 1 个柜格被占", facts["distinct_cabinets"] == 1, str(facts["distinct_cabinets"])))
        checks.append(("无重复 (cabinet, slot_start)", facts["duplicate_slot_groups"] == 0, str(facts["duplicate_slot_groups"])))
    elif scenario == "limited":
        checks.append(
            (
                "失败业务码均为 CABINET_TIME_CONFLICT",
                business_codes.get("CABINET_TIME_CONFLICT", 0) == len(rows) - expected,
                f"CABINET_TIME_CONFLICT={business_codes.get('CABINET_TIME_CONFLICT', 0)}",
            )
        )
        checks.append(("成功数 = min(用户数, 柜格数)", codes.get("201", 0) == expected, f"201={codes.get('201', 0)}, expected={expected}"))
        checks.append(("其余均为 409 冲突", codes.get("409", 0) == len(rows) - expected, f"409={codes.get('409', 0)}"))
        checks.append(("无 HTTP 503", codes.get("503", 0) == 0, f"503={codes.get('503', 0)}"))
        checks.append(("无断言失败", assertion_failures == 0, f"assertion_failures={assertion_failures}"))
        checks.append(("DB 活动订单数 = 成功数", facts["active_orders"] == expected, str(facts["active_orders"])))
        checks.append(("DB 时段数 = 2 × 成功数", facts["slots"] == expected * 2, str(facts["slots"])))
        checks.append(("DB 被占柜格数 = 成功数", facts["distinct_cabinets"] == expected, str(facts["distinct_cabinets"])))
        checks.append(("无重复 (cabinet, slot_start)", facts["duplicate_slot_groups"] == 0, str(facts["duplicate_slot_groups"])))
    elif scenario == "duplicate":
        checks.append(("恰好 1 个 HTTP 201", codes.get("201", 0) == 1, f"201={codes.get('201', 0)}"))
        checks.append(("其余为幂等重放 200", codes.get("200", 0) == len(rows) - 1, f"200={codes.get('200', 0)}"))
        checks.append(("所有响应同一订单号", len(order_nos) == 1, f"order_nos={len(order_nos)}"))
        checks.append(("无断言失败", assertion_failures == 0, f"assertion_failures={assertion_failures}"))
        checks.append(("DB 仅 1 个订单", facts.get("orders") == 1, str(facts.get("orders"))))
        checks.append(("DB 仅 2 条时段", facts["slots"] == 2, str(facts["slots"])))
    elif scenario == "cancel":
        checks.append(
            (
                "失败业务码均为 ORDER_STATUS_NOT_ALLOWED",
                business_codes.get("ORDER_STATUS_NOT_ALLOWED", 0) == len(rows) - 1,
                f"ORDER_STATUS_NOT_ALLOWED={business_codes.get('ORDER_STATUS_NOT_ALLOWED', 0)}",
            )
        )
        checks.append(("恰好 1 个 HTTP 200", codes.get("200", 0) == 1, f"200={codes.get('200', 0)}"))
        checks.append(("其余为 409 状态冲突", codes.get("409", 0) == len(rows) - 1, f"409={codes.get('409', 0)}"))
        checks.append(("无 HTTP 503", codes.get("503", 0) == 0, f"503={codes.get('503', 0)}"))
        checks.append(("DB 订单已取消", facts.get("status") == "CANCELLED", str(facts.get("status"))))
        checks.append(("DB 时段已释放", facts["slots"] == 0, str(facts["slots"])))
        checks.append(("DB 仅 1 条取消日志", facts.get("cancel_logs") == 1, str(facts.get("cancel_logs"))))
    else:
        checks.append(("未知场景", False, scenario))

    summary = {
        "scenario": scenario,
        "threads": len(rows),
        "http_codes": codes,
        "business_codes": business_codes,
        "assertion_failures": assertion_failures,
        "db": facts,
        "checks": [{"name": name, "ok": ok, "detail": detail} for name, ok, detail in checks],
        "jtl": str(Path(args.jtl).resolve()),
        "run_id": run["run_id"],
    }
    out = RESULT_DIR / f"verify-{scenario}-{run['run_id']}.json"
    out.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"scenario={scenario} samples={len(rows)} codes={codes} business={business_codes}")
    print(f"db={json.dumps(facts, ensure_ascii=False)}")
    failed = 0
    for name, ok, detail in checks:
        print(("  PASS " if ok else "  FAIL ") + f"{name} ({detail})")
        if not ok:
            failed += 1
    print(f"summary={out}")
    if failed:
        print(f"VERIFY FAILED: {failed} checks failed")
        return 1
    print("VERIFY OK")
    return 0


# ---------------------------------------------------------------------------
# cleanup
# ---------------------------------------------------------------------------
def cleanup(args: argparse.Namespace) -> int:
    run_path = DATA_DIR / "run.json"
    if not run_path.exists():
        print("没有 data/run.json，跳过")
        return 0
    run = json.loads(run_path.read_text(encoding="utf-8"))
    point_id = int(run["point_id"])
    group_id = int(run["group_id"])
    usernames = run.get("users", [])

    with SessionLocal() as session:
        session.execute(
            text(
                "DELETE l FROM reservation_status_logs l JOIN reservations r ON r.id = l.reservation_id "
                "WHERE r.point_id = :point_id"
            ),
            {"point_id": point_id},
        )
        session.execute(
            text(
                "DELETE s FROM reservation_slots s JOIN reservations r ON r.id = s.reservation_id "
                "WHERE r.point_id = :point_id"
            ),
            {"point_id": point_id},
        )
        session.execute(text("DELETE FROM reservations WHERE point_id = :point_id"), {"point_id": point_id})
        session.execute(text("DELETE FROM cabinets WHERE group_id = :group_id"), {"group_id": group_id})
        session.execute(text("DELETE FROM cabinet_groups WHERE id = :group_id"), {"group_id": group_id})
        session.execute(text("DELETE FROM storage_points WHERE id = :point_id"), {"point_id": point_id})
        for username in usernames:
            session.execute(text("DELETE FROM users WHERE username = :username"), {"username": username})
        session.commit()

    print(f"cleanup ok: point_id={point_id}, group_id={group_id}, users={len(usernames)}")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description="JMeter 并发预约测试数据工具")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare")
    p.add_argument("--scenario", choices=["same", "limited", "duplicate", "cancel"], required=True)
    p.add_argument("--users", type=int, default=4)
    p.add_argument("--cabinets", type=int, default=6)
    p.add_argument("--base-url", default="http://127.0.0.1:8138/api/v1")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8138)
    p.add_argument("--protocol", default="http")
    p.add_argument("--admin-username", default="admin")
    p.add_argument("--admin-password", default="Demo@123456")
    p.set_defaults(func=prepare)

    v = sub.add_parser("verify")
    v.add_argument("--jtl", required=True)
    v.add_argument("--samples", type=int, default=None, help="期望样本数 = 线程数 × 循环数")
    v.set_defaults(func=verify)

    c = sub.add_parser("cleanup")
    c.set_defaults(func=cleanup)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
