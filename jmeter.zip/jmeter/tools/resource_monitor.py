"""JMeter 运行期间的轻量资源采样器（Windows，无第三方依赖）。

采集：
- 整机 CPU / 可用内存
- 后端 Python、JMeter Java、mysqld 的进程 CPU 与工作集
- MySQL 全局状态：连接数、运行线程、最大连接、InnoDB 行锁等待、慢查询、Questions

用法：
    python resource_monitor.py --output ../results/same-16-resources.csv --stop-file ../results/.monitor.stop

进程 CPU 的单位是“单核百分比”，多核进程可超过 100%；整机 CPU 是 0~100%。
"""
from __future__ import annotations

import argparse
import csv
import ctypes
import json
import os
import re
import subprocess
import time
from ctypes import wintypes
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

from sqlalchemy import create_engine, text


PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_FILE = PROJECT_ROOT / "backend" / ".env"


# ---------------------------------------------------------------------------
# Windows 进程/内存 API
# ---------------------------------------------------------------------------
class FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD)]


class PROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
        ("PrivateUsage", ctypes.c_size_t),
    ]


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD),
        ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

kernel32.GetSystemTimes.argtypes = [
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
]
kernel32.GetSystemTimes.restype = wintypes.BOOL

kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL
kernel32.GetProcessTimes.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
]
kernel32.GetProcessTimes.restype = wintypes.BOOL
kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL

psapi.GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE,
    ctypes.POINTER(PROCESS_MEMORY_COUNTERS_EX),
    wintypes.DWORD,
]
psapi.GetProcessMemoryInfo.restype = wintypes.BOOL

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _ft_value(value: FILETIME) -> int:
    return (int(value.dwHighDateTime) << 32) + int(value.dwLowDateTime)


def system_cpu_times() -> tuple[float, float, float]:
    idle = FILETIME()
    kernel = FILETIME()
    user = FILETIME()
    if not kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
        raise OSError("GetSystemTimes failed")
    return _ft_value(idle), _ft_value(kernel), _ft_value(user)


def memory_available_mb() -> tuple[float, float]:
    status = MEMORYSTATUSEX()
    status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
    if not kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("GlobalMemoryStatusEx failed")
    return status.ullAvailPhys / 1024 / 1024, status.ullTotalPhys / 1024 / 1024


def process_cpu_seconds(pid: int) -> float | None:
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        creation = FILETIME()
        exit_time = FILETIME()
        kernel = FILETIME()
        user = FILETIME()
        if not kernel32.GetProcessTimes(
            handle,
            ctypes.byref(creation),
            ctypes.byref(exit_time),
            ctypes.byref(kernel),
            ctypes.byref(user),
        ):
            return None
        return (_ft_value(kernel) + _ft_value(user)) / 10_000_000
    finally:
        kernel32.CloseHandle(handle)


def process_working_set_mb(pid: int) -> float | None:
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        counters = PROCESS_MEMORY_COUNTERS_EX()
        counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS_EX)
        if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
            return None
        return counters.WorkingSetSize / 1024 / 1024
    finally:
        kernel32.CloseHandle(handle)


# ---------------------------------------------------------------------------
# 进程定位
# ---------------------------------------------------------------------------
def run_powershell(command: str) -> str:
    wrapped = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + command
    try:
        completed = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", wrapped],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=12,
        )
    except Exception:
        return ""
    return (completed.stdout or "").strip()


def first_int(text_value: str) -> int | None:
    match = re.search(r"\d+", text_value or "")
    return int(match.group(0)) if match else None


def process_stats(pid: int) -> tuple[float | None, float | None]:
    """优先用 Win32 API；权限不足时用 Get-Process 兜底（如 mysqld）。"""
    cpu_seconds = process_cpu_seconds(pid)
    working_set = process_working_set_mb(pid)
    if cpu_seconds is not None and working_set is not None:
        return cpu_seconds, working_set
    raw = run_powershell(
        f"$p = Get-Process -Id {pid} -ErrorAction SilentlyContinue; "
        "if ($p) { [pscustomobject]@{ CPU = $p.CPU; WS = $p.WorkingSet64 } "
        "| ConvertTo-Json -Compress }"
    )
    if raw:
        try:
            match = re.search(r"\{.*\}", raw, re.S)
            payload = json.loads(match.group(0) if match else raw)
            fallback_cpu = payload.get("CPU")
            fallback_ws = payload.get("WS")
            if cpu_seconds is None and fallback_cpu is not None:
                cpu_seconds = float(fallback_cpu)
            if working_set is None and fallback_ws is not None:
                working_set = float(fallback_ws) / 1024 / 1024
        except Exception:
            pass
    return cpu_seconds, working_set


def mysqld_stats_wmi(pid: int) -> tuple[float | None, float | None]:
    """服务进程（mysqld）拿不到进程句柄时，用性能计数器取瞬时 CPU% 和工作集。"""
    raw = run_powershell(
        "Get-CimInstance Win32_PerfFormattedData_PerfProc_Process "
        f"-Filter \"IDProcess={pid}\" "
        "| Select-Object PercentProcessorTime,WorkingSet | ConvertTo-Json -Compress"
    )
    if not raw:
        return None, None
    try:
        match = re.search(r"\{.*\}", raw, re.S)
        payload = json.loads(match.group(0) if match else raw)
        cpu = payload.get("PercentProcessorTime")
        working_set = payload.get("WorkingSet")
        return (
            float(cpu) if cpu is not None else None,
            float(working_set) / 1024 / 1024 if working_set is not None else None,
        )
    except Exception:
        return None, None


def locate_processes() -> dict[str, int | None]:
    raw = run_powershell(
        "$backend = (Get-NetTCPConnection -LocalPort 8138 -State Listen -ErrorAction SilentlyContinue "
        "| Select-Object -First 1 -ExpandProperty OwningProcess); "
        "$jmeter = (Get-CimInstance Win32_Process -Filter \"name='java.exe'\" "
        "| Where-Object { $_.CommandLine -match 'jmeter' } "
        "| Select-Object -First 1 -ExpandProperty ProcessId); "
        "$mysql = (Get-Process -Name mysqld -ErrorAction SilentlyContinue "
        "| Select-Object -First 1 -ExpandProperty Id); "
        "[pscustomobject]@{ backend = $backend; jmeter = $jmeter; mysqld = $mysql } "
        "| ConvertTo-Json -Compress"
    )
    payload: dict[str, object] = {}
    if raw:
        try:
            match = re.search(r"\{.*\}", raw, re.S)
            payload = json.loads(match.group(0) if match else raw)
        except Exception:
            payload = {}
    backend_pid = first_int(str(payload.get("backend", "")))
    if backend_pid is None:
        netstat = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        for line in netstat.stdout.splitlines():
            if ":8138" in line and "LISTENING" in line.upper():
                backend_pid = first_int(line.split()[-1])
                break

    return {
        "backend": backend_pid,
        "jmeter": first_int(str(payload.get("jmeter", ""))),
        "mysqld": first_int(str(payload.get("mysqld", ""))),
    }


# ---------------------------------------------------------------------------
# MySQL 指标
# ---------------------------------------------------------------------------
def read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if not ENV_FILE.exists():
        return values
    for raw in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def make_engine():
    env = read_env()
    host = env.get("DB_HOST", "127.0.0.1")
    port = env.get("DB_PORT", "3306")
    user = env.get("DB_USER", "root")
    password = env.get("DB_PASSWORD", "")
    database = env.get("DB_NAME", "luggage_locker")
    url = (
        f"mysql+pymysql://{quote_plus(user)}:{quote_plus(password)}"
        f"@{host}:{port}/{database}?charset=utf8mb4"
    )
    return create_engine(url, pool_pre_ping=True, pool_recycle=60)


STATUS_KEYS = {
    "Threads_connected": "mysql_threads_connected",
    "Threads_running": "mysql_threads_running",
    "Max_used_connections": "mysql_max_used_connections",
    "Innodb_row_lock_current_waits": "mysql_lock_current_waits",
    "Innodb_row_lock_waits": "mysql_lock_waits",
    "Innodb_row_lock_time_avg": "mysql_lock_time_avg_ms",
    "Innodb_row_lock_time_max": "mysql_lock_time_max_ms",
    "Innodb_row_lock_time": "mysql_lock_time_total_ms",
    "Slow_queries": "mysql_slow_queries",
    "Questions": "mysql_questions",
    "Uptime": "mysql_uptime_s",
    "Aborted_connects": "mysql_aborted_connects",
}


def mysql_metrics(engine, previous: dict[str, int]) -> dict[str, int]:
    values: dict[str, int] = {}
    with engine.connect() as connection:
        rows = connection.execute(text("SHOW GLOBAL STATUS")).fetchall()
        status = {str(row[0]): str(row[1]) for row in rows}
        variables = connection.execute(text("SHOW GLOBAL VARIABLES LIKE 'max_connections'")).fetchall()
        processlist = connection.execute(
            text("SELECT COUNT(*) FROM information_schema.PROCESSLIST")
        ).scalar_one()
    for source, target in STATUS_KEYS.items():
        try:
            values[target] = int(status.get(source, "0"))
        except ValueError:
            values[target] = 0
    values["mysql_max_connections"] = int(variables[0][1]) if variables else 0
    values["mysql_processlist_count"] = int(processlist)
    values["mysql_questions_delta"] = max(
        0, values["mysql_questions"] - previous.get("mysql_questions", values["mysql_questions"])
    )
    values["mysql_lock_waits_delta"] = max(
        0, values["mysql_lock_waits"] - previous.get("mysql_lock_waits", values["mysql_lock_waits"])
    )
    return values


# ---------------------------------------------------------------------------
# 采样
# ---------------------------------------------------------------------------
CSV_FIELDS = [
    "timestamp",
    "elapsed_s",
    "cpu_total_pct",
    "mem_available_mb",
    "mem_total_mb",
    "backend_pid",
    "backend_cpu_pct",
    "backend_ws_mb",
    "jmeter_pid",
    "jmeter_cpu_pct",
    "jmeter_ws_mb",
    "mysqld_pid",
    "mysqld_cpu_pct",
    "mysqld_ws_mb",
    *STATUS_KEYS.values(),
    "mysql_max_connections",
    "mysql_processlist_count",
    "mysql_questions_delta",
    "mysql_lock_waits_delta",
]


def summarize(rows: list[dict[str, object]], meta: dict[str, object]) -> dict[str, object]:
    metrics: dict[str, dict[str, float | None]] = {}
    numeric_fields = [field for field in CSV_FIELDS if field not in {"timestamp", "elapsed_s"}]
    for field in numeric_fields:
        values = []
        for row in rows:
            raw = row.get(field)
            if raw in (None, ""):
                continue
            try:
                values.append(float(raw))
            except (TypeError, ValueError):
                continue
        if values:
            metrics[field] = {
                "min": round(min(values), 2),
                "max": round(max(values), 2),
                "avg": round(sum(values) / len(values), 2),
            }
    return {
        **meta,
        "sample_count": len(rows),
        "metrics": metrics,
        "note": (
            "process_cpu_pct 是单核百分比，多核进程可超过 100；"
            "cpu_total_pct 是整机 0~100。mysqld 进程句柄被服务权限拒绝，"
            "mysqld_cpu_pct/mysqld_ws_mb 每 5 个样本用 WMI 取一次并沿用；"
            "MySQL 连接/锁指标每个样本都从 performance_schema/global_status 读取。"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, help="CSV 输出路径")
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--duration", type=float, default=0, help="0 表示一直采到 stop-file 出现")
    parser.add_argument("--stop-file", default="")
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    summary_path = output.with_suffix(".summary.json")
    stop_file = Path(args.stop_file) if args.stop_file else None
    if stop_file and stop_file.exists():
        stop_file.unlink()

    engine = None
    try:
        engine = make_engine()
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
    except Exception as exc:
        print(f"MySQL metrics disabled: {type(exc).__name__}")
        engine = None

    rows: list[dict[str, object]] = []
    previous_process_cpu: dict[str, float] = {}
    previous_system = system_cpu_times()
    previous_mysql: dict[str, int] = {}
    started = time.monotonic()
    started_at = datetime.now().isoformat(timespec="seconds")
    processes: dict[str, int | None] = {}
    next_process_refresh = 0.0
    mysqld_cache: dict[str, object] = {"cpu": "", "ws": ""}

    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        while True:
            now = time.monotonic()
            if args.duration > 0 and now - started >= args.duration:
                break
            if stop_file and stop_file.exists():
                break
            if now >= next_process_refresh:
                processes = locate_processes()
                next_process_refresh = now + 2.0

            idle, kernel, user = system_cpu_times()
            idle_delta = idle - previous_system[0]
            kernel_delta = kernel - previous_system[1]
            user_delta = user - previous_system[2]
            busy_delta = kernel_delta + user_delta
            cpu_total = 0.0
            if busy_delta > 0:
                cpu_total = max(0.0, min(100.0, (busy_delta - idle_delta) / busy_delta * 100))
            previous_system = (idle, kernel, user)

            elapsed = now - started
            interval = max(0.001, elapsed - float(rows[-1]["elapsed_s"])) if rows else args.interval
            avail_mb, total_mb = memory_available_mb()
            row: dict[str, object] = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "elapsed_s": round(elapsed, 3),
                "cpu_total_pct": round(cpu_total, 2),
                "mem_available_mb": round(avail_mb, 1),
                "mem_total_mb": round(total_mb, 1),
            }
            for name in ("backend", "jmeter", "mysqld"):
                pid = processes.get(name)
                row[f"{name}_pid"] = pid or ""
                cpu_pct = ""
                ws_mb = ""
                if pid:
                    if name == "mysqld":
                        # mysqld 以服务账号运行，OpenProcess 被拒绝；每 5 个样本用 WMI 取一次，
                        # 其余样本沿用上一次值，避免 WMI 查询把 1 秒采样拖慢。
                        if len(rows) % 5 == 0:
                            direct_pct, direct_ws = mysqld_stats_wmi(pid)
                            if direct_pct is not None:
                                mysqld_cache["cpu"] = round(max(0.0, direct_pct), 2)
                            if direct_ws is not None:
                                mysqld_cache["ws"] = round(direct_ws, 1)
                        cpu_pct = mysqld_cache["cpu"]
                        ws_mb = mysqld_cache["ws"]
                    else:
                        cpu_seconds, ws = process_stats(pid)
                        if cpu_seconds is not None:
                            previous = previous_process_cpu.get(name)
                            if previous is not None:
                                cpu_pct = round(max(0.0, (cpu_seconds - previous) / interval * 100), 2)
                            previous_process_cpu[name] = cpu_seconds
                        if ws is not None:
                            ws_mb = round(ws, 1)
                row[f"{name}_cpu_pct"] = cpu_pct
                row[f"{name}_ws_mb"] = ws_mb

            if engine is not None:
                try:
                    metrics = mysql_metrics(engine, previous_mysql)
                    previous_mysql = metrics
                    row.update(metrics)
                except Exception:
                    pass
            writer.writerow(row)
            handle.flush()
            rows.append(row)
            summary_path.write_text(
                json.dumps(
                    summarize(
                        rows,
                        {
                            "started_at": started_at,
                            "updated_at": datetime.now().isoformat(timespec="seconds"),
                            "interval_s": args.interval,
                            "csv": str(output),
                        },
                    ),
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            time.sleep(max(0.05, args.interval - (time.monotonic() - now)))

    summary = summarize(
        rows,
        {
            "started_at": started_at,
            "ended_at": datetime.now().isoformat(timespec="seconds"),
            "interval_s": args.interval,
            "csv": str(output),
        },
    )
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"samples={len(rows)} csv={output} summary={summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
